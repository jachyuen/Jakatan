﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net.Core;
using System.ServiceModel;
using DIS.Framework.Commands;

namespace DIS.Framework.Logging
{
    public interface IExeLogger
    {
        void Debug(String message);
        void Debug(String message, Exception exception);
        void DebugFormat(string format, params object[] args);
        void DebugFormat(string format, object arg0);
        void DebugFormat(IFormatProvider provider, string format, params object[] args);
        void DebugFormat(string format, object arg0, object arg1);
        void DebugFormat(string format, object arg0, object arg1, object arg2);
        void Error(String message);
        void Error(String message, Exception exception);
        void ErrorFormat(string format, params object[] args);
        void ErrorFormat(string format, object arg0);
        void ErrorFormat(IFormatProvider provider, string format, params object[] args);
        void ErrorFormat(string format, object arg0, object arg1);
        void ErrorFormat(string format, object arg0, object arg1, object arg2);
        void Fatal(String message);
        void Fatal(String message, Exception exception);
        void FatalFormat(string format, object arg0);
        void FatalFormat(string format, params object[] args);
        void FatalFormat(IFormatProvider provider, string format, params object[] args);
        void FatalFormat(string format, object arg0, object arg1);
        void FatalFormat(string format, object arg0, object arg1, object arg2);
        void Info(String message);
        void Info(String message, Exception exception);
        void InfoFormat(string format, object arg0);
        void InfoFormat(string format, params object[] args);
        void InfoFormat(string format, object arg0, object arg1);
        void InfoFormat(IFormatProvider provider, string format, params object[] args);
        void InfoFormat(string format, object arg0, object arg1, object arg2);
        void Warn(String message);
        void Warn(String message, Exception exception);
        void WarnFormat(string format, object arg0);
        void WarnFormat(string format, params object[] args);
        void WarnFormat(string format, object arg0, object arg1);
        void WarnFormat(IFormatProvider provider, string format, params object[] args);
        void WarnFormat(string format, object arg0, object arg1, object arg2);
    }

    public class ExeLogger : IExeLogger
    {
        public ILog _log { get; set; }
        private ICommandCallback _callback;
        private string _sessionId;

        public ExeLogger()
        {
            try
            {
                if (OperationContext.Current == null)
                {
                    _callback = null;
                }
                else
                {
                    if (OperationContext.Current.Channel.State == CommunicationState.Opened || OperationContext.Current.Channel.State == CommunicationState.Created)
                        _callback = OperationContext.Current.GetCallbackChannel<ICommandCallback>();
                    else
                        _callback = null;
                }

                _sessionId = String.Format("[SessionId:{0}] ", OperationContext.Current == null ? "NULL" : OperationContext.Current.SessionId);
            }
            catch (InvalidCastException)
            {
                _callback = null;
                _sessionId = String.Format("[SessionId:NULL] ");
            }

        }

        private void CallbackDEBUG(string message)
        {
            Callback("[DEBUG] " + message);
        }

        private void CallbackERROR(string message)
        {
            Callback("[ERROR] " + message);
        }

        private void CallbackFATAL(string message)
        {
            Callback("[FATAL] " + message);
        }

        private void CallbackINFO(string message)
        {
            Callback("[INFO] " + message);
        }

        private void CallbackWARN(string message)
        {
            Callback("[WARN] " + message);
        }

        private void Callback(string message)
        {
            if (_callback != null)
            {
                try
                {
                    _callback.SendResult(message + "\r\n");
                }
                catch (CommunicationException)
                {
                    //communication with client failed. more than likely the exe process was killed. not required to do anything if that happens.
                }
            }
        }

        private string PrepareLog(String message)
        {
            return _sessionId + " " + message;
        }

        public void Debug(String message)
        {
            _log.Debug(PrepareLog(message));
            CallbackDEBUG(PrepareLog(message));
        }

        public void Debug(String message, Exception exception)
        {
            _log.Debug(PrepareLog(message), exception);
            CallbackDEBUG(PrepareLog(message));
        }

        public void DebugFormat(string format, object arg0)
        {
            _log.DebugFormat(PrepareLog(format), arg0);
            CallbackDEBUG(String.Format(PrepareLog(format), arg0));
        }

        public void DebugFormat(string format, params object[] args)
        {
            _log.DebugFormat(PrepareLog(format), args);
            CallbackDEBUG(String.Format(PrepareLog(format), args));
        }

        public void DebugFormat(IFormatProvider provider, string format, params object[] args)
        {
            _log.DebugFormat(provider, PrepareLog(format), args);
            CallbackDEBUG(String.Format(provider, PrepareLog(format), args));
        }

        public void DebugFormat(string format, object arg0, object arg1)
        {
            _log.DebugFormat(PrepareLog(format), arg0, arg1);
            CallbackDEBUG(String.Format(PrepareLog(format), arg0, arg1));
        }

        public void DebugFormat(string format, object arg0, object arg1, object arg2)
        {
            _log.DebugFormat(PrepareLog(format), arg0, arg1, arg2);
            CallbackDEBUG(String.Format(PrepareLog(format), arg0, arg1, arg2));
        }

        public void Error(String message)
        {
            _log.Error(PrepareLog(message));
            CallbackERROR(PrepareLog(message));
        }

        public void Error(String message, Exception exception)
        {
            _log.Error(PrepareLog(message), exception);
            CallbackERROR(PrepareLog(message));
        }

        public void ErrorFormat(string format, object arg0)
        {
            _log.ErrorFormat(PrepareLog(format), arg0);
            CallbackERROR(String.Format(PrepareLog(format), arg0));
        }

        public void ErrorFormat(string format, params object[] args)
        {
            _log.ErrorFormat(PrepareLog(format), args);
            CallbackERROR(String.Format(PrepareLog(format), args));
        }

        public void ErrorFormat(IFormatProvider provider, string format, params object[] args)
        {
            _log.ErrorFormat(provider, PrepareLog(format), args);
            CallbackERROR(String.Format(provider, PrepareLog(format), args));
        }

        public void ErrorFormat(string format, object arg0, object arg1)
        {
            _log.ErrorFormat(PrepareLog(format), arg0, arg1);
            CallbackERROR(String.Format(PrepareLog(format), arg0, arg1));
        }

        public void ErrorFormat(string format, object arg0, object arg1, object arg2)
        {
            _log.ErrorFormat(PrepareLog(format), arg0, arg1, arg2);
            CallbackERROR(String.Format(PrepareLog(format), arg0, arg1, arg2));

        }

        public void Fatal(String message)
        {
            _log.Fatal(PrepareLog(message));
            CallbackFATAL(PrepareLog(message));
        }

        public void Fatal(String message, Exception exception)
        {
            _log.Fatal(PrepareLog(message), exception);
            CallbackFATAL(PrepareLog(message));
        }

        public void FatalFormat(string format, object arg0)
        {
            _log.FatalFormat(PrepareLog(format), arg0);
            CallbackFATAL(String.Format(PrepareLog(format), arg0));
        }

        public void FatalFormat(string format, params object[] args)
        {
            _log.FatalFormat(PrepareLog(format), args);
            CallbackFATAL(String.Format(PrepareLog(format), args));
        }

        public void FatalFormat(IFormatProvider provider, string format, params object[] args)
        {
            _log.FatalFormat(provider, PrepareLog(format), args);
            CallbackFATAL(String.Format(provider, PrepareLog(format), args));
        }

        public void FatalFormat(string format, object arg0, object arg1)
        {
            _log.FatalFormat(PrepareLog(format), arg0, arg1);
            CallbackFATAL(String.Format(PrepareLog(format), arg0, arg1));
        }

        public void FatalFormat(string format, object arg0, object arg1, object arg2)
        {
            _log.FatalFormat(PrepareLog(format), arg0, arg1, arg2);
            CallbackFATAL(String.Format(PrepareLog(format), arg0, arg1, arg2));
        }

        public void Info(String message)
        {
            _log.Info(PrepareLog(message));
            CallbackINFO(PrepareLog(message));
        }

        public void Info(String message, Exception exception)
        {
            _log.Info(PrepareLog(message), exception);
            CallbackINFO(PrepareLog(message));
        }

        public void InfoFormat(string format, object arg0)
        {
            _log.InfoFormat(PrepareLog(format), arg0);
            CallbackINFO(String.Format(PrepareLog(format), arg0));
        }

        public void InfoFormat(string format, params object[] args)
        {
            _log.InfoFormat(PrepareLog(format), args);
            CallbackINFO(String.Format(PrepareLog(format), args));
        }

        public void InfoFormat(IFormatProvider provider, string format, params object[] args)
        {
            _log.InfoFormat(provider, PrepareLog(format), args);
            CallbackINFO(String.Format(provider, PrepareLog(format), args));
        }

        public void InfoFormat(string format, object arg0, object arg1)
        {
            _log.InfoFormat(PrepareLog(format), arg0, arg1);
            CallbackINFO(String.Format(PrepareLog(format), arg0, arg1));
        }

        public void InfoFormat(string format, object arg0, object arg1, object arg2)
        {
            _log.InfoFormat(PrepareLog(format), arg0, arg1, arg2);
            CallbackINFO(String.Format(PrepareLog(format), arg0, arg1, arg2));
        }

        public void Warn(String message)
        {
            _log.Warn(PrepareLog(message));
            CallbackWARN(PrepareLog(message));
        }

        public void Warn(String message, Exception exception)
        {
            _log.Warn(PrepareLog(message), exception);
            CallbackWARN(PrepareLog(message));
        }

        public void WarnFormat(string format, object arg0)
        {
            _log.WarnFormat(PrepareLog(format), arg0);
            CallbackWARN(String.Format(PrepareLog(format), arg0));
        }

        public void WarnFormat(string format, params object[] args)
        {
            _log.WarnFormat(PrepareLog(format), args);
            CallbackWARN(String.Format(PrepareLog(format), args));
        }

        public void WarnFormat(IFormatProvider provider, string format, params object[] args)
        {
            _log.WarnFormat(provider, PrepareLog(format), args);
            CallbackWARN(String.Format(provider, PrepareLog(format), args));
        }

        public void WarnFormat(string format, object arg0, object arg1)
        {
            _log.WarnFormat(PrepareLog(format), arg0, arg1);
            CallbackWARN(String.Format(PrepareLog(format), arg0, arg1));
        }

        public void WarnFormat(string format, object arg0, object arg1, object arg2)
        {
            _log.WarnFormat(PrepareLog(format), arg0, arg1, arg2);
            CallbackWARN(String.Format(PrepareLog(format), arg0, arg1, arg2));
        }
    }
}