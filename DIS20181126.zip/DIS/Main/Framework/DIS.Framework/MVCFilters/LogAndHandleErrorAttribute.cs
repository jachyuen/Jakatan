﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace DIS.Framework.MVCFilters
{
    public class LogAndHandleErrorAttribute : HandleErrorAttribute//, IActionFilter
    {
        private ILog _log;
        public ILog log
        {
            get
            {
                if (_log == null)
                    _log = LogManager.GetLogger(this.GetType());

                return _log;
            }
            set
            {
                _log = value;
            }
        }

        public override void OnException(ExceptionContext filterContext)
        {
            if (filterContext == null)
                throw new ArgumentNullException("filterContext");

            bool isAjaxRequest = filterContext.HttpContext.Request.IsAjaxRequest();
            bool isJsonRequest = IsJsonRequest(filterContext);

            string errorRef = GetErrorRef();
            LogException(filterContext, errorRef);

            if (filterContext.ExceptionHandled)
                return;

            if (!filterContext.ExceptionHandled && filterContext.HttpContext.IsCustomErrorEnabled && filterContext.HttpContext.Response.StatusCode != 500)
            {
                Exception exception = filterContext.Exception;
                int httpStatusCode = (new HttpException(null, exception)).GetHttpCode();

                string area = (string)filterContext.RouteData.Values["area"];
                string controllerName = (string)filterContext.RouteData.Values["controller"];
                string actionName = (string)filterContext.RouteData.Values["action"];

                if (this.View != "NULL")
                    base.OnException(filterContext);

                //Clean cache
                HttpContext.Current.Cache.Remove("MVCExceptionTEMPDATA");
                TempDataDictionary tdd = new TempDataDictionary();
                tdd.Add("errorRef", errorRef);
                tdd.Add("errorInfo", new HandleErrorInfo(filterContext.Exception, controllerName, actionName));
                tdd.Add("aspxErrorPath", filterContext.HttpContext.Request.Url.PathAndQuery);
                tdd.Add("isAjaxRequest", isAjaxRequest);
                tdd.Add("isJsonRequest", isJsonRequest);
                HttpContext.Current.Cache.Insert("MVCExceptionTEMPDATA", tdd);

                filterContext.HttpContext.Response.TrySkipIisCustomErrors = false;

                if (isAjaxRequest && filterContext.Exception != null)
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    filterContext.Result = new JsonResult
                    {
                        JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                        Data = new
                        {
                            Message = String.Format("Oops! something bad happened during the AJAX call. Please contact support and provide the following REF:{0}", errorRef)
                            //filterContext.Exception.Message
                            //,filterContext.Exception.StackTrace
                        }
                    };
                    filterContext.ExceptionHandled = true;
                }
                else
                {
                    base.OnException(filterContext);
                }
            }
        }

        private bool IsJsonRequest(ExceptionContext filterContext)
        {
            string requestedWith = filterContext.RequestContext.HttpContext.Request.ServerVariables["HTTP_X_REQUESTED_WITH"] ?? string.Empty;
            return string.Compare(requestedWith, "XMLHttpRequest", true) == 0
                && filterContext.RequestContext.HttpContext.Request.ContentType.ToLower().Contains("application/json");
        }

        private string GetErrorRef()
        {
            // Return the current date time Hexdecimal value as error ref
            return DateTime.Now.Ticks.ToString("X2");
        }

        private void LogException(ExceptionContext filterContext, string errorRef)
        {
            string errorMsg = String.Format("\r\nUnhandled exception:\r\nREF:{0} - USER: {1} - SOURCE: {2} - PATH: {3}",
                errorRef,
                filterContext.HttpContext.User.Identity.IsAuthenticated ? filterContext.HttpContext.User.Identity.Name : "Not Authenticated User",
                filterContext.Controller.GetType().ToString(),
                filterContext.RequestContext.HttpContext.Request.Path
            );

            if (filterContext.Exception != null && filterContext.Exception is SecurityException)
                log.Warn(errorMsg, filterContext.Exception);
            else
                log.Error(errorMsg, filterContext.Exception);
        }

    }

}
