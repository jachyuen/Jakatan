﻿using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess
{
    public class ConnectionInfo
    {
        private string _connectionString;
        private string _providerName;
        private UserImpersonation _impersonation;

        /// <summary>
        /// Initialize using connection string and provider name.
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="providerName"></param>
        public ConnectionInfo(string connectionString, string providerName)
            : this(connectionString, providerName, null)
        {
        }

        public ConnectionInfo(string connectionString, string providerName, UserImpersonation userImpersonation)
        {
            _connectionString = connectionString;
            _providerName = providerName;
            _impersonation = userImpersonation;
        }

        /// <summary>
        /// Get the connection string.
        /// </summary>
        public string ConnectionString
        {
            get { return _connectionString; }
        }


        /// <summary>
        /// THe name of the database provider. e.g. "System.Data.SqlClient"
        /// </summary>
        public string ProviderName
        {
            get { return _providerName; }
        }


        /// <summary>
        /// The impersonation instance used to connect to DB.
        /// </summary>
        public UserImpersonation Impersonation
        {
            get
            {
                return _impersonation;
            }
            set
            {
                _impersonation = value;
            }
        }
    }
}
