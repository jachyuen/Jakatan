﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Entity
{
    public interface IEntityPersistantViewModel<TId>
    {
        /// <summary>
        /// Get the id of a persistant entity.
        /// </summary>
        TId Id { get; set; }
    }

    /// <summary>
    /// Persistant entity 
    /// </summary>
    public interface IEntityPersistant<TId>
    {
        /// <summary>
        /// Get the id of a persistant entity.
        /// </summary>
        TId Id { get; set; }


        /// <summary>
        /// Determines whether this instance is persistant.
        /// </summary>
        /// <returns>
        /// 	<c>true</c> if this instance is persistant; otherwise, <c>false</c>.
        /// </returns>
        bool IsPersistant();
    }

    /// <summary>
    /// Auditable entity.
    /// This interface is meant to provide auditing features to
    /// any entity/domain object.
    /// When changing the data model, at times it important to know.
    /// 1. who made a change.
    /// 2. when the change was made.
    /// 3. who created it.
    /// 4. what version it is.
    /// </summary>
    public interface IEntityAuditable
    {
        /// <summary>
        /// Date the entity was created.
        /// </summary>
        DateTime? CreateDate { get; set; }


        /// <summary>
        /// User who first created this entity.
        /// </summary>
        string CreateUser { get; set; }


        /// <summary>
        /// Date the entitye was updated.
        /// </summary>
        DateTime? UpdateDate { get; set; }


        /// <summary>
        /// User who last updated the entity.
        /// </summary>
        string UpdateUser { get; set; }
    }

    public interface IEntityAuditableWithComment : IEntityAuditable
    {
        /// <summary>
        /// Comment used for updates.
        /// </summary>
        string UpdateComment { get; set; }
    }

    /// <summary>
    /// Entity interface.
    /// </summary>
    public interface IEntity : IEntityPersistant<int>, IEntityAuditable
    { }

    public interface IEntity<TId> : IEntityPersistant<TId>, IEntityAuditable
    { }

    public interface IEntityViewModel : IEntityPersistantViewModel<int>, IEntityAuditable
    { }

    public interface IEntityViewModel<TId> : IEntityPersistantViewModel<TId>, IEntityAuditable
    { }
}
