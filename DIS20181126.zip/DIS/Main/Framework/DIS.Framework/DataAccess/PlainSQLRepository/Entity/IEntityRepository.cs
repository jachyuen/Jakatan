﻿using DIS.Framework.DataAccess.PlainSQLRepository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Entity
{
    //public interface IEntityRepository<T> : IRepository<T>, IRepositoryConfigurable
    public interface IEntityRepository<T> : IEntityRepository<T, int>
    {
    }

    public interface IEntityRepository<T, TId> : IRepositoryWithId<TId, T>, IRepositoryConfigurable
    {
        IEntityRowMapper<T> RowMapper { get; set; }
    }
}
