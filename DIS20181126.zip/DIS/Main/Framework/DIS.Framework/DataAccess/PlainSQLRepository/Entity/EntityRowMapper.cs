﻿using DIS.Framework.DataAccess.PlainSQLRepository.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Entity
{
    public abstract class EntityRowMapper<T> : RowMapperReaderBased<T>, IEntityRowMapper<T>
    {
    }
}
