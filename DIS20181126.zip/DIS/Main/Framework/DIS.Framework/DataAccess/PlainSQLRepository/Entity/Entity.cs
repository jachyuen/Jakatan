﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Entity
{
    public abstract class Entity : EntityPersistantAuditable<int>, IEntity
    {
    }

    public abstract class EntityViewModel : EntityPersistantAuditableViewModel<int>, IEntityViewModel
    {
    }

    public abstract class EntityPersistantAuditable<TId> : EntityPersistant<TId>, IEntityAuditable
    {
        #region IEntityAuditable Members
        /// <summary>
        /// Create datetime.
        /// </summary>
        public DateTime? CreateDate { get; set; }


        /// <summary>
        /// User who first created this entity.
        /// </summary>
        public string CreateUser { get; set; }


        /// <summary>
        /// Update date time
        /// </summary>
        public DateTime? UpdateDate { get; set; }


        /// <summary>
        /// User updating the value
        /// </summary>
        public string UpdateUser { get; set; }


        /// <summary>
        /// Indicates whether or not this entity is active,
        /// meaning that it is just stored in the database for historic
        /// record keeping/versioning.
        /// </summary>
        //public bool IsActive { get; set; }


        /// <summary>
        /// The version number of the persistant entity.
        /// </summary>
        //public int Version { get; set; }


        /// <summary>
        /// Comment to describe any updates to entity.
        /// </summary>
        //public string UpdateComment { get; set; }
        #endregion
    }

    public abstract class EntityPersistantAuditableViewModel<TId> : EntityPersistantViewModel<TId>, IEntityAuditable
    {
        #region IEntityAuditable Members
        /// <summary>
        /// Create datetime.
        /// </summary>
        public virtual DateTime? CreateDate { get; set; }


        /// <summary>
        /// User who first created this entity.
        /// </summary>
        public virtual string CreateUser { get; set; }


        /// <summary>
        /// Update date time
        /// </summary>
        public virtual DateTime? UpdateDate { get; set; }


        /// <summary>
        /// User updating the value
        /// </summary>
        public virtual string UpdateUser { get; set; }
        #endregion
    }

    public abstract class EntityPersistant<TId> : IEntityPersistant<TId>
    {
        #region IEntityPersistant<TId> Members

        /// <summary>
        /// Get the id of a persistant entity.
        /// </summary>
        /// <value></value>
        public virtual TId Id { get; set; }


        /// <summary>
        /// Determines whether this instance is persistant.
        /// </summary>
        /// <returns>
        /// 	<c>true</c> if this instance is persistant; otherwise, <c>false</c>.
        /// </returns>
        public virtual bool IsPersistant()
        {
            return (Id != null && !Id.Equals(default(TId)));
        }

        #endregion
    }

    public abstract class EntityPersistantViewModel<TId> : IEntityPersistantViewModel<TId>
    {
        public virtual TId Id { get; set; }
    }
}
