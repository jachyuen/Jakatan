﻿using DIS.Framework.DataAccess.PlainSQLRepository.DB;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Repository
{
    public interface IRepository<T> : IRepositoryWithId<int, T>
    { }

    /// <summary>
    /// 
    /// </summary>
    public interface IRepositoryConfigurable
    {
        /// <summary>
        /// Gets or sets the db helper.
        /// </summary>
        /// <value>The helper.</value>
        IDBHelper DbHelper { get; set; }


        /// <summary>
        /// Gets or sets the connection.
        /// </summary>
        /// <value>The connection.</value>
        ConnectionInfo Connection { get; set; }


        /// <summary>
        /// Gets the connection STR.
        /// </summary>
        /// <value>The connection STR.</value>
        string ConnectionString { get; }
    }



    /// <summary>
    /// Interface for a DAO(Data Access Object) to support CRUD operations.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <typeparam name="IdT"></typeparam>
    public interface IRepositoryWithId<TId, T>
    {

        #region Retrieve methods.
        /// <summary>
        /// Retrieve the entity by it's key/id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        T Get(TId id);


        /// <summary>
        /// Retrieve all the entities.
        /// </summary>
        /// <returns></returns>
        IList<T> GetAll();


        /// <summary>
        /// Retrieve all the entities into a non-generic list.
        /// </summary>
        /// <returns></returns>
        IList GetAllItems();


        /// <summary>
        /// Get items by page
        /// </summary>
        /// <param name="table">"Blogposts"</param>
        /// <param name="pageNumber">1</param>
        /// <param name="pageSize">15 ( records per page )</param>
        /// <param name="totalPages"> Total number of pages found</param>
        /// <param name="totalRecords">Total number of records found.</param>
        /// <returns></returns>
        IList<T> GetByFilter(string filter, string table, int pageNumber, int pageSize, ref int totalRecords);


        /// <summary>
        /// Get items by page
        /// </summary>
        /// <param name="table">"Blogposts"</param>
        /// <param name="pageNumber">1</param>
        /// <param name="pageSize">15 ( records per page )</param>
        /// <param name="totalPages"> Total number of pages found</param>
        /// <param name="totalRecords">Total number of records found.</param>
        /// <returns></returns>
        IList<T> GetRecent(string table, int pageNumber, int pageSize, ref int totalRecords);
        #endregion


        #region Find methods
        /// <summary>
        /// Find by query
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        IList<T> Find(string queryString);


        /// <summary>
        /// Find by query string and single parameter value.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        IList<T> Find(string queryString, object value);


        /// <summary>
        /// Find by query and multiple parameter values.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        IList<T> Find(string queryString, object[] values);


        /// <summary>
        /// Finds the entities by the query.
        /// </summary>
        /// <param name="queryString">Query text.</param>
        /// <param name="isFullSql">Indicate if text supplied is a full sql or just 
        /// clause after the where.</param>
        /// <returns></returns>
        IList<T> FindByQuery(string queryString, bool isFullSql);

        /// <summary>
        /// Find by query with paging support
        /// </summary>
        /// <param name="queryString">The query, this can be either just a filter
        /// after the where clause or the entire sql</param>
        /// <param name="isFullSql"></param>
        /// <param name="displayStart">1 based. the start row number of records to be returned</param>
        /// <param name="displayLength">how many row of data to be returned</param>
        /// <param name="sortBy">database column name that is used to sort records, default sort by IDColumn</param>
        /// <param name="sortDir">sorting direction: asc, desc. default asc, if sortBy is present</param>
        /// <returns></returns>
        IList<T> FindByQueryWithPaging(string queryString, bool isFullSql, int displayStart, int displayLength,
                                                        String sortBy, String sortDir);

        IList<T> FindByQueryWithPagingOracle(string queryString, bool isFullSql, int displayStart, int displayLength,
                                                String sortBy, String sortDir);

        #endregion


        #region Save/Delete methods
        /// <summary>
        /// Create an entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        T Create(T entity);


        /// <summary>
        /// UPdate the entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        T Update(T entity);


        /// <summary>
        /// Delete the entity.
        /// </summary>
        /// <param name="entity"></param>
        void DeleteByEntity(T entity);


        /// <summary>
        /// Delete the entitiy by it's key/id.
        /// </summary>
        /// <param name="id"></param>
        void Delete(TId id);


        /// <summary>
        /// Create or update an entity.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        T Save(T entity);
        #endregion
    }
}
