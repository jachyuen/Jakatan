﻿using DIS.Framework.DataAccess.PlainSQLRepository.DB;
using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using DIS.Framework.DataAccess.PlainSQLRepository.Helpers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Repository
{
    //public class RepositorySql<T> : RepositoryBase<T, int>, IEntityRepository<T> where T : IEntityPersistant<int>
    public class RepositorySql<T> : RepositorySql<T, int> where T : IEntityPersistant<int>
    {
        /// <summary>
        /// Initialize
        /// </summary>
        public RepositorySql() : base()
        {
        }

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositorySql(ConnectionInfo connectionInfo) : base(connectionInfo)
        {
        }

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositorySql(ConnectionInfo connectionInfo, IDBHelper helper) : base(connectionInfo, helper)
        {
        }
    }

    public class RepositorySql<T, TId> : RepositoryBase<T, TId>, IEntityRepository<T, TId> where T : IEntityPersistant<TId>
    {
        private string _tableName;
        private string _idName;

        /// <summary>
        /// Initialize
        /// </summary>
        public RepositorySql()
        {
            Init(null, null);
        }

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositorySql(ConnectionInfo connectionInfo)
        {
            IDBHelper helper = new DBHelper(connectionInfo);
            Init(connectionInfo, helper);
        }

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public RepositorySql(ConnectionInfo connectionInfo, IDBHelper helper)
        {
            Init(connectionInfo, helper);
        }

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <param name="helper"></param>
        public void Init(ConnectionInfo connectionInfo, IDBHelper helper)
        {
            _connectionInfo = connectionInfo;
            _db = helper;
            _tableName = typeof(T).Name + "s";
            _idName = "Id";
        }

        /// <summary>
        /// Get / Set the table name.
        /// </summary>
        public string TableName
        {
            get { return _tableName; }
            set { _tableName = value; }
        }

        /// <summary>
        /// Get / Set the table ID name.
        /// </summary>
        public string IDName
        {
            get { return _idName; }
            set { _idName = value; }
        }

        #region IDaoWithKey<int,T> Members
        /// <summary>
        /// Create the entity in the datastore.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public override T Create(T entity)
        {
            return entity;
        }

        /// <summary>
        /// Update the entity in the datastore.
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public override T Update(T entity)
        {
            return entity;
        }

        /// <summary>
        /// Get item by id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual T Get(TId id)
        {
            string sql = string.Format("select * from {0} where {1} = {2}", TableName, IDName, id);
            IList<T> result = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            if (result == null || result.Count == 0)
                return default(T);

            return result[0];
        }

        /// <summary>
        /// Get all the entities from the datastore.
        /// </summary>
        /// <returns></returns>
        public virtual IList<T> GetAll()
        {
            string sql = string.Format("select * from {0} ", TableName);
            IList<T> result = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return result;
        }

        /// <summary>
        /// Get all the items.
        /// </summary>
        /// <returns></returns>
        public virtual System.Collections.IList GetAllItems()
        {
            ArrayList list = new ArrayList();
            IList<T> allItems = GetAll();
            foreach (T item in allItems)
                list.Add(item);

            return list;
        }

        /// <summary>
        /// Get page of records using filter.
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="table"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public virtual IList<T> GetByFilter(string filter, string table, int pageNumber, int pageSize, ref int totalRecords)
        {
            string procName = table + "_GetByFilter";
            List<DbParameter> dbParams = new List<DbParameter>();
            dbParams.Add(DbHelper.BuildInParam("@Filter", System.Data.DbType.String, filter));
            dbParams.Add(DbHelper.BuildInParam("@PageIndex", System.Data.DbType.Int32, pageNumber));
            dbParams.Add(DbHelper.BuildInParam("@PageSize", System.Data.DbType.Int32, pageSize));
            dbParams.Add(DbHelper.BuildOutParam("@TotalRows", System.Data.DbType.Int32));

            Tuple2<IList<T>, IDictionary<string, object>> result = DbHelper.Query<T>(
                procName, System.Data.CommandType.StoredProcedure, dbParams.ToArray(), _rowMapper, new string[] { "@TotalRows" });

            // Set the total records.
            totalRecords = (int)result.Second["@TotalRows"];
            return result.First;
        }

        /// <summary>
        /// Get recents posts by page
        /// </summary>
        /// <param name="table"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public virtual IList<T> GetRecent(string table, int pageNumber, int pageSize, ref int totalRecords)
        {
            string procName = table + "_GetRecent";
            List<DbParameter> dbParams = new List<DbParameter>();

            // Build input params to procedure.
            dbParams.Add(DbHelper.BuildInParam("@PageIndex", System.Data.DbType.Int32, pageNumber));
            dbParams.Add(DbHelper.BuildInParam("@PageSize", System.Data.DbType.Int32, pageSize));
            dbParams.Add(DbHelper.BuildOutParam("@TotalRows", System.Data.DbType.Int32));

            Tuple2<IList<T>, IDictionary<string, object>> result = DbHelper.Query<T>(
                procName, System.Data.CommandType.StoredProcedure, dbParams.ToArray(), _rowMapper, new string[] { "@TotalRows" });

            // Set the total records.
            totalRecords = (int)result.Second["@TotalRows"];
            return result.First;
        }


        /// <summary>
        /// Find all records matching the query string.
        /// </summary>
        /// <param name="queryString"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString)
        {
            return FindByQuery(queryString, true);
        }


        /// <summary>
        /// Find by the sql using the single parameter value.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString, object value)
        {
            string filter = string.Format(queryString, value);
            return FindByQuery(filter, true);
        }


        /// <summary>
        /// Find by sql text using the parameters supplied.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="values"></param>
        /// <returns></returns>
        public virtual IList<T> Find(string queryString, object[] values)
        {
            string filter = string.Format(queryString, values);
            return FindByQuery(filter, true);
        }


        /// <summary>
        /// Find by filter.
        /// </summary>
        /// <param name="queryString">The query, this can be either just a filter
        /// after the where clause or the entire sql</param>
        /// <returns></returns>
        public virtual IList<T> FindByQuery(string queryString, bool isFullSql)
        {
            string sql = queryString;
            if (!isFullSql)
            {
                string tableName = this.TableName;
                queryString = string.IsNullOrEmpty(queryString) ? string.Empty : " where " + queryString;
                sql = "select * from " + tableName + " " + queryString;
            }
            IList<T> results = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return results;
        }

        /// <summary>
        /// Find by query with paging support
        /// </summary>
        /// <param name="queryString">The query, this can be either just a filter
        /// after the where clause or the entire sql</param>
        /// <param name="isFullSql"></param>
        /// <param name="displayStart">1 based. the start row number of records to be returned</param>
        /// <param name="displayLength">how many row of data to be returned</param>
        /// <param name="sorBy">A Dictionary with key value pair on sorting column name and sorting direction</param>
        /// <returns></returns>
        public virtual IList<T> FindByQueryWithPaging(string queryString, bool isFullSql, int displayStart, int displayLength,
                                                        IDictionary<string, string> sortBy)
        {
            if (!isFullSql)
            {
                queryString = string.IsNullOrEmpty(queryString) ? string.Empty : " where " + queryString;
                queryString = "select * from " + this.TableName + " " + queryString;
            }

            //sortBy = string.IsNullOrEmpty(sortBy) ? this.IDName : sortBy;
            //sortDir = string.IsNullOrEmpty(sortDir) ? "asc" : sortDir;

            string sql = String.Format(@"select * 
                                        from (
	                                        select row_number() OVER (order by {0}) as rowNum, * 
	                                        from 
	                                        (
		                                        {1}
	                                        ) tempResult
                                        ) tempResult
                                        where rowNum Between {2} and {3}", string.Join(",", sortBy.Select(x => x.Key + ' ' + x.Value).ToArray()), queryString, displayStart, displayStart + displayLength - 1);                // -1 because displayStart is 1 based.

            IList<T> results = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return results;
        }

        /// <summary>
        /// Find by query with paging support
        /// </summary>
        /// <param name="queryString">The query, this can be either just a filter
        /// after the where clause or the entire sql</param>
        /// <param name="isFullSql"></param>
        /// <param name="displayStart">1 based. the start row number of records to be returned</param>
        /// <param name="displayLength">how many row of data to be returned</param>
        /// <param name="sortBy">database column name that is used to sort records, default sort by IDColumn</param>
        /// <param name="sortDir">sorting direction: asc, desc. default asc, if sortBy is present</param>
        /// <returns></returns>
        public virtual IList<T> FindByQueryWithPaging(string queryString, bool isFullSql, int displayStart, int displayLength,
                                                        String sortBy, String sortDir)
        {
            if (!isFullSql)
            {
                queryString = string.IsNullOrEmpty(queryString) ? string.Empty : " where " + queryString;
                queryString = "select * from " + this.TableName + " " + queryString;
            }

            sortBy = string.IsNullOrEmpty(sortBy) ? this.IDName : sortBy;
            sortDir = string.IsNullOrEmpty(sortDir) ? "asc" : sortDir;

            string sql = String.Format(@"select * 
                                        from (
	                                        select row_number() OVER (order by {0} {1}) as rowNum, * 
	                                        from 
	                                        (
		                                        {2}
	                                        ) tempResult
                                        ) tempResult
                                        where rowNum Between {3} and {4}", sortBy, sortDir, queryString, displayStart, displayStart + displayLength - 1);                // -1 because displayStart is 1 based.

            IList<T> results = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return results;
        }

        public virtual IList<T> FindByQueryWithPagingOracle(string queryString, bool isFullSql, int displayStart, int displayLength,
                                                String sortBy, String sortDir)
        {
            if (!isFullSql)
            {
                queryString = string.IsNullOrEmpty(queryString) ? string.Empty : " where " + queryString;
                queryString = "select * from " + this.TableName + " " + queryString;
            }

            sortBy = string.IsNullOrEmpty(sortBy) ? this.IDName : sortBy; // or use "1" instead of this.IDName for Oracle
            sortDir = string.IsNullOrEmpty(sortDir) ? "asc" : sortDir;

            string sql = String.Format(@"select *
from (
	select a.*, rownum rnum
	from (
		{2}
		order by {0} {1}, rowid
	) a
	where rownum <= {4}
)
where rnum >= {3}", sortBy, sortDir, queryString, displayStart, displayStart + displayLength - 1);                // -1 because displayStart is 1 based.

            IList<T> results = _db.QueryNoParams<T>(sql, CommandType.Text, RowMapper);
            return results;
        }

        /// <summary>
        /// Delete by the entity id.
        /// </summary>
        /// <param name="id"></param>
        public override void Delete(TId id)
        {
            string sql = string.Format("delete from {0} where {1} = {2}", TableName, IDName, id);
            _db.ExecuteNonQueryText(sql, null);
        }
        #endregion
    }
}
