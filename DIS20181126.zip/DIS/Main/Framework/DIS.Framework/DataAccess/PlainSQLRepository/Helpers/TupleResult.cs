﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.Helpers
{
    public struct Tuple2<T1, T2>
    {
        private readonly T1 _first;
        /// <summary>
        /// The first item of the tuple
        /// </summary>
        public T1 First
        {
            get { return _first; }
        }


        private readonly T2 _second;
        /// <summary>
        /// The second item of the tuple
        /// </summary>
        public T2 Second
        {
            get { return _second; }
        }


        /// <summary>
        /// Initialize the tuple items.
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        public Tuple2(T1 first, T2 second)
        {
            _first = first;
            _second = second;
        }
    }



    public struct Tuple3<T1, T2, T3>
    {
        private readonly T1 _first;
        /// <summary>
        /// The first item of the tuple
        /// </summary>
        public T1 First
        {
            get { return _first; }
        }


        private readonly T2 _second;
        /// <summary>
        /// The second item of the tuple
        /// </summary>
        public T2 Second
        {
            get { return _second; }
        }


        private readonly T3 _third;
        /// <summary>
        /// The second item of the tuple
        /// </summary>
        public T3 Third
        {
            get { return _third; }
        }


        /// <summary>
        /// Initialize the tuple items.
        /// </summary>
        /// <param name="first"></param>
        /// <param name="second"></param>
        public Tuple3(T1 first, T2 second, T3 third)
        {
            _first = first;
            _second = second;
            _third = third;
        }
    }
}
