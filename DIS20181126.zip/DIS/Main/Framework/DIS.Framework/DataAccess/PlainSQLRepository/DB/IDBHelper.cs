﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.DB
{
    public interface IDBHelper
    {
        /// <summary>
        /// The underlying connection to the datastore.
        /// </summary>
        ConnectionInfo Connection { get; set; }

        /// <summary>
        /// Initialize the injected DbHelper with parameters
        /// </summary>
        /// <param name="connection">Connection definition</param>
        /// <param name="settings">Database settings</param>
        /// <param name="factory">Factory use to create objects</param>
        void Init(ConnectionInfo connection, DbSettings settings);

        /// <summary>
        /// Core method which all the 
        /// 1. ExecuteScalar
        /// 2. ExecuteNonQuery
        /// 3. ExecuteReader
        /// 4. ExecuteDataTable methods call.
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <param name="dbParameters"></param>
        /// <param name="useTransaction"></param>
        /// <param name="executor"></param>
        /// <returns></returns>
        TResult Execute<TResult>(string commandText, CommandType commandType, DbParameter[] dbParameters, bool useTransaction, Func<DbCommand, TResult> executor);
        TResult Execute<TResult>(string commandText, CommandType commandType, int sqlTimeout, DbParameter[] dbParameters, bool useTransaction, Func<DbCommand, TResult> executor);

        /// <summary>
        /// Execute non-query sql.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        int ExecuteNonQuery(string commandText, CommandType commandType, params DbParameter[] dbParameters);
        int ExecuteNonQuery(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute non-query sql.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        int ExecuteNonQueryText(string commandText, params DbParameter[] dbParameters);
        int ExecuteNonQueryText(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute non-query sql.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        int ExecuteNonQueryProc(string commandText, params DbParameter[] dbParameters);
        int ExecuteNonQueryProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datareader.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        IDataReader ExecuteReader(string commandText, CommandType commandType, params DbParameter[] dbParameters);
        IDataReader ExecuteReader(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datareader.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        IDataReader ExecuteReaderText(string commandText, params DbParameter[] dbParameters);
        IDataReader ExecuteReaderText(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datareader.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        IDataReader ExecuteReaderProc(string commandText, params DbParameter[] dbParameters);
        IDataReader ExecuteReaderProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return single scalar value.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        object ExecuteScalar(string commandText, CommandType commandType, params DbParameter[] dbParameters);
        object ExecuteScalar(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return single scalar value.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        object ExecuteScalarText(string commandText, params DbParameter[] dbParameters);
        object ExecuteScalarText(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return single scalar value.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        object ExecuteScalarProc(string commandText, params DbParameter[] dbParameters);
        object ExecuteScalarProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return dataset.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataSet ExecuteDataSet(string commandText, CommandType commandType, params DbParameter[] dbParameters);
        DataSet ExecuteDataSet(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return dataset.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataSet ExecuteDataSetText(string commandText, params DbParameter[] dbParameters);
        DataSet ExecuteDataSetText(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return dataset.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataSet ExecuteDataSetProc(string commandText, params DbParameter[] dbParameters);
        DataSet ExecuteDataSetProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datatable
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataTable ExecuteDataTable(string commandText, CommandType commandType, params DbParameter[] dbParameters);
        DataTable ExecuteDataTable(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datatable
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataTable ExecuteDataTableText(string commandText, params DbParameter[] dbParameters);
        DataTable ExecuteDataTableText(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Execute sql and return datatable
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DataTable ExecuteDataTableProc(string commandText, params DbParameter[] dbParameters);
        DataTable ExecuteDataTableProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters);


        /// <summary>
        /// Build an input parameter.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        DbParameter BuildInParam(string paramName, DbType dbType, object val);


        /// <summary>
        /// Build an input parameter.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        DbParameter BuildOutParam(string paramName, DbType dbType);


        /// <summary>
        /// Get a connection to the appropriate database.
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <returns></returns>
        DbConnection GetConnection();


        /// <summary>
        /// Create a new IDbCommand using the connection.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commmandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        DbCommand GetCommand(DbConnection con, string commmandText, CommandType commandType);
    }
}
