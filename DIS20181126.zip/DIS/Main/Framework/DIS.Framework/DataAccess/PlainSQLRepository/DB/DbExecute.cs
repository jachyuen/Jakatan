﻿using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.DB
{
    public static class DbExecute
    {
        /// <summary>
        /// Execute a non-query with a single output value.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText">E.g. Storedprocedure : Posts_DeleteExpired</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="outputParamName">The name of the output parameter. E.g. @TotalRows</param>
        /// <param name="dbParameters">Input parameters.</param>
        /// <returns></returns>
        public static T Execute<T>(this IDBHelper dbHelper, string commandText, CommandType commandType, DbParameter[] dbParameters, string outputParamName)
        {
            IDictionary<string, object> results = Execute(dbHelper, commandText, commandType, dbParameters, new string[] { outputParamName });
            return (T)results[outputParamName];
        }


        /// <summary>
        /// Execute a non-query with a single input parameter.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="commandText">E.g. Storedprocedure : Posts_DeleteByUser</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="paramName">E.g. "@UserName"</param>
        /// <param name="paramType">E.g. DbType.String</param>
        /// <param name="paramValue">E.g. "kreddy"</param>
        /// <returns></returns>
        public static int Execute(this IDBHelper dbHelper, string commandText, CommandType commandType, string paramName, DbType paramType, object paramValue)
        {
            DbParameter parameter = dbHelper.BuildInParam(paramName, paramType, paramValue);
            return dbHelper.ExecuteNonQuery(commandText, CommandType.StoredProcedure, parameter);
        }


        /// <summary>
        /// Executes the non-query and returns a dictionary of all the output parameters.
        /// </summary>
        /// <param name="dbHelper"></param>
        /// <param name="commandText">StoredProc : Posts_PerformActivation</param>
        /// <param name="commandType">StoredProc</param>
        /// <param name="dbParameters">Array of all input parameters to the proc.</param>
        /// <param name="outputParamNames">Array of output parameter names.
        /// e.g. "@TotalRecordsUpdated", @TotalProductTypesUpdated"</param>
        /// <returns></returns>
        public static IDictionary<string, object> Execute(this IDBHelper dbHelper, string commandText, CommandType commandType,
            DbParameter[] dbParameters, string[] outputParamNames)
        {
            DbConnection connection = dbHelper.GetConnection();
            DbCommand command = dbHelper.GetCommand(connection, commandText, CommandType.StoredProcedure);

            // Check if parameters supplied.
            if (dbParameters != null && dbParameters.Length > 0)
            {
                foreach (DbParameter p in dbParameters)
                {
                    if (p != null)
                        command.Parameters.Add(p);
                }
            }

            // Create list of parameter results.
            IDictionary<string, object> outputResults = new Dictionary<string, object>();

            using (connection)
            {
                if (dbHelper.Connection.Impersonation == null)
                    connection.Open();
                else
                {
                    IExecuteHelper exHelper = Singleton<IDISHost>.Instance.Resolve<IExecuteHelper>();
                    exHelper.RunAs(dbHelper.GetType(), dbHelper.Connection.Impersonation, () => connection.Open());
                }

                int queryResult = command.ExecuteNonQuery();

                // Get each output parameter name.
                for (int ndx = 0; ndx < outputParamNames.Length; ndx++)
                {
                    string outputParamName = outputParamNames[ndx];
                    object outputResult = command.Parameters[outputParamName];
                    outputResults[outputParamName] = outputResult;
                }
                command.Dispose();
            }
            return outputResults;
        }
    }
}
