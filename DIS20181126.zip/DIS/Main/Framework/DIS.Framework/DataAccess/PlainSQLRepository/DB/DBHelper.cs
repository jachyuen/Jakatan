﻿using DIS.Framework.Security;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.DB
{
    public class DBHelper : IDBHelper
    {
        protected ConnectionInfo _connection;
        protected DbProviderFactory _factory;
        protected bool _createFactory = true;
        protected DbSettings _settings;
        protected IExecuteHelper _exHelper;
        protected int defaultTimeout = 1800;

        protected ILog _log;

        /// <summary>
        /// Initialize
        /// </summary>
        /// <param name="connection"></param>
        public DBHelper(ILog log,
            IExecuteHelper exHelper)
        {
            _log = log;
            _exHelper = exHelper;
        }

        public DBHelper(ConnectionInfo connection)
            : this(connection, new DbSettings())
        {
        }

        /// <summary>
        /// Initialize using connection.
        /// </summary>
        /// <param name="connection"></param>
        public DBHelper(ConnectionInfo connection, DbSettings settings)
        {
            Init(connection, settings);
        }


        /// <summary>
        /// Initialize this dbhelper.
        /// </summary>
        /// <param name="connection">The connection information.</param>
        /// <param name="settings">Optional settings for this instance of DbHelper.</param>
        /// <param name="factory">Optional instance of the provider factory.
        /// e.g. If using oracle, supply this as OracleClientFactory.Instance</param>
        public void Init(ConnectionInfo connection, DbSettings settings)
        {
            _connection = connection;
            _settings = settings == null ? new DbSettings() : settings;

            InitFactory();
        }


        /// <summary>
        /// Database settings
        /// </summary>
        public DbSettings Settings
        {
            get { return _settings; }
        }

        #region Public database execute methods
        /// <summary>
        /// Execute the datareader.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// IDataReader = db.ExecuteReader("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public IDataReader ExecuteReaderText(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteReader(commandText, CommandType.Text, dbParameters);
        }
        public IDataReader ExecuteReaderText(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteReader(commandText, CommandType.Text, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Execute the datareader.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// IDataReader = db.ExecuteReader("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public IDataReader ExecuteReaderProc(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteReader(commandText, CommandType.StoredProcedure, dbParameters);
        }
        public IDataReader ExecuteReaderProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteReader(commandText, CommandType.StoredProcedure, sqlTimeout, dbParameters);
        }

        /// <summary>
        /// Execute the datareader.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// IDataReader = db.ExecuteReader("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public IDataReader ExecuteReader(string commandText, CommandType commandType, params DbParameter[] dbParameters)
        {
            return Execute<IDataReader>(commandText, commandType, dbParameters, command => command.ExecuteReader());
        }
        public IDataReader ExecuteReader(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return Execute<IDataReader>(commandText, commandType, sqlTimeout, dbParameters, false, command => command.ExecuteReader());
        }


        /// <summary>
        /// Executes a non-query using sql text
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.ExecuteNonQuery("update users set isactive =1", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public int ExecuteNonQueryText(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteNonQuery(commandText, CommandType.Text, dbParameters);
        }
        public int ExecuteNonQueryText(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteNonQuery(commandText, CommandType.Text, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes a non-query using command
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.ExecuteNonQuery("update users set isactive =1", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public int ExecuteNonQueryProc(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteNonQuery(commandText, CommandType.StoredProcedure, dbParameters);
        }
        public int ExecuteNonQueryProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteNonQuery(commandText, CommandType.StoredProcedure, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes a non-query using command
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.ExecuteNonQuery("update users set isactive =1", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public int ExecuteNonQuery(string commandText, CommandType commandType, params DbParameter[] dbParameters)
        {
            return Execute<int>(commandText, commandType, dbParameters, command => { return command.ExecuteNonQuery(); });
        }
        public int ExecuteNonQuery(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return Execute<int>(commandText, commandType, sqlTimeout, dbParameters, false, command => { return command.ExecuteNonQuery(); });
        }


        /// <summary>
        /// Executes a scalar query using sql text.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// object obj = db.ExecuteScalar("select count(*) from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public object ExecuteScalarText(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteScalar(commandText, CommandType.Text, dbParameters);
        }
        public object ExecuteScalarText(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteScalar(commandText, CommandType.Text, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes a scalar query using a stored procedure.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// object obj = db.ExecuteScalar("select count(*) from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public object ExecuteScalarProc(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteScalar(commandText, CommandType.StoredProcedure, dbParameters);
        }
        public object ExecuteScalarProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteScalar(commandText, CommandType.StoredProcedure, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes a scalar query.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// object obj = db.ExecuteScalar("select count(*) from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public object ExecuteScalar(string commandText, CommandType commandType, params DbParameter[] dbParameters)
        {
            return Execute<object>(commandText, commandType, dbParameters, command => command.ExecuteScalar());
        }
        public object ExecuteScalar(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return Execute<object>(commandText, commandType, sqlTimeout, dbParameters, false, command => command.ExecuteScalar());
        }


        /// <summary>
        /// executes
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataTable tbl = db.ExecuteDataTable("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataTable ExecuteDataTableText(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.Text, dbParameters).Tables[0];
        }
        public DataTable ExecuteDataTableText(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.Text, sqlTimeout, dbParameters).Tables[0];
        }


        /// <summary>
        /// executes
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataTable tbl = db.ExecuteDataTable("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataTable ExecuteDataTableProc(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.StoredProcedure, dbParameters).Tables[0];
        }
        public DataTable ExecuteDataTableProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.StoredProcedure, sqlTimeout, dbParameters).Tables[0];
        }


        /// <summary>
        /// executes
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataTable tbl = db.ExecuteDataTable("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataTable ExecuteDataTable(string commandText, CommandType commandType, params DbParameter[] dbParameters)
        {
            return ExecuteDataTable(commandText, commandType, defaultTimeout, dbParameters);
        }
        public DataTable ExecuteDataTable(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return Execute<DataTable>(commandText, commandType, sqlTimeout, dbParameters, false,
                (command) =>
                {
                    IDataReader reader = command.ExecuteReader();
                    DataTable table = new DataTable();
                    table.Load(reader);

                    return table;
                });
        }


        /// <summary>
        /// Executes the stored proc command and returns a dataset.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataSet set = db.ExecuteDataSet("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataSet ExecuteDataSetText(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.Text, dbParameters);
        }
        public DataSet ExecuteDataSetText(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.Text, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes the stored proc command and returns a dataset.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataSet set = db.ExecuteDataSet("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataSet ExecuteDataSetProc(string commandText, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.StoredProcedure, dbParameters);
        }
        public DataSet ExecuteDataSetProc(string commandText, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, CommandType.StoredProcedure, sqlTimeout, dbParameters);
        }


        /// <summary>
        /// Executes the stored proc command and returns a dataset.
        /// </summary>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// DataSet set = db.ExecuteDataSet("select * from users", CommandType.Text, null);
        /// </example>
        /// <returns></returns>
        public DataSet ExecuteDataSet(string commandText, CommandType commandType, params DbParameter[] dbParameters)
        {
            return ExecuteDataSet(commandText, commandType, defaultTimeout, dbParameters);
        }
        public DataSet ExecuteDataSet(string commandText, CommandType commandType, int sqlTimeout, params DbParameter[] dbParameters)
        {
            return Execute<DataSet>(commandText, commandType, sqlTimeout, dbParameters, false,
                (command) =>
                {
                    DbDataAdapter adapter = _factory.CreateDataAdapter();
                    adapter.SelectCommand = command;
                    DataSet dataSet = new DataSet();
                    dataSet.Locale = CultureInfo.InvariantCulture;
                    adapter.Fill(dataSet);

                    return dataSet;
                });
        }
        #endregion


        #region Public getter/setters
        /// <summary>
        /// Get/Set the connection object.
        /// This is specifically made as a setter to
        /// 1. Allow dependency injection
        /// 2. Allow connections to multiple database with multiple instances of DbHelper.
        /// </summary>
        public ConnectionInfo Connection
        {
            get { return _connection; }
            set
            {
                _connection = value;

                // Set the DbFactory.
                InitFactory();
            }
        }
        #endregion


        #region public Connection helpers
        /// <summary>
        /// Create a connection to the database.
        /// </summary>
        /// <param name="connectionInfo"></param>
        /// <returns></returns>
        public DbConnection GetConnection()
        {
            DbConnection con = _factory.CreateConnection();
            con.ConnectionString = _connection.ConnectionString;

            return con;
        }


        /// <summary>
        /// Create a IDbCommand given the IDbConnection.
        /// </summary>
        /// <param name="con"></param>
        /// <param name="commmandText"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        public DbCommand GetCommand(DbConnection con, string commandText, CommandType commandType)
        {
            return GetCommand(con, commandText, commandType, defaultTimeout);
        }

        public DbCommand GetCommand(DbConnection con, string commandText, CommandType commandType, int commandTimeout)
        {
            DbCommand cmd = con.CreateCommand();
            //sDbCommand cmd = _factory.CreateCommand();
            cmd.Connection = con;
            cmd.CommandType = commandType;
            cmd.CommandText = commandText;
            cmd.CommandTimeout = commandTimeout;

            return cmd;
        }
        #endregion


        #region Database Parameter building
        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="direction"></param>
        /// <param name="ctx"></param>
        public DbParameter BuildInParam(string paramName, DbType dbType, object val)
        {
            // Parameter.
            DbParameter param = _factory.CreateParameter();
            param.ParameterName = paramName;
            param.DbType = dbType;
            param.Value = val;
            return param;
        }


        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="direction"></param>
        /// <param name="ctx"></param>
        public void BuildInParam(IList<DbParameter> parameters, string paramName, DbType dbType, object val)
        {
            parameters.Add(BuildInParam(paramName, dbType, val));
        }


        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="direction"></param>
        /// <param name="ctx"></param>
        public void BuildInParam(IList<DbParameter> parameters, DbParameter param, object val)
        {
            param.Value = val;
            parameters.Add(param);
        }


        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="direction"></param>
        /// <param name="ctx"></param>
        public DbParameter BuildOutParam(string paramName, DbType dbType)
        {
            // Parameter.
            DbParameter param = _factory.CreateParameter();
            param.ParameterName = paramName;
            param.DbType = dbType;
            param.Direction = ParameterDirection.Output;
            return param;
        }


        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>
        /// <param name="paramName"></param>
        /// <param name="dbType"></param>
        /// <param name="direction"></param>
        /// <param name="ctx"></param>
        public void BuildOutParam(IList<DbParameter> parameters, string paramName, DbType dbType)
        {
            parameters.Add(BuildOutParam(paramName, dbType));
        }


        /// <summary>
        /// Creates a DbParameter object from the arguments and adds it to the ctx command.
        /// </summary>        
        /// <param name="parameters">List of parameters.</param>
        /// <param name="dbParam"></param>
        public void BuildOutParam(IList<DbParameter> parameters, DbParameter dbParam)
        {
            dbParam.Direction = ParameterDirection.Output;
            parameters.Add(dbParam);
        }
        #endregion


        #region Execute Methods
        /// <summary>
        /// A template method to execute any command action.
        /// This is made virtual so that it can be extended to easily include Performance profiling.
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.Execute(int)("Users_GrantAccessToAllUsers", CommandType.StoredProcedure, 
        ///                               null, delegate(IDbCommand cmd) { cmd.ExecuteNonQuery(); } );
        /// </example>
        /// <returns></returns>
        public virtual TResult Execute<TResult>(string commandText, CommandType commandType, DbParameter[] dbParameters, Func<DbCommand, TResult> executor)
        {
            return Execute<TResult>(commandText, commandType, dbParameters, false, executor);
        }
        public virtual TResult Execute<TResult>(string commandText, CommandType commandType, int sqlTimeout, DbParameter[] dbParameters, Func<DbCommand, TResult> executor)
        {
            return Execute<TResult>(commandText, commandType, sqlTimeout, dbParameters, false, executor);
        }


        /// <summary>
        /// A template method to execute any command action that is Stored Procedure based.
        /// This is made virtual so that it can be extended to easily include Performance profiling.
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.Execute(int)("Users_GrantAccessToAllUsers", CommandType.StoredProcedure, 
        ///                               null, delegate(IDbCommand cmd) { cmd.ExecuteNonQuery(); } );
        /// </example>
        /// <returns></returns>
        public virtual TResult ExecuteProc<TResult>(string commandText, DbParameter[] dbParameters, Func<DbCommand, TResult> executor)
        {
            return Execute<TResult>(commandText, CommandType.StoredProcedure, dbParameters, false, executor);
        }


        public virtual TResult Execute<TResult>(string commandText, CommandType commandType, DbParameter[] dbParameters, bool useTransaction, Func<DbCommand, TResult> executor)
        {
            return Execute<TResult>(commandText, commandType, defaultTimeout, dbParameters, useTransaction, executor);
        }

        /// <summary>
        /// A template method to execute any command action.
        /// This is made virtual so that it can be extended to easily include Performance profiling.
        /// </summary>
        /// <typeparam name="TResult"></typeparam>
        /// <param name="commandText">Sql text or StoredProcedure Name. </param>
        /// <param name="commandType"><see cref="System.Data.CommandType"/></param>
        /// <param name="dbParameters">List of parameters</param>
        /// <example>
        /// DBHelper db = new DBHelper("connectionString value");
        /// int result = db.Execute(int)("Users_GrantAccessToAllUsers", CommandType.StoredProcedure, 
        ///                               null, delegate(IDbCommand cmd) { cmd.ExecuteNonQuery(); } );
        /// </example>
        /// <returns></returns>
        public virtual TResult Execute<TResult>(string commandText, CommandType commandType, int sqlTimeout, DbParameter[] dbParameters, bool useTransaction, Func<DbCommand, TResult> executor)
        {
            TResult result = default(TResult);
            DbConnection connection = _factory.CreateConnection();
            connection.ConnectionString = _connection.ConnectionString;

            using (connection)
            {
                // need to use impersonation if it is provided.
                if (_connection.Impersonation == null)
                {
                    connection.Open();
                }
                else
                {
                    _exHelper.RunAs(GetType(), _connection.Impersonation, () => connection.Open());
                }
                //DbCommand command = connection.CreateCommand();
                String dbParamStr = String.Empty;
                DbCommand command = _factory.CreateCommand();
                DbTransaction transaction = useTransaction ? connection.BeginTransaction() : null;
                command.Connection = connection;
                command.CommandType = commandType;
                command.CommandText = commandText;
                command.Transaction = transaction;
                command.CommandTimeout = sqlTimeout;
                if (dbParameters != null && dbParameters.Length > 0)
                {
                    foreach (DbParameter p in dbParameters)
                    {
                        if (p != null)
                        {
                            command.Parameters.Add(p);
                            dbParamStr += String.Format("{0}:{1}\r\n", p.ParameterName, p.Value);
                        }
                    }
                }

                //_log.Debug(string.Format("Execute on DB: {0}\r\nParameters:\r\n{1}", commandText, dbParamStr));
                result = executor(command);

                // Commit transaction if enabled.
                if (useTransaction) transaction.Commit();
            }
            return result;
        }



        /// <summary>
        /// Gets a single value from the reader and closes it after reading
        /// the value if the close is true.
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="close"></param>
        /// <returns></returns>
        public static object GetSingleValue(IDataReader reader, bool close)
        {
            reader.Read();
            object result = reader.GetValue(0);
            if (close) reader.Close();
            return result;
        }


        /// <summary>
        /// Initialize the database factory.
        /// </summary>
        protected void InitFactory()
        {
            if (_createFactory)
            {
                _factory = DbProviderFactories.GetFactory(_connection.ProviderName);
            }
        }

        #endregion

        #region Diagnostic
        public void ConnectionTest()
        {
            DbConnection connection = _factory.CreateConnection();
            connection.ConnectionString = _connection.ConnectionString;

            using (connection)
            {
                if (_connection.Impersonation == null)
                {
                    connection.Open();
                    connection.Close();
                }
                else
                {
                    _exHelper.RunAs(GetType(), _connection.Impersonation, () => connection.Open());
                    _exHelper.RunAs(GetType(), _connection.Impersonation, () => connection.Close());
                }
            }
        }
        #endregion
    }
}
