﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.DB
{
    public abstract class RowMapperTableBased<T> : RowMapperBase<DataTable, T, int>, IRowMapper<DataTable, T>
    {
        /// <summary>
        /// Maps all the rows using DataTable.
        /// </summary>
        /// <param name="table"></param>
        /// <returns></returns>
        public IList<T> MapRows(DataTable table)
        {
            IList<T> records = new List<T>();
            for (int ndx = 0; ndx < table.Rows.Count; ndx++)
            {
                T record = MapRow(table, ndx);
                records.Add(record);
            }
            return records;
        }
    }

    /// <summary>
    /// Abstract class for mapping a row from a DataReader.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class RowMapperReaderBased<T> : RowMapperBase<IDataReader, T, int>, IRowMapper<IDataReader, T>
    {
        /// <summary>
        /// Map all the rows to IList of objects T using DataReader
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        public IList<T> MapRows(IDataReader reader)
        {
            IList<T> records = new List<T>();
            int ndx = 0;
            while (reader.Read())
            {
                T record = MapRow(reader, ndx);
                records.Add(record);
                ndx++;
            }
            return records;
        }
    }



    /// <summary>
    /// Context used when mapping a row.
    /// </summary>
    /// <typeparam name="TSource"></typeparam>
    /// <typeparam name="TResult"></typeparam>
    /// <typeparam name="TRowId"></typeparam>
    public class RowMappingContext<TSource, TResult, TRowId>
    {
        /// <summary>
        /// Just used for contextual information at the moment.
        /// </summary>
        public bool IsRowIdStringBased;


        /// <summary>
        /// The Datasource. e.g. Xmldocument, Inidocument, Csvdocument.
        /// </summary>
        public TSource Source;


        /// <summary>
        /// The Row id, either a sting, int or some other object.
        /// </summary>
        public TRowId RowId;
    }



    /// <summary>
    /// Abstract class for row mapping.
    /// </summary>
    /// <typeparam name="TSource"></typeparam>
    /// <typeparam name="TResult"></typeparam>
    public abstract class RowMapperBase<TSource, TResult, TRowId>
    {
        /// <summary>
        /// Map the row number.
        /// </summary>
        /// <param name="source"></param>
        /// <param name="rowNumber"></param>
        /// <returns></returns>
        public abstract TResult MapRow(TSource source, TRowId rowNumber);
    }
}
