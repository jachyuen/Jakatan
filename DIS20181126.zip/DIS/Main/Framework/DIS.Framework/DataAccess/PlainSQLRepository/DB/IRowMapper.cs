﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.DataAccess.PlainSQLRepository.DB
{
    public interface IRowMapper<TSource, TResult>
    {
        /// <summary>
        /// Maps all the rows in TSource to list objects of type T.
        /// </summary>
        /// <param name="dataSource"></param>
        /// <returns></returns>
        IList<TResult> MapRows(TSource dataSource);


        /// <summary>
        /// Maps a specific row to an item of type TResult
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        TResult MapRow(TSource dataSource, int rowId);
    }
}
