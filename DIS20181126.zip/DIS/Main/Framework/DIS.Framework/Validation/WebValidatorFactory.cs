﻿using Autofac;
using FluentValidation;
using FluentValidation.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Validation
{
    public class WebValidatorFactory : ValidatorFactoryBase
    {
        private readonly IContainer container;

        public WebValidatorFactory(IContainer container)
        {
            this.container = container;
        }

        public override IValidator CreateInstance(Type validatorType)
        {
            IValidator validator = container.ResolveOptionalKeyed<IValidator>(validatorType.GenericTypeArguments[0].FullName.ToLowerInvariant());
            return validator;
        }
    }
}
