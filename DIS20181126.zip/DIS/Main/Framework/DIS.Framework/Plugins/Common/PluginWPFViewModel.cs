﻿using DIS.Framework.Security.Authorization;
using DIS.Framework.WPF.Infrastructure;
using log4net;
using Prism.Mvvm;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Common
{
    public abstract class PluginWPFViewModel : BindableBase
    {
        protected ILog _log;
        protected IAuthorizationService _auth;

        public PluginWPFViewModel(ILog log, IAuthorizationService auth)
        {
            _log = log;
            _auth = auth;
        }
    }

    public abstract class PluginWPFValidatableViewModel<T> : ValidatableBindableBase, INotifyDataErrorInfo
    {
        private readonly IValidator<T> _validator;
        public T _genericInstance { get; set; }

        protected ILog _log;

        public PluginWPFValidatableViewModel(ILog log, IValidator<T> validator)
        {
            _log = log;
            _validator = validator;
            _validator.ErrorsChanged += (s, e) => this.OnErrorsChanged(e);
        }

        public override void ValidateAllProperties()
        {
            _validator.Validate(_genericInstance);
        }

        public bool HasErrors
        {
            get
            {
                return _validator.HasErrors;
            }
        }

        public IList<string> GetAllErrors()
        {
            return _validator.GetAllErrors();
        }

        public IEnumerable GetErrors(string propertyName)
        {
            return _validator.GetErrors(propertyName);
        }
    }
}
