﻿using DIS.Framework.MVCFilters;
using DIS.Framework.Security.Authorization;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DIS.Framework.Plugins.Common
{
    [LogAndHandleError(Order = 99, View = "NULL")]
    public abstract class PluginController : AsyncController
    {
        protected ILog _log;
        protected IAuthorizationService _auth;

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //strange workarond to populate this.ControllerContext.RouteData.DataTokens, which is used to determine area of controller action.
            base.OnActionExecuting(filterContext);
            if (!this.ControllerContext.RouteData.DataTokens.ContainsKey("area"))
            {
                object area;
                if (this.ControllerContext.RouteData.Values.TryGetValue("area", out area))
                    this.ControllerContext.RouteData.DataTokens.Add("area", area);
            }
        }


    }
}
