﻿using DIS.Framework.DataAccess;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Configuration
{
    public interface IExternalPluginsConfigurationManager
    {
        IDictionary<string, string> GetConnectionString(String extConfigId);
        ConnectionInfo GetConnectionInfo(String extConfigId);
        UserImpersonation GetImpersonation(String extConfigId);
        IDictionary<string, string> GetPlugSettings();
    }
}
