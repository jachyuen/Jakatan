﻿using DIS.Framework.DataAccess;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Configuration
{
    public interface IPluginsConfigurationManager
    {
        IDictionary<string, string> GetPlugSettings(Type t);
        IDictionary<string, IDictionary<string, string>> GetConnectionStrings(Type t);
        IDictionary<string, string> GetConnectionParams(Type t, string name);
        IDictionary<string, string> GetQueryParameters(Type t, string queryID);
        IDictionary<string, string> GetClientWebServiceParameters(Type t, string serviceName);
        IDictionary<string, string> GetQueries(Type t);
        IDictionary<string, string> GetReportSection(Type t, string reportID);
        string GetQuery(Type t, string queryID);
        UserImpersonation GetImpersonation(Type t);
        UserImpersonation GetImpersonation(Type t, String id);
        IDictionary<string, UserImpersonation> GetImpersonations(Type t);
        ConnectionInfo GetConnectionInfo(Type t, string connectionName);
        //ConnectionInfo GetConnectionInfoFromExtConfig(string extConfigId);
        string[] GetMappedRoles(Type t, string role);
        string[] GetMembers(Type t);
        string BuildReportFileName(Type t, string reportID);
        string GetCurrentDISEnv();
    }
}
