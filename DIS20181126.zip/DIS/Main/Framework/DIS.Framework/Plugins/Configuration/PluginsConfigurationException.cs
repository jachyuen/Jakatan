﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Configuration
{
    public class PluginsConfigurationException : Exception
    {
        public PluginsConfigurationException()
        {
        }

        public PluginsConfigurationException(string message)
            : base(message)
        {
        }

        public PluginsConfigurationException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    public class PluginsConfigurationInvalidException : Exception
    {
        public PluginsConfigurationInvalidException()
        {
        }

        public PluginsConfigurationInvalidException(string message)
            : base(message)
        {
        }

        public PluginsConfigurationInvalidException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    public class PluginsConfigurationEncryptionException : Exception
    {
        public PluginsConfigurationEncryptionException()
        {
        }

        public PluginsConfigurationEncryptionException(string message)
            : base(message)
        {
        }

        public PluginsConfigurationEncryptionException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }

    public class PluginsConfigurationNotFoundException : Exception
    {
        public PluginsConfigurationNotFoundException()
        {
        }

        public PluginsConfigurationNotFoundException(string message)
            : base(message)
        {
        }

        public PluginsConfigurationNotFoundException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}
