﻿using DIS.Framework.Host;
using DIS.Framework.Modules;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.XPath;

namespace DIS.Framework.Plugins.Configuration
{
    public class PluginsConfiguration : IPluginsConfiguration
    {
        private ICryptoHelper _cryptoHelper;
        public string _configFullPath
        {
            get
            {
                if (Path.IsPathRooted(DISHostConfigStatics.PluginsConfigPath))
                    return DISHostConfigStatics.PluginsConfigPath;
                else
                    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DISHostConfigStatics.PluginsConfigPath);
            }
        }
        public string _configEncFullPath
        {
            get
            {
                if (Path.IsPathRooted(DISHostConfigStatics.PluginsEncryptedConfigPath))
                    return DISHostConfigStatics.PluginsEncryptedConfigPath;
                else
                    return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DISHostConfigStatics.PluginsEncryptedConfigPath);
            }
        }

        public string Config { get { return Path.Combine(_configFullPath, AssemblyName + DISHostConfigStatics.PluginsConfigFileExt); } }
        public string ConfigEnc { get { return Path.Combine(_configEncFullPath, AssemblyName + DISHostConfigStatics.PluginsEncryptedConfigFileExt); } }
        public ConfigStatusEnum ConfigStatus { get; set; }
        public ConfigErrorEnum ConfigError { get; set; }
        public string AssemblyName { get; set; }

        public PluginsConfiguration(ICryptoHelper cryptoHelper)
        {
            _cryptoHelper = cryptoHelper;
        }

        public void Init()
        {
            if (this.FileExists() && this.IsValid() && !DISHostConfigStatics.PluginsEncrypted)
            {
                ConfigStatus = ConfigStatusEnum.Valid;
            }
            else if (this.FileExists() && this.IsValid() && DISHostConfigStatics.PluginsEncrypted)
            {
                ConfigStatus = ConfigStatusEnum.Encrypted;
            }
            else if (this.FileExists() && !this.IsValid())
            {
                ConfigStatus = ConfigStatusEnum.Error;
                ConfigError = ConfigErrorEnum.EnvIssue;
            }
            if (!this.FileExists() && DISHostConfigStatics.PluginsEncrypted)
            {
                this.Update();

                //try
                //{
                //    this.Update();
                //    ConfigStatus = ConfigStatusEnum.Encrypted;
                //}
                //catch (PluginsConfigurationNotFoundException pcfe)
                //{
                //    ConfigStatus = ConfigStatusEnum.Error;
                //    ConfigError = ConfigErrorEnum.Missing;
                //}
                //catch (PluginsConfigurationEncryptionException pcee)
                //{
                //    ConfigStatus = ConfigStatusEnum.Error;
                //    ConfigError = ConfigErrorEnum.EncryptIssue;
                //}
                //catch (PluginsConfigurationInvalidException pcie)
                //{
                //    ConfigStatus = ConfigStatusEnum.Error;
                //    ConfigError = ConfigErrorEnum.EnvIssue;
                //}
                //catch (Exception e)
                //{
                //    ConfigStatus = ConfigStatusEnum.Error;
                //    ConfigError = ConfigErrorEnum.Unknown;
                //}
            }
        }

        /// <summary>
        /// Wrapper used to masquarade the call to the OS.Framework.Security CryptoUtils
        /// </summary>
        /// <param name="file">assembly</param>
        private void FileCrypt()
        {
            if (File.Exists(Config))
            {
                _cryptoHelper.EncryptXML(Config).Save(ConfigEnc);
                return;
            }

            throw new PluginsConfigurationNotFoundException(_configFullPath);
        }

        public bool FileExists()
        {
            return File.Exists(this.ToString());
        }

        public DateTime GetTimeStamp()
        {
            try
            {
                return File.GetLastWriteTime(this.ToString());
            }
            catch (Exception e)
            {
                throw new ConfigurationErrorsException(String.Format("Impossible to get configuration time stamp {0}", this.ToString()), e);
            }
        }

        public XmlDocument Read()
        {
            if (this.FileExists())
            {
                if (!DISHostConfigStatics.PluginsEncrypted)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(this.ToString());

                    return doc;
                }

                return _cryptoHelper.DecryptPluginsConfig(this.ToString());
            }

            throw new PluginsConfigurationNotFoundException(this.ToString());
        }

        public void Update()
        {
            ////try
            ////{
            ////    //if(File.Exists(Config))
            //this.FileCrypt();
            ////}
            ////catch (Exception e)
            ////{
            ////    throw new PluginsConfigurationEncryptionException(string.Format("Issue during FileCrypt({0})", Config), e);
            ////}
            //if(this.IsValid())
            //    File.Delete(Config);
            //else
            //    throw new PluginsConfigurationInvalidException(Config);

            try
            {
                this.FileCrypt();
                if (this.IsValid())
                    File.Delete(Config);
                else
                    throw new PluginsConfigurationInvalidException(Config);

                ConfigStatus = ConfigStatusEnum.Encrypted;
                ConfigError = ConfigErrorEnum.None;
            }
            catch (PluginsConfigurationNotFoundException)
            {
                ConfigStatus = ConfigStatusEnum.Error;
                ConfigError = ConfigErrorEnum.Missing;
            }
            catch (PluginsConfigurationEncryptionException)
            {
                ConfigStatus = ConfigStatusEnum.Error;
                ConfigError = ConfigErrorEnum.EncryptIssue;
            }
            catch (PluginsConfigurationInvalidException)
            {
                ConfigStatus = ConfigStatusEnum.Error;
                ConfigError = ConfigErrorEnum.EnvIssue;
            }
            catch (Exception)
            {
                ConfigStatus = ConfigStatusEnum.Error;
                ConfigError = ConfigErrorEnum.Unknown;
            }
        }

        public virtual bool IsValid()
        {
            if (this.FileExists())
            {
                try
                {
                    XPathDocument document = new XPathDocument(new XmlNodeReader(this.Read()));
                    XPathNavigator navigator = document.CreateNavigator();
                    XPathNodeIterator nodes = navigator.Select(String.Format("{0}[@id=\"{1}\"]", PluginsConfigStatics.configRoot_XPath, DISHostConfigStatics.Environment));

                    if (nodes.Count > 0)
                        return true;
                }
                catch (XPathException xe)
                {
                    throw new PluginsConfigurationInvalidException(string.Format("Impossible to find environemnt {0} root element of {1}", DISHostConfigStatics.Environment, this), xe);
                }
                catch (Exception e)
                {
                    throw new PluginsConfigurationInvalidException(string.Format("Configuration {0} is invalid", this), e);
                }
            }

            return false;
        }

        public override string ToString()
        {
            if (DISHostConfigStatics.PluginsEncrypted)
                return ConfigEnc;
            else
                return Config;
        }
    }
}
