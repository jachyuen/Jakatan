﻿using DIS.Framework.DataAccess;
using DIS.Framework.Host;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.XPath;

namespace DIS.Framework.Plugins.Configuration
{
    public class PluginsConfigurationManager : IPluginsConfigurationManager
    {
        IExternalPluginsConfigurationManager _extPluginsConfigManager;
        IPluginsConfiguration _pluginsConfig;

        public PluginsConfigurationManager(IExternalPluginsConfigurationManager extPluginsConfigManager,
            IPluginsConfiguration pluginsConfig)
        {
            _extPluginsConfigManager = extPluginsConfigManager;
            _pluginsConfig = pluginsConfig;
        }

        /// <summary>
        /// Verify if the given config is in cache
        /// </summary>
        /// <param name="assembly">Name of the assembly</param>
        /// <returns>a XML Config or Null</returns>
        private XPathDocument IsCached(string assembly)
        {
            XPathDocument cachedConfig = (XPathDocument)HttpRuntime.Cache["DIS_CURRENT_PluginsConfiguration_" + assembly];

            if (cachedConfig == null)
                return null;

            return cachedConfig;
        }

        private XPathDocument GetConfig(Type t)
        {
            XPathDocument document = null;
            string assemblyName = t.Assembly.GetName().Name;

            if (DISHostConfigStatics.PluginsConfigCached && IsCached(assemblyName) != null)
            {
                document = IsCached(assemblyName);
            }
            else
            {
                _pluginsConfig.AssemblyName = assemblyName;
                document = new XPathDocument(new XmlNodeReader(_pluginsConfig.Read()));

                if (DISHostConfigStatics.PluginsConfigCached)
                    HttpRuntime.Cache.Insert("DIS_CURRENT_PluginsConfiguration_" + assemblyName, document);
            }

            return document;
        }

        private XPathNavigator FindByEnv(Type t)
        {
            XPathDocument document = this.GetConfig(t);

            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator nodes = navigator.Select(String.Format("{0}[@id=\"{1}\"]", PluginsConfigStatics.configRoot_XPath, DISHostConfigStatics.Environment));

            if (nodes.Count > 0)
            {
                nodes.MoveNext();
                return nodes.Current;
            }

            throw new ConfigurationErrorsException(String.Format("Plugins has no defined configuration for current environment: {0}", DISHostConfigStatics.Environment));
        }

        public IDictionary<string, string> GetPlugSettings(Type t)
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNodeIterator nodes = this.FindByEnv(t).Select(PluginsConfigStatics.plugSettings_XPath);

            while (nodes.MoveNext())
            {
                settings.Add(nodes.Current.GetAttribute("key", ""), nodes.Current.GetAttribute("value", ""));
            }

            if (settings.Count == 0)
                throw new ConfigurationErrorsException("No plugins settings defined");

            return settings;
        }

        public IDictionary<string, IDictionary<string, string>> GetConnectionStrings(Type t)
        {
            IDictionary<string, IDictionary<string, string>> settings = new Dictionary<string, IDictionary<string, string>>();
            XPathNodeIterator nodes = this.FindByEnv(t).Select(PluginsConfigStatics.conString_XPath);

            while (nodes.MoveNext())
            {
                IDictionary<string, string> result;
                if (String.IsNullOrEmpty(nodes.Current.GetAttribute(PluginsConfigStatics.externalConfigId, "")))
                {
                    if (String.IsNullOrEmpty(nodes.Current.GetAttribute("connectionString", "")))
                        result = GetClearerConnectionStrings(nodes);
                    else
                        result = GetSimpleConnectionStrings(nodes);
                }
                else
                {
                    result = _extPluginsConfigManager.GetConnectionString(nodes.Current.GetAttribute(PluginsConfigStatics.externalConfigId, ""));
                }
                settings.Add(nodes.Current.GetAttribute("name", ""), result);
            }

            //if (settings.Count == 0)
            //{
            //    throw new PluginsConfigurationException("No connection defined");
            //}

            return settings;
        }

        private IDictionary<string, string> GetClearerConnectionStrings(XPathNodeIterator nodes)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            //result.Add("connectionString", nodes.Current.GetAttribute("connectionString", ""));
            // instead of getting the connection string directly, need to grab the pieces and combine them together to get the real connection string... this is suppose to be clearer?
            string databaseHost = nodes.Current.GetAttribute("databaseHost", "");
            string databaseName = nodes.Current.GetAttribute("databaseName", "");
            string databaseUser = nodes.Current.GetAttribute("databaseUser", "");
            string databasePassword = nodes.Current.GetAttribute("databasePassword", "");
            string databasePasswordConfigId = nodes.Current.GetAttribute("databasePasswordConfigId", "");
            string providerName = nodes.Current.GetAttribute("providerName", "");

            if (!string.IsNullOrWhiteSpace(databasePasswordConfigId))
                databasePassword = _extPluginsConfigManager.GetPlugSettings()[databasePasswordConfigId];

            string actualConnectionString = string.Empty;
            // either ORACLE or SQL server for now. need to cater addition provider later.
            if (providerName != null && providerName.ToUpper().Contains("ORACLE"))
            {
                actualConnectionString = string.Format(@"Data Source={0};Persist Security Info=True;User ID={1};Password={2};", databaseHost, databaseUser, databasePassword);
            }
            else
            {
                // assume SQL server if not ORACLE
                if (string.IsNullOrEmpty(databaseUser))
                {
                    // no database user provided. assume using integrate security
                    actualConnectionString = string.Format(@"Server={0};Database={1};Integrated Security=SSPI;", databaseHost, databaseName);
                }
                else
                    actualConnectionString = string.Format(@"Server={0};Database={1};User ID={2};Password={3};", databaseHost, databaseName, databaseUser, databasePassword);
            }

            result.Add("connectionString", actualConnectionString);
            result.Add("providerName", providerName);
            result.Add("impersonationId", nodes.Current.GetAttribute("impersonationId", ""));
            return result;
        }

        private IDictionary<string, string> GetSimpleConnectionStrings(XPathNodeIterator nodes)
        {
            IDictionary<string, string> result = new Dictionary<string, string>();
            result.Add("connectionString", nodes.Current.GetAttribute("connectionString", ""));
            result.Add("providerName", nodes.Current.GetAttribute("providerName", ""));
            result.Add("impersonationId", nodes.Current.GetAttribute("impersonationId", ""));
            return result;
        }

        public IDictionary<string, string> GetConnectionParams(Type t, string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name", "Connection string name cannot be null");

            IDictionary<string, string> dict = new Dictionary<string, string>();
            string cnx = null;
            string provider = null;
            string impersonationId = null;

            try
            {
                cnx = this.GetConnectionStrings(t)[name].Where(d => d.Key.Equals("connectionString")).Select(d => d.Value).Single<string>();
                provider = this.GetConnectionStrings(t)[name].Where(d => d.Key.Equals("providerName")).Select(d => d.Value).Single<string>();
                impersonationId = this.GetConnectionStrings(t)[name].Where(d => d.Key.Equals("impersonationId")).Select(d => d.Value).Single<string>();
                dict.Add("connectionString", cnx);
                dict.Add("providerName", provider);
                dict.Add("impersonationId", impersonationId);

                return dict;
            }
            catch (KeyNotFoundException knfe)
            {
                throw new PluginsConfigurationException(string.Format("Connection string {0} not found", name), knfe);
            }
        }


        public IDictionary<string, string> GetClientWebServiceParameters(Type t, string serviceName)
        {
            IDictionary<string, string> dict = new Dictionary<string, string>();
            XPathNodeIterator nodes = this.FindByEnv(t).Select(string.Format(PluginsConfigStatics.webServices_Xpath, serviceName));
            nodes.MoveNext();

            dict.Add("address", nodes.Current.GetAttribute("address", ""));
            dict.Add("binding", nodes.Current.GetAttribute("binding", ""));

            return dict;
        }

        public string BuildReportFileName(Type t, string reportID)
        {
            string filename = null;

            IDictionary<string, string> rptParams = GetReportSection(t, reportID);
            string path = rptParams["Path"];
            string dateFormat = rptParams["DateFormat"];
            string fileNameFormat = rptParams["FileName"];
            double dateShift = double.Parse(rptParams["DateShift"]);
            DateTime date = DateTime.Now;

            date = date.AddDays(dateShift);
            filename = String.Format(fileNameFormat, date.ToString(dateFormat));
            filename = Path.Combine(path, filename);

            return filename;
        }

        public IDictionary<string, string> GetReportSection(Type t, string reportID)
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNodeIterator nodes = FindByEnv(t).Select(string.Format(PluginsConfigStatics.reportSettings_XPath, reportID));

            while (nodes.MoveNext())
                settings.Add(nodes.Current.GetAttribute("key", ""), nodes.Current.GetAttribute("value", ""));

            if (settings.Count == 0)
            {
                throw new ConfigurationErrorsException(string.Format("No Report parameters defined for report with ID: {0}", reportID));
            }

            return settings;
        }


        public IDictionary<string, string> GetQueryParameters(Type t, string queryID)
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNodeIterator nodes = FindByEnv(t).Select(PluginsConfigStatics.queryParams_XPath);

            while (nodes.MoveNext())
            {
                if (nodes.Current.GetAttribute("id", "") == queryID)
                {
                    nodes = nodes.Current.Select("param");

                    while (nodes.MoveNext())
                        settings.Add(nodes.Current.GetAttribute("id", ""), nodes.Current.Value);

                    break;
                }
            }

            if (settings.Count == 0)
            {
                throw new ConfigurationErrorsException(string.Format("No SQL parameters defined for query with ID: {0}", queryID));
            }

            return settings;
        }

        public IDictionary<string, string> GetQueries(Type t)
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNavigator navigator = this.GetConfig(t).CreateNavigator();
            XPathNodeIterator nodes = navigator.Select(PluginsConfigStatics.queryDetails_XPath);

            while (nodes.MoveNext())
            {
                settings.Add(nodes.Current.GetAttribute("id", ""), nodes.Current.Value);
            }

            if (settings.Count == 0)
            {
                throw new ConfigurationErrorsException("No query defined");
            }

            return settings;
        }

        public string GetQuery(Type t, string queryID)
        {
            XPathNavigator navigator = this.GetConfig(t).CreateNavigator();
            XPathNodeIterator nodes = navigator.Select(PluginsConfigStatics.queryDetails_XPath);

            while (nodes.MoveNext())
            {
                if (nodes.Current.GetAttribute("id", "") == queryID)
                    return nodes.Current.Value;
            }

            throw new ConfigurationErrorsException(string.Format("No SQL Query defined with ID: {0}", queryID));
        }

        /// <summary>
        /// Used to get the array of mapped roles
        /// </summary>
        /// <param name="assembly">Plugin assembly</param>
        /// <param name="roles">Plugin role names in list seperated by a ","</param>
        /// <returns>array of AD Groups</returns>
        public string[] GetMappedRoles(Type t, string roles)
        {
            IList<PluginsRole> _mapper = new List<PluginsRole>();
            XPathNodeIterator nodes = this.FindByEnv(t).Select(PluginsConfigStatics.rolesMapping_XPath);

            while (nodes.MoveNext())
            {
                if (roles.Split(',').AsQueryable<String>().Contains(nodes.Current.GetAttribute("Plugins", "")))
                    _mapper.Add(new PluginsRole(nodes.Current.GetAttribute("AD", ""), nodes.Current.GetAttribute("Plugins", "")));
            }

            //return _mapper.Where(aMapper => aMapper.Plugins == role).Select(aMapper => aMapper.AD).ToArray<string>();
            return _mapper.Select(aMapper => aMapper.AD).ToArray<string>();
        }

        /// <summary>
        /// Used to get the array of members
        /// </summary>
        /// <param name="assembly">Plugin assembly</param>
        /// <param name="roles">Plugin role names in list seperated by a ","</param>
        /// <returns>array of AD Groups</returns>
        public string[] GetMembers(Type t)
        {
            IList<string> _members = new List<string>();
            XPathNodeIterator nodes = this.FindByEnv(t).Select(PluginsConfigStatics.members_XPath);

            while (nodes.MoveNext())
            {
                _members.Add(nodes.Current.Value);
            }

            return _members.ToArray<string>();
        }

        /// <summary>
        /// Used to get the Impersonation parameters of a plugin
        /// </summary>
        /// <param name="assembly">Plugin assembly</param>
        /// <returns>a instance of UserImpersonation class with "default" as ID or no ID at all</returns>
        public UserImpersonation GetImpersonation(Type t)
        {
            return GetImpersonation(t, "default");
        }

        public UserImpersonation GetImpersonation(Type t, String id)
        {
            if (string.IsNullOrEmpty(id))
                throw new ArgumentNullException("id", "Must provide a valid user id to get the impersonation");

            UserImpersonation _winUser = null;
            try
            {
                _winUser = GetImpersonations(t)[id];
                _winUser.Id = id;

                if ((_winUser == null) || (_winUser.IsNull()))
                    throw new PluginsConfigurationException(string.Format("Cannot find user {0} defined in impersonation section", id));
            }
            catch (KeyNotFoundException knfe)
            {
                throw new PluginsConfigurationException(string.Format("Cannot find user {0} defined in impersonation section", id), knfe);
            }

            return _winUser;
        }

        public IDictionary<string, UserImpersonation> GetImpersonations(Type t)
        {
            IDictionary<string, UserImpersonation> settings = new Dictionary<string, UserImpersonation>();
            UserImpersonation _winUser;
            XPathNodeIterator nodes = this.FindByEnv(t).Select(PluginsConfigStatics.impersonation_XPath);
            XPathNodeIterator impersonateNodes;
            while (nodes.MoveNext())
            {
                if (String.IsNullOrEmpty(nodes.Current.GetAttribute(PluginsConfigStatics.externalConfigId, "")))
                {
                    _winUser = new UserImpersonation();
                    impersonateNodes = nodes.Current.SelectChildren(nodes.Current.NodeType);

                    while (impersonateNodes.MoveNext())
                    {
                        switch (impersonateNodes.Current.Name)
                        {
                            case "login":
                                _winUser.UserName = impersonateNodes.Current.Value;
                                break;
                            case "password":
                                _winUser.UserPassword = impersonateNodes.Current.Value;
                                break;
                            case "domain":
                                _winUser.Domain = impersonateNodes.Current.Value;
                                break;
                        }
                    }
                }
                else
                {
                    _winUser = _extPluginsConfigManager.GetImpersonation(nodes.Current.GetAttribute(PluginsConfigStatics.externalConfigId, ""));
                }
                settings.Add(nodes.Current.GetAttribute("id", ""), _winUser);
            }

            //if (settings.Count <= 0)
            //    throw new PluginsConfigurationException("No <impersonations> section is defined or no <impersonation> is defined under <impersonations>");

            return settings;
        }

        public ConnectionInfo GetConnectionInfo(Type t, string connectionName)
        {
            ConnectionInfo setting = null;
            String imperId = GetConnectionParams(t, connectionName)["impersonationId"];
            UserImpersonation imperUser = null;

            if (!String.IsNullOrEmpty(imperId))
                imperUser = GetImpersonation(t, imperId);

            // need to break up the connection. I want to keep the origin just in case.
            string connectionString = GetConnectionParams(t, connectionName)["connectionString"];

            setting = new ConnectionInfo(connectionString,
                                        GetConnectionParams(t, connectionName)["providerName"],
                                        imperUser);

            return setting;
        }

        public ConnectionInfo GetConnectionInfoFromExtConfig(string extConfigId)
        {
            return _extPluginsConfigManager.GetConnectionInfo(extConfigId);
        }

        public string GetCurrentDISEnv()
        { return DISHostConfigStatics.Environment; }
    }
}
