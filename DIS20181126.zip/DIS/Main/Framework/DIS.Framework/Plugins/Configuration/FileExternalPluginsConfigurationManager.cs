﻿using DIS.Framework.DataAccess;
using DIS.Framework.Host;
using DIS.Framework.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.XPath;

namespace DIS.Framework.Plugins.Configuration
{
    public class FileExternalPluginsConfigurationManager : IExternalPluginsConfigurationManager
    {
        private ICryptoHelper _cryptoHelper;

        public FileExternalPluginsConfigurationManager(ICryptoHelper cryptoHelper)
        {
            _cryptoHelper = cryptoHelper;
            this.Init();
        }

        public void Init()
        {
            if (DISHostConfigStatics.PluginsExternalConfigEncrypted)
            {
                if (File.Exists(DISHostConfigStatics.PluginsExternalConfigPath))
                {
                    if (File.Exists(DISHostConfigStatics.PluginsExternalConfigEncryptPath))
                        File.Delete(DISHostConfigStatics.PluginsExternalConfigEncryptPath);

                    this.FileCrypt();
                    if (this.IsValid())
                        File.Delete(DISHostConfigStatics.PluginsExternalConfigPath);
                    else
                        throw new PluginsConfigurationInvalidException(DISHostConfigStatics.PluginsExternalConfigPath);
                }
                else if(!File.Exists(DISHostConfigStatics.PluginsExternalConfigEncryptPath))
                    throw new PluginsConfigurationInvalidException(DISHostConfigStatics.PluginsExternalConfigPath);
            }
        }

        private void FileCrypt()
        {
            if (File.Exists(DISHostConfigStatics.PluginsExternalConfigPath))
            {
                _cryptoHelper.EncryptXML(DISHostConfigStatics.PluginsExternalConfigPath).Save(DISHostConfigStatics.PluginsExternalConfigEncryptPath);
                return;
            }

            throw new PluginsConfigurationNotFoundException(DISHostConfigStatics.PluginsExternalConfigPath);
        }

        public bool FileExists()
        {
            return File.Exists(this.ExtConfigFileFullPath());
        }

        public string ExtConfigFileFullPath()
        {
            if (DISHostConfigStatics.PluginsExternalConfigEncrypted)
                return DISHostConfigStatics.PluginsExternalConfigEncryptPath;
            else
                return DISHostConfigStatics.PluginsExternalConfigPath;
        }

        public virtual bool IsValid()
        {
            if (FileExists())
            {
                try
                {
                    XPathDocument document = new XPathDocument(new XmlNodeReader(ReadExternalConfig()));
                    XPathNavigator navigator = document.CreateNavigator();
                    XPathNodeIterator nodes = navigator.Select(String.Format("{0}[@id=\"{1}\"]", PluginsConfigStatics.configRoot_XPath, DISHostConfigStatics.Environment));

                    if (nodes.Count > 0)
                        return true;
                }
                catch (XPathException xe)
                {
                    throw new PluginsConfigurationInvalidException(string.Format("Impossible to find environemnt {0} root element of {1}", DISHostConfigStatics.Environment, this), xe);
                }
                catch (Exception e)
                {
                    throw new PluginsConfigurationInvalidException(string.Format("Configuration {0} is invalid", this), e);
                }
            }

            return false;
        }

        private XPathNavigator FindByEnv()
        {
            XPathDocument document = this.GetConfig();

            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator nodes = navigator.Select(String.Format("{0}[@id=\"{1}\"]", PluginsConfigStatics.configRoot_XPath, DISHostConfigStatics.Environment));

            if (nodes.Count > 0)
            {
                nodes.MoveNext();
                return nodes.Current;
            }

            throw new ConfigurationErrorsException(String.Format("Plugins has no defined configuration for current environment: {0}", DISHostConfigStatics.Environment));
        }

        private XPathDocument GetConfig()
        {
            XPathDocument document = null;

            if (DISHostConfigStatics.PluginsConfigCached && IsCached() != null)
            {
                document = IsCached();
            }
            else
            {
                document = new XPathDocument(new XmlNodeReader(ReadExternalConfig()));

                if (DISHostConfigStatics.PluginsConfigCached)
                    HttpRuntime.Cache.Insert("DIS_CURRENT_PluginsConfiguration_DISExternalConfig", document);
            }

            return document;
        }

        private XPathDocument IsCached()
        {
            XPathDocument cachedConfig = (XPathDocument)HttpRuntime.Cache["DIS_CURRENT_PluginsConfiguration_DISExternalConfig"];

            if (cachedConfig == null)
                return null;

            return cachedConfig;
        }

        private XmlDocument ReadExternalConfig()
        {
            if (FileExists())
            {
                if (DISHostConfigStatics.PluginsExternalConfigEncrypted)
                    return _cryptoHelper.DecryptPluginsConfig(ExtConfigFileFullPath());
                else
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(ExtConfigFileFullPath());

                    return doc;
                }
            }

            throw new PluginsConfigurationNotFoundException(DISHostConfigStatics.PluginsExternalConfigPath);
        }

        public IDictionary<string, string> GetConnectionString(String extConfigId)
        {
            //XPathNodeIterator nodes = GetConfig().CreateNavigator().Select(String.Format("/configuration/{0}[@ConfigId=\"{1}\"]", PluginsConfigStatics.conString_XPath, extConfigId));
            XPathNodeIterator nodes = FindByEnv().Select(string.Format("{0}[@ConfigId=\"{1}\"]", PluginsConfigStatics.conString_XPath, extConfigId));

            if (nodes.Count > 0)
            {
                while (nodes.MoveNext())
                {
                    IDictionary<string, string> result = new Dictionary<string, string>();
                    result.Add("connectionString", nodes.Current.GetAttribute("connectionString", ""));
                    result.Add("providerName", nodes.Current.GetAttribute("providerName", ""));
                    result.Add("impersonationId", nodes.Current.GetAttribute("impersonationId", ""));
                    return result;
                }
            }
            throw new PluginsConfigurationException(string.Format("No connection ({0}) found in external config file.", extConfigId));
        }

        public ConnectionInfo GetConnectionInfo(String extConfigId)
        {
            ConnectionInfo connInfo = null;
            IDictionary<string, string> connInfoDetails = GetConnectionString(extConfigId);
            UserImpersonation imperUser = null;

            if (!String.IsNullOrEmpty(connInfoDetails["impersonationId"]))
                imperUser = GetImpersonation(connInfoDetails["impersonationId"]);

            connInfo = new ConnectionInfo(connInfoDetails["connectionString"],
                            connInfoDetails["providerName"],
                            imperUser);

            return connInfo;
        }

        public UserImpersonation GetImpersonation(String extConfigId)
        {
            UserImpersonation _winUser;
            //XPathNodeIterator nodes = GetConfig().CreateNavigator().Select(String.Format("/configuration/{0}[@ConfigId=\"{1}\"]", PluginsConfigStatics.impersonation_XPath, extConfigId));
            XPathNodeIterator nodes = FindByEnv().Select(String.Format("{0}[@ConfigId=\"{1}\"]", PluginsConfigStatics.impersonation_XPath, extConfigId));
            XPathNodeIterator impersonateNodes;
            if (nodes.Count > 0)
            {
                while (nodes.MoveNext())
                {
                    _winUser = new UserImpersonation();

                    impersonateNodes = nodes.Current.SelectChildren(nodes.Current.NodeType);

                    while (impersonateNodes.MoveNext())
                    {
                        switch (impersonateNodes.Current.Name)
                        {
                            case "login":
                                _winUser.UserName = impersonateNodes.Current.Value;
                                break;
                            case "password":
                                _winUser.UserPassword = impersonateNodes.Current.Value;
                                break;
                            case "domain":
                                _winUser.Domain = impersonateNodes.Current.Value;
                                break;
                        }
                    }
                    return _winUser;
                }
            }

            throw new PluginsConfigurationException(String.Format("No ConfigId ({0}) found in external configuration file", extConfigId));
        }

        public IDictionary<string, string> GetPlugSettings()
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNodeIterator nodes = this.FindByEnv().Select(PluginsConfigStatics.plugSettings_XPath);

            while (nodes.MoveNext())
            {
                settings.Add(nodes.Current.GetAttribute("key", ""), nodes.Current.GetAttribute("value", ""));
            }

            if (settings.Count == 0)
                throw new ConfigurationErrorsException("No plugins settings defined in external configuration file");

            return settings;
        }

    }
}

