﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Configuration
{
    public static class PluginsConfigStatics
    {
        //Plugins XPath variables for reading xml cfg
        public static readonly string configRoot_XPath = "/configuration/env";
        public static readonly string plugSettings_XPath = "plugSettings/setting";
        public static readonly string reportSettings_XPath = "reportSettings/report[@id={0}]/param";
        public static readonly string queryDetails_XPath = "/configuration/queries/query";
        public static readonly string queryParams_XPath = "sqlParams/query";
        public static readonly string conString_XPath = "connectionStrings/connection";
        public static readonly string rolesMapping_XPath = "rolesMapping/role";
        public static readonly string members_XPath = "members/group";
        public static readonly string impersonation_XPath = "impersonations/impersonation";
        public static readonly string webServices_Xpath = "webServices/client/endpoint[@name='{0}']";
        public static readonly string externalConfigId = "ExtConfigId";
    }
}
