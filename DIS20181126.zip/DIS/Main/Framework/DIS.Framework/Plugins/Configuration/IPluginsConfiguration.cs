﻿using System;
using System.Xml;
using DIS.Framework.Modules;

namespace DIS.Framework.Plugins.Configuration
{
    public interface IPluginsConfiguration
    {
        string Config { get; }
        string ConfigEnc { get; }
        ConfigErrorEnum ConfigError { get; set; }
        ConfigStatusEnum ConfigStatus { get; set; }
        string AssemblyName { get; set; }

        bool FileExists();
        DateTime GetTimeStamp();
        bool IsValid();
        XmlDocument Read();
        string ToString();
        void Update();
        void Init();
    }
}