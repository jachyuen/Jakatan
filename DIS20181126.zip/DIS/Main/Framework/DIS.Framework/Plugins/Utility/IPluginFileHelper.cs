﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Utility
{
    public interface IPluginFileHelper
    {
        string GetPluginFile(Type t, string file);
        Stream GetPluginEmbeddedFile(string file);
        string GetPluginTempFile(Type t, string file);
    }
}
