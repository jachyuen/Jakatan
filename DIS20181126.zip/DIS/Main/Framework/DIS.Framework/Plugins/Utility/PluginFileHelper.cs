﻿using DIS.Framework.Host;
using DIS.Framework.Modules;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Plugins.Utility
{
    public class PluginFileHelper : IPluginFileHelper
    {
        private IPluginsCatalogService _plugCat; // = ServiceLocator.Current.GetInstance<IPluginsCatalogService>();

        public PluginFileHelper(IPluginsCatalogService plugCat)
        { _plugCat = plugCat; }

        /// <summary>
        /// Returns full path of a plugin external file
        /// </summary>
        /// <param name="t"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        public string GetPluginFile(Type t, string file)
        {
            string output = string.Format("{0}\\{1}\\{2}", DISHostConfigStatics.PluginsPath, _plugCat.GetByAssembly(t.Assembly).Area, file);
            output = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, output);

            if (!File.Exists(output))
                throw new FileNotFoundException(string.Format("Plugin File not found: {0}", output), output);

            return output;
        }

        /// <summary>
        /// Returns full path of a plugin temp file
        /// </summary>
        /// <param name="t"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        public string GetPluginTempFile(Type t, string file)
        {
            string output = string.Format(DISHostConfigStatics.PluginsTempPath, _plugCat.GetByAssembly(t.Assembly).Area);
            output = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, output);
            output = Path.Combine(output, file);

            if (!File.Exists(output))
                throw new FileNotFoundException(string.Format("Plugin Temp File not found: {0}", output), output);

            return output;
        }

        public Stream GetPluginEmbeddedFile(string file)
        {
            Assembly a = new StackFrame(1).GetMethod().DeclaringType.Assembly;
            file = string.Format("{0}.{1}", a.GetName().Name, file);
            Stream resourceStream = a.GetManifestResourceStream(file);

            return resourceStream;
        }
    }
}
