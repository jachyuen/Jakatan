﻿using System.Web.Hosting;

namespace DIS.Framework.FileSystems
{
    public interface ICustomVirtualPathProvider
    {
        VirtualPathProvider Instance { get; }
    }
}
