﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework
{
    [Serializable]
    public class PagedList<T> : List<T>, IPagedList<T>
    {
        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="source">source</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        public PagedList(IQueryable<T> source, int displayStart, int displayLength)
        {
            int total = source.Count();
            this.TotalCount = total;
            this.TotalPages = total / displayLength;

            if (total % displayLength > 0)
                TotalPages++;

            this.PageSize = displayLength;
            this.PageIndex = displayStart / displayLength; // this is zero based
            this.AddRange(source.Skip(displayStart).Take(displayLength).ToList());
        }

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="source">source</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        public PagedList(IList<T> source, int displayStart, int displayLength)
        {
            TotalCount = source.Count();
            TotalPages = TotalCount / displayLength;

            if (TotalCount % displayLength > 0)
                TotalPages++;

            this.PageSize = displayLength;
            this.PageIndex = displayStart / displayLength;
            this.AddRange(source.Skip(displayStart).Take(displayLength).ToList());
        }

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="source">source</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <param name="totalCount">Total count</param>
        public PagedList(IEnumerable<T> source, int displayStart, int displayLength, int totalCount)
        {
            TotalCount = totalCount;
            TotalPages = TotalCount / displayLength;

            if (TotalCount % displayLength > 0)
                TotalPages++;

            this.PageSize = displayLength;
            this.PageIndex = displayStart / displayLength;
            this.AddRange(source);
        }

        public int PageIndex { get; private set; }
        public int PageSize { get; private set; }
        public int TotalCount { get; private set; }
        public int TotalPages { get; private set; }

        public bool HasPreviousPage
        {
            get { return (PageIndex > 0); }
        }
        public bool HasNextPage
        {
            get { return (PageIndex + 1 < TotalPages); }
        }
    }
}
