﻿using Autofac;
using DIS.Framework.Plugins.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class ContractPluginsPackage : PluginsPackage
    {
        public override void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager)
        {
            _configManager = configManager;
            SetPluginConfig(config);
            try
            {
                _log.Debug(String.Format("Registering contract assembly: {0}", assembly));
                Status = PlugStatusEnum.Registering;
                RegisterWcfClient(builder, assembly, Area);
                RegisterPluginSpecific(builder);
                Status = PlugStatusEnum.Registered;
                _log.Debug(String.Format("Contract Assembly {0} is registerd", assembly));
            }
            catch (ComponentRegistrationException cre)
            {
                RegistrationError = RegistrationErrorEnum.Component;
                _log.Error(String.Format("Error while registering assembly: {0}!", assembly), cre);
            }
            catch (Exception e)
            {
                RegistrationError = RegistrationErrorEnum.Unknown;
                _log.Error(String.Format("Error while registering assembly: {0}!", assembly), e);
            }
        }

        public override void RegisterPluginSpecific(ContainerBuilder builder)
        { }

        protected virtual void RegisterWcfClient(ContainerBuilder builder, Assembly assembly, string areaName)
        {
            try
            {
                var contractType = from ty in assembly.GetTypes()
                                   where (System.Attribute.GetCustomAttributes(ty).Where(c => c is System.ServiceModel.ServiceContractAttribute).Count() > 0)
                                   select ty;

                foreach (Type t in contractType)
                {
                    string address = _configManager.GetPlugSettings(t)["WcfURL"];
                    //address = TranslateURL(address) + "/" + areaName + "/" + t.Name;
                    //address = address + "/" + areaName + "/" + t.Name;
                    address = address + "/" + t.Name + ".svc";

                    _log.Info(String.Format("Registering Interface: '{0}' to WCF URL '{1}'", t.Name, address));
                }
            }
            catch (Exception e)
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName), e);
            }
        }

        protected string TranslateURL(string address)
        {
            string url = address;
            string alias = new Uri(url).Host;
            string machineName = Dns.GetHostEntry(alias).HostName;
            return url.Replace(alias, machineName);
        }

        protected BasicHttpBinding GetBasicHttpBinding()
        {
            BasicHttpBinding binding = new BasicHttpBinding()
            {
                Security = new BasicHttpSecurity()
                {
                    Mode = BasicHttpSecurityMode.TransportCredentialOnly,
                    Transport = new HttpTransportSecurity() { ClientCredentialType = HttpClientCredentialType.Windows }
                },
                MaxReceivedMessageSize = int.MaxValue,
                //TransferMode = System.ServiceModel.TransferMode.Streamed,
                TransferMode = System.ServiceModel.TransferMode.Buffered,
                MessageEncoding = WSMessageEncoding.Mtom,
                MaxBufferSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                OpenTimeout = new TimeSpan(0, 30, 0),
                CloseTimeout = new TimeSpan(0, 30, 0),
                ReceiveTimeout = new TimeSpan(0, 30, 0),
                SendTimeout = new TimeSpan(0, 30, 0)
            };

            return binding;
        }
    }

}
