﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public enum RegistrationErrorEnum
    {
        None,
        Component,
        NHibernate,
        Unknown
    }

    public enum ConfigErrorEnum
    {
        None,
        Missing,
        EncryptIssue,
        EnvIssue,
        Unknown
    }

    public enum ConfigStatusEnum
    {
        Error,
        Valid,
        Encrypted
    }

    public enum PlugOnOffEnum
    {
        Offline,
        Online
    }

    public enum PlugStatusEnum
    {
        NotRegistered,
        ReadyForRegistration,
        Registering,
        Error,
        Registered
    }
}
