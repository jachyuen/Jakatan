﻿using Autofac;
using DIS.Framework.Host;
using DIS.Framework.Plugins.Configuration;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class PluginsPackage : IPluginsPackage
    {
        protected IPluginsConfiguration _config;
        protected IPluginsConfigurationManager _configManager;

        public Assembly assembly { get; set; }
        public string Area { get; set; }
        public ILog _log { get; set; }

        private int _patternAreaIndex = (DISHostConfigStatics.PluginsNameStringFormat).Split('.').Select((v, i) => new { obj = v, index = i }).First(x => x.obj.Contains("{1}")).index;
        private PlugOnOffEnum _onoffStatus;

        #region Get/Set

        public PlugStatusEnum Status { get; set; }
        public string PlugType
        {
            get
            {
                return this.assembly.GetName().Name.Split('.')[2];
            }
        }

        public string Name
        {
            get
            {
                return this.assembly.GetName().Name;
            }
        }

        public PlugOnOffEnum OnOff
        {
            get
            {
                if (_config.ConfigStatus == ConfigStatusEnum.Error && Status != PlugStatusEnum.Registered)
                    return PlugOnOffEnum.Offline;

                return _onoffStatus;
            }
            set
            {
                _onoffStatus = value;
            }
        }
        public RegistrationErrorEnum RegistrationError { get; set; }
        public IPluginsConfiguration Config { get { return _config; } }

        //public virtual AreaMap GetMap()
        //{
        //    return new AreaMap { MasterPageLocation = string.Format("~/Views/{0}/Shared/Site.Master", WebHostConfigStatics.DefaultArea) };
        //}

        #endregion

        public PluginsPackage()
        {
            assembly = GetType().Assembly;
            this.Init();
        }

        private void Init()
        {
            Area = assembly.GetName().Name.Split('.')[_patternAreaIndex];

            //if (_config.ConfigStatus != ConfigStatusEnum.Error)
            //{
            //    Status = PlugStatusEnum.ReadyForRegistration;
            //    //this.RegisterAreaEmbeddedResources();
            //}
            //else if (!_config.FileExists())
            //{
            //    Status = PlugStatusEnum.Error;
            //}
        }
        /*
        private void RegisterAreaEmbeddedResources()
        {
            var areaType = GetType();
            var resourceStore = new AssemblyResourceStore(areaType, "/" + Area.ToLower(), areaType.Namespace, GetMap());
            AssemblyResourceManager.RegisterAreaResources(resourceStore);
        }
        */
        protected void SetPluginConfig(IPluginsConfiguration config)
        {
            _config = config;
            _config.AssemblyName = assembly.GetName().Name;
            _config.Init();
            Status = PlugStatusEnum.ReadyForRegistration;
        }
        /// <summary>
        /// Abstract Package registration methode
        /// </summary>
        /// <param name="container">IoC container instance to register plugins components</param>
        /// <param name="routes">Routes Collection</param>
        /// <param name="viewEngines">ViewEngines Collection</param>
        public abstract void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager);

        public virtual void RegisterPluginSpecific(ContainerBuilder builder) { }
    }
}
