﻿using Autofac;
using DIS.Framework.Plugins.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class WCFServicePluginsPackage : ServicePluginsPackage
    {
        public override void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager)
        {
            _configManager = configManager;
            SetPluginConfig(config);
            try
            {
                _log.Debug(String.Format("Registering assembly: {0}", assembly));
                Status = PlugStatusEnum.Registering;
                RegisterService(builder);
                RegisterWCFService(builder, assembly, Area);
                RegisterStandardComponents(builder);
                RegisterPluginSpecific(builder);
                Status = PlugStatusEnum.Registered;
                _log.Debug(String.Format("Assembly {0} is registerd", assembly));
            }
            catch (ComponentRegistrationException cre)
            {
                RegistrationError = RegistrationErrorEnum.Component;
                _log.Error(String.Format("Error while registering assembly: {0}!", assembly), cre);
            }
            catch (Exception e)
            {
                RegistrationError = RegistrationErrorEnum.Unknown;
                _log.Error(String.Format("Error while registering assembly: {0}!", assembly), e);
            }
        }

        private void RegisterWCFService(ContainerBuilder builder, Assembly assembly, string areaName)
        {
            try
            {
                var types = from t in assembly.GetTypes()
                            where (System.Attribute.GetCustomAttributes(t).Where(c => c is System.ServiceModel.ServiceBehaviorAttribute).Count() > 0)
                            select t;

                foreach (Type t in types)
                {
                    var contractType = (from ty in t.GetInterfaces()
                                        where (System.Attribute.GetCustomAttributes(ty).Where(c => c is System.ServiceModel.ServiceContractAttribute).Count() > 0)
                                        select ty).FirstOrDefault();

                    if (contractType != null)
                    {
                        string baseAddress = string.Format("{0}/{1}/{2}",
                            _configManager.GetPlugSettings(this.GetType())[string.Format("WcfURL_{0}", contractType.Name)], 
                            areaName, 
                            contractType.Name);
                        _log.Info(String.Format("Registering Interface: '{0}' to WCF URL '{1}'", contractType.Name, baseAddress));
                        _log.Info(String.Format("type .AssemblyQualifiedName: '{0}'", t.AssemblyQualifiedName));

                        //builder.RegisterType(t).AsImplementedInterfaces();
                        builder.RegisterType(t).AsSelf();
                    }
                }
            }
            catch (Exception e)
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName), e);
            }
        }

        /// <summary>
        /// Components registration methode
        /// </summary>
        /// <param name="container">IoC container instance to register plugins components</param>
        /// <param name="assembly">Plugins assembly to register (DLL)</param>
        /// <param name="areaName">Name of the Plugins to register</param>
        private void RegisterStandardComponents(ContainerBuilder builder)
        {
            try
            {
            }
            catch
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName));
            }
        }
    }
}
