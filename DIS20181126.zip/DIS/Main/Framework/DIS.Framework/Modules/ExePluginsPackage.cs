﻿using Autofac;
using DIS.Framework.Commands;
using DIS.Framework.Plugins.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class ExePluginsPackage : PluginsPackage
    {
        public override void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager)
        {
            _configManager = configManager;
            SetPluginConfig(config);
            if (Status == PlugStatusEnum.ReadyForRegistration)
            {
                try
                {

                    _log.Debug(String.Format("Registering assembly: {0}", assembly));
                    Status = PlugStatusEnum.Registering;
                    RegisterStandardComponents(builder);
                    RegisterPluginSpecific(builder);
                    Status = PlugStatusEnum.Registered;
                    _log.Debug(String.Format("Assembly {0} is registerd", assembly));
                }
                catch (ComponentRegistrationException cre)
                {
                    RegistrationError = RegistrationErrorEnum.Component;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), cre);
                }
                catch (Exception e)
                {
                    RegistrationError = RegistrationErrorEnum.Unknown;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), e);
                }
            }
        }

        /// <summary>
        /// Components registration methode
        /// </summary>
        /// <param name="builder">IoC builder instance to register plugins components</param>
        /// <param name="assembly">Plugins assembly to register (DLL)</param>
        /// <param name="areaName">Name of the Plugins to register</param>
        private void RegisterStandardComponents(ContainerBuilder builder)
        {
            try
            {
                builder.RegisterAssemblyTypes(assembly)
                    .AssignableTo<ICommandHandler>()
                    .Keyed<ICommandHandler>(t => Area.ToLowerInvariant() + "." + t.Name.ToLowerInvariant())
                    .AsImplementedInterfaces()
                    .InstancePerRequest();

                //builder
                //    .Register(AllTypes
                //                  .FromAssembly(Assembly)
                //                  .BasedOn<ICommandHandler>()
                //                  .WithService.FromInterface(typeof(ICommandHandler))
                //                  .Configure(c => c.LifeStyle.Transient))
            }
            catch
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName));
            }
        }
    }
}
