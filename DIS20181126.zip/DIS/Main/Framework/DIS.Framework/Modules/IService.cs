﻿namespace DIS.Framework.Modules
{
    public interface IService
    {
    }
}
