﻿using Autofac;
using DIS.Framework.Plugins.Configuration;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public interface IPluginsPackage
    {
        ILog _log { get; set; }

        void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager);
    }
}
