﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public interface IPluginsCatalogService
    {
        #region Plugins ON / OFF
        void ActivateAllPlugins();
        void ActivatePlugin(PluginsPackage pkg);
        void PutAllOffline();
        void PutOffline(PluginsPackage pkg);
        void PutAllOnline();
        void PutOnline(PluginsPackage pkg);
        PlugOnOffEnum GetStatus(string id);
        #endregion



        /// <summary>
        /// Get the plugins definitin in the catalog based on the areaname
        /// </summary>
        /// <param name="area">area/plugins name</param>
        /// <returns>Plugins definition</returns>
        PluginsPackage GetMvcByArea(string area);

        /// <summary>
        /// Get the plugins definitin in the catalog based on the areaname
        /// </summary>
        /// <param name="area">area/plugins name</param>
        /// <returns>Plugins definition</returns>
        PluginsPackage GetByArea(string plugtype, string area);

        /// <summary>
        /// Get a plugins definition based on the assembly
        /// </summary>
        /// <param name="assembly">Plugins dll/assembly</param>
        /// <returns>Plugins definition</returns>
        PluginsPackage GetByAssembly(Assembly assembly);

        /// <summary>
        /// Gets a PluginsPackage by package name.
        /// </summary>
        /// <param name="assembly">The assembly.</param>
        /// <returns>a PluginsCatalog</returns>
        PluginsPackage GetByName(string pkgName);

        /// <summary>
        /// Get a list of registerd plugins
        /// </summary>
        /// <returns>List of Plugins definition</returns>
        IEnumerable<PluginsPackage> ListPlugins<T>();

        /// <summary>
        /// TO get the list of areas registered in Plugins catalog
        /// </summary>
        /// <returns>List of registered area/plugins</returns>
        IEnumerable<string> ListAreas();

        /// <summary>
        /// Verify that the requested view of an area in the vpath exist
        /// </summary>
        /// <param name="vpath">virtualpath to the are</param>
        /// <returns>TRUE if the plugins/area exists</returns>
        bool AreaViewExist(string vpath);
    }
}
