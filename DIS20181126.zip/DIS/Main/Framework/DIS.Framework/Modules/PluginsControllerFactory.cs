﻿using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.SessionState;

namespace DIS.Framework.Modules
{
    public class PluginsControllerFactory : IControllerFactory
    {
        //private readonly IKernel _kernel;
        //private readonly IPluginsCatalogService _catatlog;
        public ILog log { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="kernel">IoC container instance</param>
        public PluginsControllerFactory()
        { }

        /// <summary>
        /// Method to create a controller
        /// </summary>
        /// <param name="requestContext">Context used to create the controller</param>
        /// <param name="controllerName">Name of controller to create</param>
        /// <returns>A Controller</returns>
        public IController CreateController(RequestContext requestContext, string controllerName)
        {
            var controllerKey = controllerName.ToLowerInvariant() + "controller";
            //object area;

            object area = null;
            if (!requestContext.RouteData.Values.TryGetValue("area", out area))
                area = "null";

            string ctrlName = (string)requestContext.RouteData.Values["controller"];
            string actionName = (string)requestContext.RouteData.Values["action"];

            log.Debug(string.Format("Entering PluginsControllerFactory Area:{0}|Controller:{1}|action:{2}", (string)area, controllerName, actionName));

            if (requestContext.RouteData.Values.TryGetValue("area", out area))
            {
                var areaControllerKey = Convert.ToString(area).ToLowerInvariant() + "." + controllerKey;
                //log.Debug(string.Format("Looking for Area Controller Area:{0}|Controller:{1}|action:{2}", (string)area, controllerName, actionName));
                try
                {
                    return Singleton<IDISHost>.Instance.ContainerManager.Resolve<IController>(areaControllerKey);
                }
                catch (Exception e)
                {
                    log.Error(string.Format("Area controller NOT FOUND Area:{0}|Controller:{1}|action:{2}", (string)area, controllerName, actionName));
                    log.Error(string.Format("Exception: {0}", e.Message));
                    throw new HttpException(404, "HTTP404 - Page Not Found");
                }
            }

            try
            {
                return Singleton<IDISHost>.Instance.ContainerManager.Resolve<IController>(controllerKey);
            }
            catch
            {
                log.Error(string.Format("Controller NOT FOUND Area:{0}|Controller:{1}|action:{2}", (string)area, controllerName, actionName));
                throw new HttpException(404, "HTTP404 - Page Not Found");
            }
        }

        public SessionStateBehavior GetControllerSessionBehavior(RequestContext requestContext, string controllerName)
        {
            return SessionStateBehavior.Default;
        }

        public void ReleaseController(IController controller)
        {
            //_kernel.ReleaseComponent(controller);
        }
    }

}
