﻿using Autofac;
using DIS.Framework.Plugins.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class DuplexContractPluginsPackage : ContractPluginsPackage
    {
        protected override void RegisterWcfClient(ContainerBuilder builder, Assembly assembly, string areaName)
        {
            try
            {
                var contractType = from ty in assembly.GetTypes()
                                   where (System.Attribute.GetCustomAttributes(ty).Where(c => c is System.ServiceModel.ServiceContractAttribute).Count() > 0)
                                   select ty;

                foreach (Type t in contractType)
                {
                    Type callbackContract = (System.Attribute.GetCustomAttribute(t, typeof(ServiceContractAttribute))
                                                as ServiceContractAttribute).CallbackContract;

                    if (callbackContract == null)
                        throw new Exception(string.Format("No callback contract defined for {0}", t.ToString()));

                    //RegisterCallback(container, Assembly, callbackContract);                   

                    string address = _configManager.GetPlugSettings(t)["WcfURL"];
                    address = TranslateURL(address) + "/" + areaName + "/" + t.Name;
                    _log.Info(String.Format("Registering Interface: '{0}' to WCF URL '{1}'", t.Name, address));
                }
            }
            catch (Exception e)
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName), e);
            }
        }
    }
}
