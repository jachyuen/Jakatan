﻿using Autofac;
using DIS.Framework.FileSystems.Plugins;
using DIS.Framework.Host;
using DIS.Framework.Plugins.Configuration;
using DIS.Framework.DataAccess.EntityFrameworkRepository.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Routing;
using DIS.Framework.Security.Authorization;
using FluentValidation;

namespace DIS.Framework.Modules
{
    public abstract class ServicePluginsPackage : PluginsPackage
    {
        protected IUserService _userService { get; set; }

        public override void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager)
        {
            _configManager = configManager;
            SetPluginConfig(config);
            if (Status == PlugStatusEnum.ReadyForRegistration)
            {
                try
                {
                    _log.Debug(String.Format("Registering assembly: {0}", assembly));
                    Status = PlugStatusEnum.Registering;

                    RegisterService(builder);
                    RegisterPluginSpecific(builder);
                    RegisterValidator(builder);

                    Status = PlugStatusEnum.Registered;
                    _log.Debug(String.Format("Assembly {0} is registered", assembly));
                }
                catch (ComponentRegistrationException cre)
                {
                    RegistrationError = RegistrationErrorEnum.Component;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), cre);
                }
                catch (Exception e)
                {
                    RegistrationError = RegistrationErrorEnum.Unknown;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), e);
                }
            }
        }

        protected void RegisterService(ContainerBuilder builder)
        {
            try
            {
                builder.RegisterAssemblyTypes(assembly)
                     .AssignableTo<IService>()
                     .Keyed<IService>(t => Area.ToLowerInvariant() + "." + t.Name.ToLowerInvariant())
                     .AsImplementedInterfaces()
                     .InstancePerLifetimeScope();
            }
            catch
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName));
            }
        }

        protected void RegisterValidator(ContainerBuilder builder)
        {
            try
            {
                builder.RegisterAssemblyTypes(assembly)
                     .AssignableTo<IValidator>()
                     .Keyed<IValidator>(t => t.BaseType.GenericTypeArguments[0].FullName.ToLowerInvariant())
                     .As<IValidator>();
            }
            catch
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName));
            }
        }
    }
}
