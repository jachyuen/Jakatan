﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public class ComponentRegistrationException : Exception
    {
        public ComponentRegistrationException()
        {
        }

        public ComponentRegistrationException(string message)
        : base(message)
        {
        }

        public ComponentRegistrationException(string message, Exception inner)
        : base(message, inner)
        {
        }
    }
}
