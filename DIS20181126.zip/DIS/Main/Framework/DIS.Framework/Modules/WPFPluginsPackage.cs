﻿using Autofac;
using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using DIS.Framework.Navigation;
using DIS.Framework.Plugins.Common;
using DIS.Framework.Plugins.Configuration;
using DIS.Framework.Security.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Modules
{
    public abstract class WPFPluginsPackage : PluginsPackage
    {
        public override void Register(ContainerBuilder builder, IPluginsConfiguration config, IPluginsConfigurationManager configManager)
        {
            _configManager = configManager;
            SetPluginConfig(config);
            if (Status == PlugStatusEnum.ReadyForRegistration)
            {
                try
                {
                    _log.Debug(String.Format("Registering assembly: {0}", assembly));
                    Status = PlugStatusEnum.Registering;
                    RegisterStandardComponents(builder, assembly, Area);

                    RegisterPluginSpecific(builder);
                    //RegisterAuthorizations();
                    Status = PlugStatusEnum.Registered;
                    OnOff = PlugOnOffEnum.Online;

                    _log.Debug(String.Format("Assembly {0} is registered", assembly));
                }
                catch (ComponentRegistrationException cre)
                {
                    RegistrationError = RegistrationErrorEnum.Component;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), cre);
                }
                catch (Exception e)
                {
                    RegistrationError = RegistrationErrorEnum.Unknown;
                    _log.Error(String.Format("Error while registering assembly: {0}!", assembly), e);
                }
            }
        }

        private void RegisterStandardComponents(ContainerBuilder builder, Assembly assembly, string areaName)
        {
            try
            {
                builder.RegisterAssemblyTypes(assembly)
                    .AssignableTo<IPermissionProvider>()
                    .Keyed<IPermissionProvider>(t => areaName.ToLowerInvariant() + "." + t.Name.ToLowerInvariant())
                    .AsImplementedInterfaces()
                    .InstancePerRequest();

                builder.RegisterAssemblyTypes(assembly)
                    .AssignableTo<IPluginMenuProvider>()
                    .Keyed<IPluginMenuProvider>(t => areaName.ToLowerInvariant() + "." + t.Name.ToLowerInvariant())
                    .AsImplementedInterfaces()
                    .InstancePerRequest();
            }
            catch
            {
                throw new ComponentRegistrationException(String.Format("Component registration issue: {0}", assembly.FullName));
            }
        }

        ///// <summary>
        ///// Auto registration of plugin permissions and roles
        ///// </summary>
        ///// <param name="container"></param>
        public void RegisterAuthorizations()
        {
            IAuthorizationService aservice = null;
            IRoleService rservice = null;
            try
            {
                aservice = Singleton<IDISHost>.Instance.Resolve<IAuthorizationService>();
                rservice = Singleton<IDISHost>.Instance.Resolve<IRoleService>();
            }
            catch (Exception e)
            {
                _log.Error("Cannot Resolve security interfaces at registration", e);
                throw new Exception("Cannot Resolve security interfaces at registration", e);
            }

            try
            {
                IPermissionProvider permission = Singleton<IDISHost>.Instance.ContainerManager.Resolve<IPermissionProvider>(Area.ToLowerInvariant() + ".permissions");
                IEnumerable<PluginPermission> pplugin = permission.GetPermissions();

                //add permissions
                foreach (PluginPermission p in pplugin)
                {
                    rservice.AddPermission(new AppPermission() { Name = p.Name, Description = p.Description, ApplicationCode = Area });
                }

                IEnumerable<PluginRole> rplugin = permission.GetRoles();

                //create role and add permission to roles
                foreach (PluginRole r in rplugin)
                {
                    AppRole appRole = new AppRole() { Name = r.Name, ApplicationCode = Area, Description = r.Description };
                    rservice.AddRole(appRole);
                    appRole = rservice.GetAppRole(r.Name, Area);
                    foreach (PluginPermission p in r.Permissions)
                    {
                        var ap = rservice.GetAppPermission(p.Name, Area);
                        rservice.AddAppPermissionToRole(ap, appRole);
                    }
                }

                //update permissions which doesn t exists anymore in the plugin. Might not be a good idea to remove permission here. just mark it as IsDeleted.
                IEnumerable<AppPermission> permissions = rservice.GetAllAppPermissionsForAppCode(Area);
                foreach (AppPermission p in permissions)
                {
                    PluginPermission ppfind = pplugin.FirstOrDefault(x => x.Name.Trim().ToLowerInvariant() == p.Name.Trim().ToLowerInvariant());
                    if (ppfind == null)
                    {
                        //rservice.DeletePermission(p);
                        p.IsDeleted = true;
                        rservice.UpdatePermission(p);
                    }
                }
            }
            catch (Exception e)
            {
                _log.Debug("No permission provider detected OR error adding record to database, this Application: " + Area + " might not use RBAC", e);
            }
        }
    }
}
