﻿using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace DIS.Framework.Modules
{
    public class PluginsCatalogService : IPluginsCatalogService
    {
        private IDISHost _host;
        public PluginsCatalogService(IDISHost host)
        {
            _host = host;
        }

        private IEnumerable<PluginsPackage> _packages; // = ServiceLocator.Current.GetAllInstances<IPluginsPackage>().Cast<PluginsPackage>();
        public IEnumerable<PluginsPackage> Packages
        {
            get {
                if (_packages == null)
                    _packages = _host.ResolveAll<IPluginsPackage>().Cast<PluginsPackage>();
                return _packages;
            }
        }
        public ILog _log { get; set; }

        #region Plugins ON / OFF
        public void PutOnline(PluginsPackage pkg)
        {
            if (pkg.Status == PlugStatusEnum.Registered)
            {
                pkg.OnOff = PlugOnOffEnum.Online;
                this.SavePlugStatus();
            }
        }

        public void PutOffline(PluginsPackage pkg)
        {
            if (pkg.Status == PlugStatusEnum.Registered)
            {
                pkg.OnOff = PlugOnOffEnum.Offline;
                this.SavePlugStatus();
            }
        }

        public void PutAllOnline()
        {
            foreach (PluginsPackage pkg in Packages)
            {
                PutOnline(pkg);
            }
        }

        public void PutAllOffline()
        {
            foreach (PluginsPackage pkg in Packages)
            {
                PutOffline(pkg);
            }
        }

        public void ActivateAllPlugins()
        {
            foreach (PluginsPackage pkg in Packages)
            {
                this.ActivatePlugin(pkg);
            }

            this.SavePlugStatus();
        }

        public void ActivatePlugin(PluginsPackage pkg)
        {
            try
            {
                if (pkg.Status != PlugStatusEnum.Registered)
                {
                    this.PutOffline(pkg);
                }
                else
                {
                    pkg.OnOff = PlugOnOffEnum.Online;
                }
            }
            catch (Exception)
            {
                this.PutOffline(pkg);
            }
        }
        private void SavePlugStatus()
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "\t";
            settings.NewLineChars = "\n";

            int count = 0;
            while (count < 5)
            {
                try
                {
                    using (XmlWriter writer = XmlWriter.Create(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + DISHostConfigStatics.PluginsList), settings))
                    {
                        writer.WriteStartDocument();
                        writer.WriteStartElement("PLUGINS");
                        foreach (var item in Packages.Select(p => new
                        {
                            p.Area,
                            p.PlugType,
                            p.OnOff,
                            p.assembly.GetName().Name
                        }))
                        {
                            writer.WriteStartElement("PLUGIN");
                            writer.WriteStartAttribute("CODE");
                            writer.WriteValue(item.Area);
                            writer.WriteEndAttribute();
                            writer.WriteStartAttribute("TYPE");
                            writer.WriteValue(item.PlugType);
                            writer.WriteEndAttribute();
                            writer.WriteStartAttribute("STATUS");
                            writer.WriteValue(item.OnOff.ToString());
                            writer.WriteEndAttribute();
                            writer.WriteStartAttribute("ASSEMBLY");
                            writer.WriteValue(item.Name);
                            writer.WriteEndAttribute();
                            writer.WriteEndElement();
                        }

                        writer.WriteEndDocument();
                        writer.Close();
                    }
                    break;
                }
                catch (Exception ex)
                {
                    _log.Warn(string.Format("{0}. Try for {1} times", ex.Message, count + 1));
                    Thread.Sleep(100);
                    count++;
                }
            }
        }

        public PlugOnOffEnum GetStatus(string id)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + DISHostConfigStatics.PluginsList));
            XmlNodeList list = null;

            list = doc.GetElementsByTagName("PLUGIN");
            foreach (XmlNode node in list)
            {
                if (node.Attributes["CODE"].Value.ToUpperInvariant() == id.ToUpperInvariant())
                    return (PlugOnOffEnum)Enum.Parse(typeof(PlugOnOffEnum), node.Attributes["STATUS"].Value, true);
            }
            return PlugOnOffEnum.Offline;
            //throw new Exception("No Plugin found");
        }
        #endregion

        public PluginsPackage GetMvcByArea(string area)
        {
            return GetByArea("WEB", area);
        }

        /// <summary>
        /// Gets the PluginsCatalog by area.
        /// </summary>
        /// <param name="area">The area.</param>
        /// <returns>a PluginsCatalog</returns>
        public PluginsPackage GetByArea(string type, string area)
        {
            return Packages.Where(p => p.Area == area)
                .Where(p => p.PlugType.ToLowerInvariant() == type.ToLowerInvariant())
                .SingleOrDefault();
            //return _pluginsCatalogRepository.Where(plug => plug.Area == area).Single();
        }

        /// <summary>
        /// Gets a PluginsPackage by assembly.
        /// </summary>
        /// <param name="assembly">The assembly.</param>
        /// <returns>a PluginsCatalog</returns>
        public PluginsPackage GetByAssembly(Assembly assembly)
        {
            return Packages.Where(p => p.assembly.FullName == assembly.FullName).Single();
        }

        /// <summary>
        /// Gets a PluginsPackage by package name.
        /// </summary>
        /// <param name="assembly">The assembly.</param>
        /// <returns>a PluginsCatalog</returns>
        public PluginsPackage GetByName(string pkgName)
        {
            return Packages.Where(p => p.assembly.GetName().Name == pkgName).Single();
        }

        /// <summary>
        /// Lists the Plugins.
        /// </summary>
        /// <returns>List of plugins</returns>
        public IEnumerable<PluginsPackage> ListPlugins<T>()
        {
            return Packages.Where(p => p is T);
        }

        /// <summary>
        /// Lists the areas.
        /// </summary>
        /// <returns>List of areas</returns>
        public IEnumerable<string> ListAreas()
        {
            return Packages.Select(p => p.Area);
        }

        /// <summary>
        /// Find if a view from a area exists
        /// </summary>
        /// <param name="vpath">The virtualpath to the resource</param>
        /// <returns><c>true</c> if the view of a given area exist</returns>
        public bool AreaViewExist(string vpath)
        {
            try
            {
                string[] parts = vpath.Split('/');
                string area = parts[2].ToLowerInvariant();
                string viewName = null;
                if (parts.Length == 5)
                    viewName = "DIS.Plugin.MVC." + parts[2] + ".Package" + ".Views." + parts[3] + "." + parts[4];
                else if (parts.Length == 6)
                    viewName = "DIS.Plugin.MVC." + parts[2] + ".Package" + ".Views." + parts[3] + "." + parts[4] + "." + parts[5];
                //string resourceName = assemblyName + ".Views." + parts[3] + "." + parts[4];
                Packages.Where(p => p.Area.ToLowerInvariant() == area && p.PlugType.ToLowerInvariant() == "mvc")
                    .Single().assembly.GetManifestResourceNames()
                    .Where(view => view.Equals(viewName, StringComparison.InvariantCultureIgnoreCase)).Single();
                return true;
            }
            catch
            {
                return false;
            }
        }

    }
}
