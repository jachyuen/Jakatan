﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    [DataContract]
    public class CommandParameters
    {
        [DataMember]
        public IList<string> Arguments { get; set; }

        [DataMember]
        public IDictionary<string, string> Switches { get; set; }

        public new string ToString()
        {
            return string.Format("\"{0} {1}\"",
                        this.Arguments.Count() > 0 ? this.Arguments.Aggregate((current, next) => current + " " + next) : "",
                        this.Switches.Count() > 0 ? this.Switches.Select((pair) => "/" + pair.Key + ":" + pair.Value).Aggregate((current, next) => current + " " + next) : "");
        }
    }
}
