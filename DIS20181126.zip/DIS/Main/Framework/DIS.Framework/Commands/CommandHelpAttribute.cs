﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    [AttributeUsage(AttributeTargets.Method)]
    public class CommandHelpAttribute : Attribute
    {
        public CommandHelpAttribute(string text)
        {
            this.HelpText = text;
        }

        public string HelpText { get; set; }
    }
}
