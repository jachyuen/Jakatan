﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public abstract class CommandHandler : ICommandHandler
    {
        public CommandContext Context { get; set; }

        public int Execute(CommandContext context)
        {
            SetSwitchValues(context);
            return Invoke(context);
        }

        private void SetSwitchValues(CommandContext context)
        {
            if (context.Switches != null && context.Switches.Any())
            {
                foreach (var commandSwitch in context.Switches)
                {
                    SetSwitchValue(commandSwitch);
                }
            }
        }

        private void SetSwitchValue(KeyValuePair<string, string> commandSwitch)
        {
            // Find the property
            PropertyInfo propertyInfo = GetType().GetProperty(commandSwitch.Key, BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
            if (propertyInfo == null)
            {
                throw new InvalidOperationException(string.Format("Switch \"{0}\" was not found", commandSwitch.Key));
            }
            if (propertyInfo.GetCustomAttributes(typeof(CommandSwitchAttribute), false).Length == 0)
            {
                throw new InvalidOperationException(string.Format("A property \"{0}\" exists but is not decorated with \"{1}\"", commandSwitch.Key, typeof(CommandSwitchAttribute).Name));
            }

            // Set the value
            try
            {
                object value = Convert.ChangeType(commandSwitch.Value, propertyInfo.PropertyType);
                propertyInfo.SetValue(this, value, null/*index*/);
            }
            catch (Exception e)
            {
                string message = string.Format("Error converting value \"{0}\" to \"{1}\" for switch \"{2}\"",
                    commandSwitch.Value,
                    propertyInfo.PropertyType.FullName,
                    commandSwitch.Key);
                throw new InvalidOperationException(message, e);
            }
        }

        private int Invoke(CommandContext context)
        {
            CheckMethodForSwitches(context.CommandDescriptor.MethodInfo, context.Switches);

            var arguments = (context.Arguments ?? Enumerable.Empty<string>()).ToArray();
            object[] invokeParameters = GetInvokeParametersForMethod(context.CommandDescriptor.MethodInfo, arguments);
            if (invokeParameters == null)
            {
                throw new InvalidOperationException(string.Format("Command arguments \"{0}\" don't match command definition", string.Join(" ", arguments)));
            }

            this.Context = context;

            int returnCode = (int)CommandReturnCodes.Error;
            try
            {
                var result = context.CommandDescriptor.MethodInfo.Invoke(this, invokeParameters);
                if (result is int)
                    returnCode = (int)result;
                else
                    throw new InvalidOperationException(string.Format("Command - {0} - do not return an INT value nor a CommandReturnCodes", context.Command));
            }
            catch (InvalidOperationException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex.InnerException;
            }

            return returnCode;
        }

        private static object[] GetInvokeParametersForMethod(MethodInfo methodInfo, IList<string> arguments)
        {
            var invokeParameters = new List<object>();
            var args = new List<string>(arguments);
            var methodParameters = methodInfo.GetParameters();
            bool methodHasParams = false;

            if (methodParameters.Length == 0)
            {
                if (args.Count == 0)
                    return invokeParameters.ToArray();
                return null;
            }

            if (methodParameters[methodParameters.Length - 1].ParameterType.IsAssignableFrom(typeof(string[])))
            {
                methodHasParams = true;
            }

            if (!methodHasParams && args.Count != methodParameters.Length) return null;
            if (methodHasParams && (methodParameters.Length - args.Count >= 2)) return null;

            for (int i = 0; i < args.Count; i++)
            {
                if (methodParameters[i].ParameterType.IsAssignableFrom(typeof(string[])))
                {
                    invokeParameters.Add(args.GetRange(i, args.Count - i).ToArray());
                    break;
                }
                invokeParameters.Add(arguments[i]);
            }

            if (methodHasParams && (methodParameters.Length - args.Count == 1)) invokeParameters.Add(new string[] { });

            return invokeParameters.ToArray();
        }

        private void CheckMethodForSwitches(MethodInfo methodInfo, IDictionary<string, string> switches)
        {
            if (switches == null || switches.Count == 0)
                return;

            var supportedSwitches = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (CommandSwitchesAttribute switchesAttribute in methodInfo.GetCustomAttributes(typeof(CommandSwitchesAttribute), false))
            {
                supportedSwitches.UnionWith(switchesAttribute.Switches);
            }

            foreach (var commandSwitch in switches.Keys)
            {
                if (!supportedSwitches.Contains(commandSwitch))
                {
                    throw new InvalidOperationException(string.Format("Method \"{0}\" does not support switch \"{1}\".", methodInfo.Name, commandSwitch));
                }
            }
        }
    }
}
