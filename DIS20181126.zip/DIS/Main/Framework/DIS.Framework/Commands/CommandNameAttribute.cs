﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    [AttributeUsage(AttributeTargets.Method)]
    public class CommandNameAttribute : Attribute
    {
        private readonly string _commandAlias;

        public CommandNameAttribute(string commandAlias)
        {
            _commandAlias = commandAlias;
        }

        public string Command
        {
            get { return _commandAlias; }
        }
    }
}
