﻿using DIS.Framework.Modules;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands.BuiltIn
{
    public class PluginsListCommand : CommandHandler
    {
        private readonly IPluginsCatalogService _pluginsCatalogService;

        public PluginsListCommand(IPluginsCatalogService pluginsCatalogService)
        { _pluginsCatalogService = pluginsCatalogService; }

        private string PluginCount(String PluginType, IEnumerable<PluginsPackage> plugins)
        {
            return String.Format("Number of Plugins(Type:{0}) : {1}", PluginType, plugins.Where(row => row.PlugType.Equals(PluginType, StringComparison.InvariantCultureIgnoreCase)).Count());
        }

        [CommandName("PluginsList")]
        [CommandHelp("PluginsList\r\n\t" + "Display version and status information for all plugins")]
        public int SingleCommand(string[] pluginStrings)
        {
            foreach (PluginsPackage p in _pluginsCatalogService.ListPlugins<PluginsPackage>())
            {
                Context.Output.WriteLine(String.Format("Area={0,-18} PluginType={1,-10} Status={2,-15} FileVersion={3,-10}",
                    p.Area, p.PlugType, p.Status.ToString(), System.Diagnostics.FileVersionInfo.GetVersionInfo(p.assembly.Location).FileVersion));
            }

            Context.Output.WriteLine();
            Context.Output.WriteLine(PluginCount("Contract", _pluginsCatalogService.ListPlugins<PluginsPackage>()));
            Context.Output.WriteLine(PluginCount("Exe", _pluginsCatalogService.ListPlugins<PluginsPackage>()));
            Context.Output.WriteLine(PluginCount("Service", _pluginsCatalogService.ListPlugins<PluginsPackage>()));
            return (int)CommandReturnCodes.Ok;
        }
    }
}
