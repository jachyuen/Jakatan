﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands.BuiltIn
{
    public class HelpCommand : CommandHandler
    {
        private readonly ICommandManager _commandManager;

        public HelpCommand(ICommandManager commandManager)
        {
            _commandManager = commandManager;
        }

        [CommandName("help commands")]
        [CommandHelp("help commands\r\n\t" + "Display help text for all available commands")]
        public int AllCommands()
        {
            Context.Output.WriteLine("List of available commands:");
            Context.Output.WriteLine("---------------------------");
            Context.Output.WriteLine();

            var descriptors = _commandManager.GetCommandDescriptors().OrderBy(d => d.Name);
            foreach (var descriptor in descriptors)
            {
                Context.Output.WriteLine(GetHelpText(descriptor));
                Context.Output.WriteLine();
            }
            return (int)CommandReturnCodes.Ok;
        }

        private string GetHelpText(CommandDescriptor descriptor)
        {
            if (string.IsNullOrEmpty(descriptor.Help))
            {
                return String.Format("{0}: no help text",
                         descriptor.MethodInfo.DeclaringType.FullName + "." + descriptor.MethodInfo.Name);
            }

            return descriptor.Help;
        }

        [CommandName("help")]
        [CommandHelp("help <command>\r\n\t" + "Display help text for <command>")]
        public int SingleCommand(string[] commandNameStrings)
        {
            string command = string.Join(" ", commandNameStrings);
            //var descriptor = _commandManager.GetCommandDescriptors().SingleOrDefault(d => string.Equals(command, d.Name, StringComparison.OrdinalIgnoreCase));
            var descriptors = _commandManager.GetCommandDescriptors().Where(d => d.Name.ToLower().Contains(command.ToLower()));
            if (descriptors == null || descriptors.Count() <= 0)
            {
                Context.Output.WriteLine(string.Format("Command {0} doesn't exist", command));
            }
            else
            {
                //Context.Output.WriteLine(GetHelpText(descriptor));
                foreach (var descriptor in descriptors)
                {
                    Context.Output.WriteLine(GetHelpText(descriptor));
                    Context.Output.WriteLine();
                }
            }
            return (int)CommandReturnCodes.Ok;
        }
    }
}
