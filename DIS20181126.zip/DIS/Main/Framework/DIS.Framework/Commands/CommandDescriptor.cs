﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public class CommandDescriptor
    {
        public string Name { get; set; }
        public MethodInfo MethodInfo { get; set; }
        public string Help { get; set; }
    }
}
