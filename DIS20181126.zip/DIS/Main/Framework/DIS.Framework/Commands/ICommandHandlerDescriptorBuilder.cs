﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public interface ICommandHandlerDescriptorBuilder
    {
        CommandHandlerDescriptor Build(Type type);
    }
}
