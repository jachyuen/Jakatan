﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public class CommandContext
    {
        public string Command { get; set; }
        public IEnumerable<string> Arguments { get; set; }
        public IDictionary<string, string> Switches { get; set; }
        public CommandDescriptor CommandDescriptor { get; set; }
        public CommandStringWriter Output { get; set; }
    }
}
