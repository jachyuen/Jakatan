﻿using DIS.Framework.Host;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public class CommandManager : ICommandManager
    {
        private IDISHost _host;
        private ICommandHandlerDescriptorBuilder _builder;
        private EventArgs e = null;
        public delegate void Write(CommandStringWriter writer, EventArgs e);
        public event Write output;

        public CommandManager(IDISHost host,
            ICommandHandlerDescriptorBuilder builder)
        {
            _host = host;
            _builder = builder;
        }

        public int Execute(CommandParameters parameters)
        {
            var matches = MatchCommands(parameters);

            if (matches.Count() == 1)
            {
                var match = matches.Single();
                int retVal = match.Execute(((CommandHandler)match).Context);
                DisposeCommand((CommandHandler)match);
                return retVal;
            }
            else
            {
                var commandMatch = string.Join(" ", parameters.Arguments.ToArray());
                var commandList = string.Join(",", GetCommandDescriptors().Select(d => d.Name).ToArray());
                if (matches.Any())
                {
                    throw new ArgumentException(string.Format("Multiple commands found matching arguments \"{0}\". Commands available: {1}.",
                                                             commandMatch, commandList));
                }
                throw new ArgumentException(string.Format("No command found matching arguments \"{0}\". Commands available: {1}.",
                                                 commandMatch, commandList));
            }
        }

        public IEnumerable<CommandDescriptor> GetCommandDescriptors()
        {
            //TODO: re-factor the service locator thing
            IEnumerable<ICommandHandler> listCommandHandler = _host.ResolveAll<ICommandHandler>();
            if (listCommandHandler.Count() > 0)
                return listCommandHandler.SelectMany(h => GetDescriptor(h).Commands);

            return Enumerable.Empty<CommandDescriptor>();
        }

        private IEnumerable<ICommandHandler> MatchCommands(CommandParameters parameters)
        {
            //TODO: re-factor the service locator thing
            IEnumerable<ICommandHandler> listCommandHandler = _host.ResolveAll<ICommandHandler>();
            if (listCommandHandler.Count() > 0)
                listCommandHandler.SelectMany(h => GetDescriptor(h).Commands);
            else
                Enumerable.Empty<ICommandHandler>();

            // Command names are matched with as many arguments as possible, in decreasing order
            foreach (var argCount in Enumerable.Range(1, parameters.Arguments.Count()).Reverse())
            {
                int count = argCount;
                var matches = listCommandHandler.SelectMany(h => MatchCommands(parameters, count, h)).ToList();
                if (matches.Any())
                    return matches;
            }

            return Enumerable.Empty<ICommandHandler>();
        }

        private IEnumerable<ICommandHandler> MatchCommands(CommandParameters parameters, int argCount, ICommandHandler handler)
        {
            CommandHandlerDescriptor descriptor = GetDescriptor(handler);
            foreach (var commandDescriptor in descriptor.Commands)
            {
                var names = commandDescriptor.Name.Split(' ');
                if (!parameters.Arguments.Take(argCount).SequenceEqual(names, StringComparer.OrdinalIgnoreCase))
                {
                    // leading arguments not equal to command name
                    continue;
                }

                var writer = new CommandStringWriter(true);
                writer.Flushed += new CommandStringWriter.FlushEventHandler(FlushWriter);

                ((CommandHandler)handler).Context = new CommandContext
                {
                    Arguments = parameters.Arguments.Skip(names.Count()),
                    Command = string.Join(" ", names),
                    CommandDescriptor = commandDescriptor,
                    Output = writer,
                    Switches = parameters.Switches,
                };

                yield return handler;
            }
        }

        private CommandHandlerDescriptor GetDescriptor(ICommandHandler handler)
        {
            return _builder.Build(handler.GetType());
        }

        //Callback to redirect StringWriter from CommandHander to Command
        private void FlushWriter(object sender, EventArgs args)
        {
            output((CommandStringWriter)sender, e);
        }

        private void DisposeCommand(CommandHandler handler)
        {
            handler.Context.Output.Close();
            handler.Context.Output.Dispose();
        }

    }
}
