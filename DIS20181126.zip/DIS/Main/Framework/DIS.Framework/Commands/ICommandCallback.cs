﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Commands
{
    public interface ICommandCallback
    {
        [OperationContract]
        void SendResult(string message);

        [OperationContract]
        void IsAlive();
    }
}
