﻿using log4net;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DIS.Framework.Security
{
    public class CryptoHelper : ICryptoHelper
    {
        private CspParameters _cspParams = null;
        private RSACryptoServiceProvider _rsaKey = null;
        public ILog _log { get; set; }

        public CryptoHelper(ILog log)
        {
            _log = log;
        }

        /// <summary>
        /// Encrypts the plugins config.
        /// </summary>
        /// <param name="input">file to encrypt</param>
        /// <param name="output">save as</param>
        public XmlDocument EncryptXML(string input)
        {
            // Create an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                // Load an XML file into the XmlDocument object.
                xmlDoc.PreserveWhitespace = true;
                xmlDoc.Load(input);

                // Create a new CspParameters object to specify
                // a key container.
                _cspParams = new CspParameters();
                _cspParams.KeyContainerName = "XML_ENC_RSA_KEY";
                _cspParams.Flags = CspProviderFlags.UseMachineKeyStore;
                
                CryptoKeyAccessRule rule = new CryptoKeyAccessRule("Everyone", CryptoKeyRights.FullControl, AccessControlType.Allow);
                _cspParams.CryptoKeySecurity = new CryptoKeySecurity();
                _cspParams.CryptoKeySecurity.SetAccessRule(rule);

                // Create a new RSA key and save it in the container.  This key will encrypt
                // a symmetric key, which will then be encryped in the XML document.
                _rsaKey = new RSACryptoServiceProvider(_cspParams);

                // Encrypt the "configuration" element.
                EncryptXMLElement(xmlDoc, "configuration", "EncryptedElement1", _rsaKey, "rsaKey");

                // Save the XML document.
                return xmlDoc;
            }
            catch (Exception e)
            {
                _log.Error(string.Format("Exception encrypting external config file [{0}]. message={1}", input, e.Message));
                throw;
            }
            finally
            {
                // Clear the RSA key.
                if (_rsaKey != null)
                    _rsaKey.Clear();
            }
        }


        /// <summary>
        /// Encrypts the plugins config.
        /// </summary>
        /// <param name="input">file to encrypt</param>
        /// <param name="output">save as</param>
        public void EncryptXMLFile(string input, string output)
        {
            // Create an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                // Load an XML file into the XmlDocument object.
                xmlDoc.PreserveWhitespace = true;
                xmlDoc.Load(input);

                // Create a new CspParameters object to specify
                // a key container.
                _cspParams = new CspParameters();
                _cspParams.KeyContainerName = "XML_ENC_RSA_KEY";
                _cspParams.Flags = CspProviderFlags.UseMachineKeyStore;

                CryptoKeyAccessRule rule = new CryptoKeyAccessRule("Everyone", CryptoKeyRights.FullControl, AccessControlType.Allow);
                _cspParams.CryptoKeySecurity = new CryptoKeySecurity();
                _cspParams.CryptoKeySecurity.SetAccessRule(rule);

                // Create a new RSA key and save it in the container.  This key will encrypt
                // a symmetric key, which will then be encryped in the XML document.
                _rsaKey = new RSACryptoServiceProvider(_cspParams);

                // Encrypt the "configuration" element.
                EncryptXMLElement(xmlDoc, "configuration", "EncryptedElement1", _rsaKey, "rsaKey");

                // Save the XML document.
                xmlDoc.Save(output);
            }
            catch (Exception e)
            {
                _log.Error(string.Format("Exception encrypting external config file [{0}]. message={1}", input, e.Message));
                throw;
            }
            finally
            {
                // Clear the RSA key.
                if (_rsaKey != null)
                    _rsaKey.Clear();
            }
        }

        /// <summary>
        /// Encrypts the plugins config.
        /// </summary>
        /// <param name="Doc">The doc.</param>
        public void EncryptPluginsConfig(string Doc)
        {
            // Create an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            // Load an XML file into the XmlDocument object.
            try
            {
                xmlDoc.PreserveWhitespace = true;
                xmlDoc.Load(Doc);
            }
            catch (Exception e)
            {
                _log.Error("Issue during plugins config encryption", e);
                throw;
            }

            // Create a new CspParameters object to specify
            // a key container.
            _cspParams = new CspParameters();
            _cspParams.KeyContainerName = "XML_ENC_RSA_KEY";
            _cspParams.Flags = CspProviderFlags.UseMachineKeyStore;

            CryptoKeyAccessRule rule = new CryptoKeyAccessRule("Everyone", CryptoKeyRights.FullControl, AccessControlType.Allow);
            _cspParams.CryptoKeySecurity = new CryptoKeySecurity();
            _cspParams.CryptoKeySecurity.SetAccessRule(rule);

            // Create a new RSA key and save it in the container.  This key will encrypt
            // a symmetric key, which will then be encryped in the XML document.
            _rsaKey = new RSACryptoServiceProvider(_cspParams);

            try
            {
                // Encrypt the "configuration" element.
                EncryptXMLElement(xmlDoc, "configuration", "EncryptedElement1", _rsaKey, "rsaKey");

                // Save the XML document.
                xmlDoc.Save(Doc);
            }
            catch (Exception e)
            {
                _log.Error("Issue during plugins config encryption", e);
                throw;
            }
            finally
            {
                // Clear the RSA key.
                if (_rsaKey != null)
                    _rsaKey.Clear();
            }
        }

        /// <summary>
        /// Encrypts the XML element.
        /// </summary>
        /// <param name="Doc">The doc.</param>
        /// <param name="ElementToEncrypt">The element to encrypt.</param>
        /// <param name="EncryptionElementID">The encryption element ID.</param>
        /// <param name="Alg">The alg.</param>
        /// <param name="KeyName">Name of the key.</param>
        public void EncryptXMLElement(XmlDocument Doc, string ElementToEncrypt, string EncryptionElementID, RSA Alg, string KeyName)
        {
            // Check the arguments.
            if (Doc == null)
                throw new ArgumentNullException("Doc");
            if (ElementToEncrypt == null)
                throw new ArgumentNullException("ElementToEncrypt");
            if (EncryptionElementID == null)
                throw new ArgumentNullException("EncryptionElementID");
            if (Alg == null)
                throw new ArgumentNullException("Alg");
            if (KeyName == null)
                throw new ArgumentNullException("KeyName");

            ////////////////////////////////////////////////
            // Find the specified element in the XmlDocument
            // object and create a new XmlElemnt object.
            ////////////////////////////////////////////////
            XmlElement elementToEncrypt = Doc.GetElementsByTagName(ElementToEncrypt)[0] as XmlElement;

            // Throw an XmlException if the element was not found.
            if (elementToEncrypt == null)
            {
                throw new XmlException("The specified element was not found");

            }
            RijndaelManaged sessionKey = null;

            try
            {
                //////////////////////////////////////////////////
                // Create a new instance of the EncryptedXml class
                // and use it to encrypt the XmlElement with the
                // a new random symmetric key.
                //////////////////////////////////////////////////

                // Create a 256 bit Rijndael key.
                sessionKey = new RijndaelManaged();
                sessionKey.KeySize = 256;

                EncryptedXml eXml = new EncryptedXml();

                byte[] encryptedElement = eXml.EncryptData(elementToEncrypt, sessionKey, false);
                ////////////////////////////////////////////////
                // Construct an EncryptedData object and populate
                // it with the desired encryption information.
                ////////////////////////////////////////////////

                EncryptedData edElement = new EncryptedData();
                edElement.Type = EncryptedXml.XmlEncElementUrl;
                edElement.Id = EncryptionElementID;
                // Create an EncryptionMethod element so that the
                // receiver knows which algorithm to use for decryption.

                edElement.EncryptionMethod = new EncryptionMethod(EncryptedXml.XmlEncAES256Url);
                // Encrypt the session key and add it to an EncryptedKey element.
                EncryptedKey ek = new EncryptedKey();

                byte[] encryptedKey = EncryptedXml.EncryptKey(sessionKey.Key, Alg, false);

                ek.CipherData = new CipherData(encryptedKey);

                ek.EncryptionMethod = new EncryptionMethod(EncryptedXml.XmlEncRSA15Url);

                // Create a new DataReference element
                // for the KeyInfo element.  This optional
                // element specifies which EncryptedData
                // uses this key.  An XML document can have
                // multiple EncryptedData elements that use
                // different keys.
                DataReference dRef = new DataReference();

                // Specify the EncryptedData URI.
                dRef.Uri = "#" + EncryptionElementID;

                // Add the DataReference to the EncryptedKey.
                ek.AddReference(dRef);
                // Add the encrypted key to the
                // EncryptedData object.

                edElement.KeyInfo.AddClause(new KeyInfoEncryptedKey(ek));
                // Set the KeyInfo element to specify the
                // name of the RSA key.


                // Create a new KeyInfoName element.
                KeyInfoName kin = new KeyInfoName();

                // Specify a name for the key.
                kin.Value = KeyName;

                // Add the KeyInfoName element to the
                // EncryptedKey object.
                ek.KeyInfo.AddClause(kin);
                // Add the encrypted element data to the
                // EncryptedData object.
                edElement.CipherData.CipherValue = encryptedElement;
                ////////////////////////////////////////////////////
                // Replace the element from the original XmlDocument
                // object with the EncryptedData element.
                ////////////////////////////////////////////////////
                EncryptedXml.ReplaceElement(elementToEncrypt, edElement, false);
            }
            catch (Exception e)
            {
                // re-throw the exception.
                _log.Error(string.Format("Exception encrypting XML element. message={0}", e.Message));
                throw;
            }
            finally
            {
                if (sessionKey != null)
                {
                    sessionKey.Clear();
                }
            }
        }

        /// <summary>
        /// Decrypts the plugins config.
        /// </summary>
        /// <param name="Doc">The doc.</param>
        /// <returns></returns>
        public XmlDocument DecryptPluginsConfig(string Doc)
        {
            // Create an XmlDocument object.
            XmlDocument xmlDoc = new XmlDocument();

            // Load an XML file into the XmlDocument object.
            try
            {
                xmlDoc.PreserveWhitespace = true;

                xmlDoc.Load(Doc);

                // Create a new CspParameters object to specify
                // a key container.
                _cspParams = new CspParameters();
                _cspParams.KeyContainerName = "XML_ENC_RSA_KEY";
                _cspParams.Flags = CspProviderFlags.UseMachineKeyStore;

                CryptoKeyAccessRule rule = new CryptoKeyAccessRule("Everyone", CryptoKeyRights.FullControl, AccessControlType.Allow);
                _cspParams.CryptoKeySecurity = new CryptoKeySecurity();
                _cspParams.CryptoKeySecurity.SetAccessRule(rule);

                // Create a new RSA key and save it in the container.  This key will encrypt
                // a symmetric key, which will then be encryped in the XML document.
                _rsaKey = new RSACryptoServiceProvider(_cspParams);

                // Encrypt the "configuration" element.
                DecryptXMLElement(xmlDoc, _rsaKey, "rsaKey");

                // Save the XML document.
                //xmlDoc.Save("C:\\Dev\\Src\\dotNet\\System\\AOSv2.2\\AOSv2\\AOS.WebHost\\Plugins\\bin\\OS.Framework.Plugins.Test.Package.config.dec");
            }
            catch (Exception e)
            {
                _log.Error(string.Format("Exception decrypting plugin config. message={0}", e.Message));
                throw;
            }
            finally
            {
                // Clear the RSA key.
                if (_rsaKey != null)
                    _rsaKey.Clear();
            }

            return xmlDoc;
        }


        /// <summary>
        /// Decrypts the XML element.
        /// </summary>
        /// <param name="Doc">The doc.</param>
        /// <param name="Alg">The alg.</param>
        /// <param name="KeyName">Name of the key.</param>
        public void DecryptXMLElement(XmlDocument Doc, RSA Alg, string KeyName)
        {
            // Check the arguments.  
            if (Doc == null)
                throw new ArgumentNullException("Doc");
            if (Alg == null)
                throw new ArgumentNullException("Alg");
            if (KeyName == null)
                throw new ArgumentNullException("KeyName");

            // Create a new EncryptedXml object.
            EncryptedXml exml = new EncryptedXml(Doc);

            // Add a key-name mapping.
            // This method can only decrypt documents
            // that present the specified key name.
            exml.AddKeyNameMapping(KeyName, Alg);

            // Decrypt the element.
            exml.DecryptDocument();

        }

        public void EncryptStream2File(Stream streamIn, string fileOut, string password, string salt)
        {
            if (fileOut == null || string.IsNullOrEmpty(fileOut))
                throw new ArgumentNullException("fileOut");
            MemoryStream msOut = EncryptStream(streamIn, password, salt);
            byte[] bytes = new byte[msOut.Length];
            msOut.Seek(0, SeekOrigin.Begin);
            msOut.Read(bytes, 0, bytes.Length);

            using (FileStream fs = new FileStream(fileOut, FileMode.Create))
            {
                BinaryWriter bw = new BinaryWriter(fs);
                bw.Write(bytes);
                bw.Close();
                fs.Close();
            }
        }

        public MemoryStream EncryptStream(Stream streamIn, string password, string salt)
        {
            if (streamIn == null || streamIn.Length == 0)
                throw new ArgumentNullException("streamIn");
            streamIn.Seek(0, SeekOrigin.Begin);
            byte[] inputByte = new byte[streamIn.Length];
            streamIn.Read(inputByte, 0, (int)streamIn.Length);

            byte[] encryptedByte = EncryptByte(inputByte, password, salt);
            return new MemoryStream(encryptedByte);
        }
        public byte[] EncryptByte(byte[] byteIn, string password, string salt)
        {
            // Check the arguments.
            if (byteIn == null || byteIn.Length == 0)
                throw new ArgumentNullException("byteIn");
            if (password == null || string.IsNullOrEmpty(password))
                throw new ArgumentNullException("password");
            if (salt == null || string.IsNullOrEmpty(salt))
                throw new ArgumentNullException("salt");

            RijndaelManaged sessionKey = null;

            try
            {
                using (MemoryStream msOut = new MemoryStream())
                {
                    Rfc2898DeriveBytes rdb = new Rfc2898DeriveBytes(password, HexToByteArray(salt));

                    //////////////////////////////////////////////////
                    // Create a new instance of the EncryptedXml class
                    // and use it to encrypt the XmlElement with the
                    // a new random symmetric key.
                    //////////////////////////////////////////////////

                    // Create a 256 bit Rijndael key.
                    sessionKey = new RijndaelManaged();
                    sessionKey.KeySize = 256;
                    sessionKey.IV = rdb.GetBytes(16);
                    sessionKey.Key = rdb.GetBytes(32);
                    sessionKey.Padding = PaddingMode.ISO10126;
                    sessionKey.Mode = CipherMode.CBC;

                    using (CryptoStream cs = new CryptoStream(msOut, sessionKey.CreateEncryptor(sessionKey.Key, sessionKey.IV), CryptoStreamMode.Write))
                    {
                        cs.Write(byteIn, 0, byteIn.Length);
                        cs.FlushFinalBlock();
                        // The GC will collect the old objects faster
                        rdb = null;
                        return msOut.ToArray();
                    }
                }
            }
            catch (Exception e)
            {
                // re-throw the exception.
                throw;
            }
            finally
            {

                if (sessionKey != null)
                {
                    sessionKey.Clear();
                }
            }
        }
        /// <summary>
        /// Encrypt file
        /// </summary>
        /// <param name="fileIn">filename of file to encrypt</param>
        /// <param name="fileOut">filename of destination</param>
        public void EncryptFile(string fileIn, string fileOut, string password, string salt)
        {
            // Check the arguments.
            if (fileIn == null || string.IsNullOrEmpty(fileIn))
                throw new ArgumentNullException("fileIn");
            if (fileOut == null || string.IsNullOrEmpty(fileOut))
                throw new ArgumentNullException("fileOut");
            if (password == null || string.IsNullOrEmpty(password))
                throw new ArgumentNullException("password");
            if (salt == null || string.IsNullOrEmpty(salt))
                throw new ArgumentNullException("salt");

            FileStream fsIn = new FileStream(fileIn, FileMode.Open);
            EncryptStream2File(fsIn, fileOut, password, salt);

            fsIn.Close();
            fsIn = null;
        }

        public void DecryptFile(string fileIn, string fileOut, string password, string salt)
        {
            // Check the arguments.
            if (fileIn == null || string.IsNullOrEmpty(fileIn))
                throw new ArgumentNullException("fileIn");
            if (fileOut == null || string.IsNullOrEmpty(fileOut))
                throw new ArgumentNullException("fileOut");
            if (password == null || string.IsNullOrEmpty(password))
                throw new ArgumentNullException("password");
            if (salt == null || string.IsNullOrEmpty(salt))
                throw new ArgumentNullException("salt");

            FileStream fsOut = new FileStream(fileOut, FileMode.OpenOrCreate);
            MemoryStream msIn = DecryptFile2Stream(fileIn, password, salt);

            msIn.Position = 0;
            msIn.Seek(0, SeekOrigin.Begin);

            int data;
            while ((data = msIn.ReadByte()) != -1)
                fsOut.WriteByte((byte)data);

            fsOut.Flush();
            msIn.Close();
            fsOut.Close();
            msIn = null;
            fsOut = null;
        }
        /// <summary>
        /// Decrypt a fiel into MemoryStream
        /// </summary>
        /// <param name="fileIn">filename of file to decrypt</param>
        /// <returns>a MemoryStream containing </returns>
        public MemoryStream DecryptFile2Stream(string fileIn, string password, string salt)
        {
            if (fileIn == null || string.IsNullOrEmpty(fileIn))
                throw new ArgumentNullException("fileIn");
            using (FileStream fsIn = new FileStream(fileIn, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                return DecryptStream(fsIn, password, salt);
            }
        }

        public MemoryStream DecryptStream(Stream streamIn, string password, string salt)
        {
            if (streamIn == null || streamIn.Length == 0)
                throw new ArgumentNullException("streamIn");
            streamIn.Seek(0, SeekOrigin.Begin);
            byte[] inputByte = new byte[streamIn.Length];
            streamIn.Read(inputByte, 0, (int)streamIn.Length);

            byte[] encryptedByte = DecryptByte(inputByte, password, salt);
            return new MemoryStream(encryptedByte);
        }

        public byte[] DecryptByte(byte[] byteIn, string password, string salt)
        {
            // Check the arguments.
            if (byteIn == null || byteIn.Length == 0)
                throw new ArgumentNullException("byteIn");
            if (password == null || string.IsNullOrEmpty(password))
                throw new ArgumentNullException("password");
            if (salt == null || string.IsNullOrEmpty(salt))
                throw new ArgumentNullException("salt");

            RijndaelManaged sessionKey = null;

            try
            {
                Rfc2898DeriveBytes rdb = new Rfc2898DeriveBytes(password, HexToByteArray(salt));
                //////////////////////////////////////////////////
                // Create a new instance of the EncryptedXml class
                // and use it to encrypt the XmlElement with the
                // a new random symmetric key.
                //////////////////////////////////////////////////

                // Create a 256 bit Rijndael key.
                sessionKey = new RijndaelManaged();
                sessionKey.KeySize = 256;
                sessionKey.IV = rdb.GetBytes(16);
                sessionKey.Key = rdb.GetBytes(32);
                sessionKey.Padding = PaddingMode.ISO10126;
                sessionKey.Mode = CipherMode.CBC;
                using (MemoryStream msIn = new MemoryStream(byteIn))
                {
                    using (CryptoStream cs = new CryptoStream(msIn, sessionKey.CreateDecryptor(sessionKey.Key, sessionKey.IV), CryptoStreamMode.Read))
                    {
                        byte[] result = new byte[byteIn.Length];
                        cs.Read(result, 0, result.Length);
                        return result;
                    }
                }
            }
            catch (Exception e)
            {
                // re-throw the exception.
                throw;
            }
            finally
            {
                if (sessionKey != null)
                {
                    sessionKey.Clear();
                }
            }
        }

        /// <summary>
        /// Creates a hex string from byte array.
        /// </summary>
        /// <param name="data">The byte data.</param>
        /// <returns>A hex string (base16 encoded)
        /// </returns>
        public static string HexFromByteArray(byte[] data)
        {
            return BitConverter.ToString(data).Replace("-", "");
        }

        /// <summary>
        /// Creates a byte array from a hex (base16) 
        /// encoded string
        /// </summary>
        /// <param name="data">A hex string (base16 
        /// encoded).</param>
        /// <returns>A byte array</returns>
        public static byte[] HexToByteArray(string data)
        {
            byte[] result = new byte[data.Length / 2];

            for (int i = 0; i < result.Length; i++)
            {
                result[i] = byte.Parse(data.Substring(i * 2, 2), NumberStyles.HexNumber);
            }

            return result;
        }
    }
}
