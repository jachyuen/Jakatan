﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security
{
    public interface IExecuteHelper
    {
        T RunAs<T>(Type ty, Func<T> action);
        void RunAs(Type ty, ActionVoid action);
        T RunAs<T>(Type ty, UserImpersonation user, Func<T> action);
        void RunAs(Type ty, UserImpersonation user, ActionVoid action);
    }
}
