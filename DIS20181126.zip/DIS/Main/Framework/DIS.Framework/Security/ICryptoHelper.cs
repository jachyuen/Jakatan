﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DIS.Framework.Security
{
    public interface ICryptoHelper
    {
        //RSA XML and PluginsConfig encryption/Decryption
        XmlDocument EncryptXML(string input);
        void EncryptXMLFile(string input, string output);
        void EncryptPluginsConfig(string Doc);
        void EncryptXMLElement(XmlDocument Doc, string ElementToEncrypt, string EncryptionElementID, RSA Alg, string KeyName);
        XmlDocument DecryptPluginsConfig(string Doc);
        void DecryptXMLElement(XmlDocument Doc, RSA Alg, string KeyName);

        //AES File Encryption/Decryption
        void EncryptFile(string fileIn, string fileOut, string password, string salt);
        void EncryptStream2File(Stream streamIn, string fileOut, string password, string salt);
        byte[] EncryptByte(byte[] byteIn, string password, string salt);
        MemoryStream EncryptStream(Stream streamIn, string password, string salt);

        void DecryptFile(string fileIn, string fileOut, string password, string salt);
        MemoryStream DecryptFile2Stream(string fileIn, string password, string salt);
        byte[] DecryptByte(byte[] byteIn, string password, string salt);
        MemoryStream DecryptStream(Stream streamIn, string password, string salt);
    }
}
