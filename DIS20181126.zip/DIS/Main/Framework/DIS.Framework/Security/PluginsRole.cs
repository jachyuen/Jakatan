﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security
{
    public class PluginsRole
    {
        public string AD { get; set; }
        public string Plugins { get; set; }

        public PluginsRole(string ad, string plugins)
        {
            AD = ad;
            Plugins = plugins;
        }
    }
}
