﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security
{
    public delegate void ActionVoid();

    public class ExecuteHelper : IExecuteHelper
    {
        private WindowsImpersonationContext _impersonationContext;
        private IImpersonationProvider _impersonation;
        public ILog _log { get; set; }

        public ExecuteHelper(IImpersonationProvider impersonation)
        { _impersonation = impersonation; }

        /// <summary>
        /// Executes an action inside a try catch and does not do anything when
        /// an exception occurrs.
        /// </summary>
        /// <param name="action"></param>
        public T RunAs<T>(Type t, UserImpersonation user, Func<T> action)
        {
            _log.Info(String.Format("Trying to impersonate User: {0}", user.UserName));
            T result = default(T);

            try
            {
                if (!_impersonation.ImpersonateValidUser(user.UserName, user.Domain, user.UserPassword, out _impersonationContext))
                {
                    throw new AuthenticationException("Impersonation failed");
                }
                result = action();
                _impersonationContext.Undo();

                _log.Info("Impersonation successfully reverted");

                return result;
            }
            catch (AuthenticationException ae)
            {
                _log.Error(String.Format("Authentication Error while impersonating User: {0}", user.UserName));
                throw ae;
            }
            catch (Exception e)
            {
                _log.Error(String.Format("Error while running action with impersonated User: {0}", user.UserName));
                throw e;
            }
        }

        /// <summary>
        /// Executes an action inside a try catch and does not do anything when
        /// an exception occurrs.
        /// </summary>
        /// <param name="action"></param>
        public void RunAs(Type t, UserImpersonation user, ActionVoid action)
        {
            _log.Info(String.Format("Trying to impersonate User: {0}", user.UserName));

            try
            {
                if (!_impersonation.ImpersonateValidUser(user.UserName, user.Domain, user.UserPassword, out _impersonationContext))
                {
                    throw new AuthenticationException("Impersonation failed");
                }
                action();

                _impersonationContext.Undo();
                _log.Info("Impersonation successfully reverted");
            }
            catch (AuthenticationException ae)
            {
                _log.Error(string.Format("Authentication Error while impersonating User: {0}", user.UserName));
                throw ae;
            }
            catch (Exception e)
            {
                _log.Error(string.Format("Error while running action with impersonated User: {0}", user.UserName));
                throw e;
            }
        }

        #region IExecuteHelper Members

        public T RunAs<T>(Type ty, Func<T> action)
        {
            throw new NotImplementedException();
        }

        public void RunAs(Type ty, ActionVoid action)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
