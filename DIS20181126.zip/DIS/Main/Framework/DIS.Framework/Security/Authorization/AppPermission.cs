﻿using FluentValidation;
using FluentValidation.Attributes;
using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    [Validator(typeof(AppPermissionValidator))]
    public class AppPermission : Entity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ApplicationCode { get; set; }
        public Boolean IsDeleted { get; set; }

        public virtual ICollection<RolePermission> RolePermissions { get; set; }
    }

    public class AppPermissionValidator : AbstractValidator<AppPermission>
    {
        public AppPermissionValidator()
        {
            RuleFor(x => x.Name).NotNull().NotEmpty().WithMessage("Name value cannot be null");
            RuleFor(x => x.Description).NotNull().NotEmpty().WithMessage("Description value cannot be null");
            RuleFor(x => x.ApplicationCode).NotNull().NotEmpty().WithMessage("Application Code value cannot be null");
        }
    }
}
