﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public interface IRoleService
    {
        //interaction permission/user

        #region role
        void AddRole(AppRole appRole);
        void UpdateRole(AppRole appRole);
        void DeleteRole(AppRole appRole);
        IEnumerable<AppRole> GetAllAppRoles();
        AppRole GetAppRole(int appRoleId);
        AppRole GetAppRole(String name, String applicationCode);
        #endregion

        #region Role / User
        IEnumerable<AppRole> GetAppRolesForUser(string username);
        IEnumerable<ADUser> GetUsersInAppRole(AppRole appRole);

        void AddRoleToUser(string username, AppRole appRole);
        void DeleteRoleFromUser(string username, AppRole appRole);
        #endregion

        #region  role / permission
        IEnumerable<AppPermission> GetAppPermissionsInAppRole(AppRole appRole);
        IEnumerable<AppRole> GetAppRolesWithAppPermission(AppPermission appPermission);

        void DeleteAppPermissionFromAppRole(AppPermission p, AppRole r);
        void AddAppPermissionToRole(AppPermission p, AppRole r);

        #endregion

        #region user
        bool IsUserAuthorized(AppPermission permission);
        bool IsUserAuthorized(IEnumerable<AppPermission> permission);

        bool IsUserMember(string applicationCode);
        /// <summary>
        /// get all users giving a ldpath
        /// </summary>
        /// <param name="ldPath">for instance :OU=User_Accounts,OU=Users,OU=_Hongkong,OU=_AP,DC=cib,DC=net</param>
        /// <returns></returns>
        IEnumerable<ADUser> GetADUsers();
        IEnumerable<ADUser> GetADUsers(string ldPath);
        IEnumerable<string> GetAllExistingUsers();
        IEnumerable<string> GetAllUserForAppCodePermissionName(string applicationCode, string permissionName);
        #endregion

        #region permission
        void AddPermission(AppPermission permission);
        void DeletePermission(AppPermission permission);
        void UpdatePermission(AppPermission permission);
        IEnumerable<AppPermission> GetAllAppPermissionsForAppCode(string applicationCode);
        IEnumerable<AppPermission> GetAllUserAppPermissionsForAppCode(string applicationCode, string userName);
        IEnumerable<AppPermission> GetAllPermissions();
        AppPermission GetAppPermission(String name, String applicationCode);
        #endregion

        #region ApplicationToExclude
        IEnumerable<string> GetApplicationToExclude();
        void AddApplicationToExclude(string applicationCode);
        void DeleteApplicationToExclude(string applicationCode);
        #endregion

        IEnumerable<string> GetApplicationMembershipToUser();

        IPagedList<AuditRecord> GetAuditRecords(string dtFilter, String sortBy, String sortDir, ref int iTotalFilteredRecords, ref int iTotalRecords, int pageIndex = 0, int pageSize = int.MaxValue);
        void MarkAppRoleDeleted(string appRoleApplicationCode);
    }
}
