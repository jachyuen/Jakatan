﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace DIS.Framework.Security.Authorization
{
    public class WebUserService : IUserService
    {
        #region IUserService Members

        public string GetUsername()
        {
            //if (HttpContext.Current != null && HttpContext.Current.User != null)
            //{
            //    return HttpContext.Current.User.Identity.Name;
            //}
            string userName = String.IsNullOrEmpty(Thread.CurrentPrincipal.Identity.Name) ? "System" : Thread.CurrentPrincipal.Identity.Name;
            return userName;
        }

        #endregion
    }
}
