﻿using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public class RolePermission : Entity
    {
        public int AppRole_Id { get; set; }
        public int AppPermission_Id { get; set; }
        public Boolean IsDeleted { get; set; }
        public virtual AppRole appRole { get; set; }
        public virtual AppPermission appPermission { get; set; }
    }
}
