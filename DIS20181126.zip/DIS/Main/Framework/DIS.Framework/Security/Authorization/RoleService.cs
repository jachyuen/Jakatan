﻿using DIS.Framework.Caching;
using DIS.Framework.DataAccess.EntityFrameworkRepository.Repository;
using DIS.Framework.DataAccess.EntityFrameworkRepository;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public class RoleService : IRoleService
    {
        protected IEFRepository<AppRole, int> _appRoleRepository;
        protected IEFRepository<AppPermission, int> _appPermissionRepository;
        protected IEFRepository<AppToExclude, int> _appToExcludeRepository;
        protected IEFRepository<AuditRecord, int> _auditRecordRepository;
        protected IEFRepository<RolePermission, int> _rolePermissionRepository;
        protected IEFRepository<UserRole, int> _userRoleRepository;

        private IUserService _userservice;
        private ICacheManager _cacheManager;

        /// <summary>
        /// Init service
        /// </summary>
        public RoleService(IEFRepository<AppRole, int> appRoleRepository,
            IEFRepository<AppPermission, int> appPermissionRepository,
            IEFRepository<AppToExclude, int> appToExcludeRepository,
            IEFRepository<AuditRecord, int> auditRecordRepository,
            IEFRepository<RolePermission, int> rolePermissionRepository,
            IEFRepository<UserRole, int> userRoleRepository,
            IUserService userservice,
            ICacheManager cacheManager)
        {
            _appRoleRepository = appRoleRepository;
            _appPermissionRepository = appPermissionRepository;
            _appToExcludeRepository = appToExcludeRepository;
            _auditRecordRepository = auditRecordRepository;
            _rolePermissionRepository = rolePermissionRepository;
            _userRoleRepository = userRoleRepository;
            _userservice = userservice;
            _cacheManager = cacheManager;
        }

        public void AddApplicationToExclude(string applicationCode)
        {
            if (String.IsNullOrEmpty(applicationCode))
                throw new ArgumentNullException("AddApplicationToExclude");

            var query = from ate in _appToExcludeRepository.Table
                        where ate.ApplicationCode.ToLower().Equals(applicationCode.ToLower())
                        select ate;

            var applicationToExclude = query.ToList();

            if (applicationToExclude.Count <= 0)
            {
                _appToExcludeRepository.Insert(new AppToExclude() { ApplicationCode = applicationCode });
            }
        }

        public void AddAppPermissionToRole(AppPermission p, AppRole r)
        {
            if (p == null || r == null)
                throw new ArgumentNullException("AddAppPermissionToRole");

            var existingCount = (from rp in _rolePermissionRepository.Table
                                 where rp.AppRole_Id.Equals(r.Id) && rp.AppPermission_Id.Equals(p.Id)
                                 select rp).Count();
            if (existingCount <= 0)
            {
                RolePermission rp = new RolePermission { appRole = r, appPermission = p };
                _rolePermissionRepository.Insert(rp);
            }
            //_ r.RolePermissions.Add(rp);
            //_appRoleRepository.Update(r);
        }

        public void AddPermission(AppPermission permission)
        {
            if (permission == null)
                throw new ArgumentNullException("AddPermission");
            var existingCount = (from ap in _appPermissionRepository.Table
                                 where ap.ApplicationCode.Equals(permission.ApplicationCode) &&
                                      ap.Name.Equals(permission.Name)
                                 select ap).Count();

            if (existingCount <= 0)
                _appPermissionRepository.Insert(permission);
        }

        public void AddRole(AppRole appRole)
        {
            if (appRole == null)
                throw new ArgumentNullException("AddRole");

            var existingCount = (from ar in _appRoleRepository.Table
                                 where ar.ApplicationCode.Equals(appRole.ApplicationCode) &&
                                      ar.Name.Equals(appRole.Name)
                                 select ar).Count();

            if (existingCount <= 0)
                _appRoleRepository.Insert(appRole);
        }

        public void AddRoleToUser(string username, AppRole appRole)
        {
            if (appRole == null || string.IsNullOrEmpty(username))
                throw new ArgumentNullException("AddRoleToUser");

            var userRole = new UserRole() { Username = username, AppRole_Id = appRole.Id };
            var existingCount = (from ur in _userRoleRepository.Table
                                 where ur.Username.Equals(username) &&
                                      ur.AppRole_Id.Equals(appRole.Id)
                                 select ur).Count();

            if (existingCount <= 0)
                _userRoleRepository.Insert(userRole);

            _cacheManager.RemoveByPrefix(username);

            //add audit 
            AuditRecord auditRecord = new AuditRecord { Action = "AddRoleToUser", RunStatus = "OK", Parameters = String.Format("username={0};AppCode={1};Role={2}", username, appRole.ApplicationCode, appRole.Name) };
            _auditRecordRepository.Insert(auditRecord);
        }

        public void DeleteApplicationToExclude(string applicationCode)
        {
            if (String.IsNullOrEmpty(applicationCode))
                throw new ArgumentNullException("DeleteApplicationToExclude");

            var ateToDeleted = (from ate in _appToExcludeRepository.Table
                                where ate.ApplicationCode.ToLower().Equals(applicationCode.ToLower())
                                select ate).FirstOrDefault();

            _appToExcludeRepository.Delete(ateToDeleted);

        }

        public void DeleteAppPermissionFromAppRole(AppPermission p, AppRole r)
        {
            if (p == null || r == null)
                throw new ArgumentNullException("DeleteAppPermissionFromAppRole");

            var tempRp = r.RolePermissions
                .Select(rp => rp)
                .Where(rp => rp.appPermission.Id.Equals(p.Id)).FirstOrDefault();
            r.RolePermissions.Remove(tempRp);
            _appRoleRepository.Update(r);
        }

        public void DeletePermission(AppPermission permission)
        {
            if (permission == null)
                throw new ArgumentNullException("DeletePermission");

            _appPermissionRepository.Delete(permission);
        }

        public void DeleteRole(AppRole appRole)
        {
            if (appRole == null)
                throw new ArgumentNullException("DeleteRole");

            _appRoleRepository.Delete(appRole);
        }

        public void DeleteRoleFromUser(string username, AppRole appRole)
        {
            if (appRole == null || String.IsNullOrEmpty(username))
                throw new ArgumentNullException("DeleteRoleFromUser");

            var urToDelete = (from ur in _userRoleRepository.Table
                              where (ur.Username.Equals(username) && ur.appRole.Id == appRole.Id)
                              select ur).FirstOrDefault();

            if (urToDelete != null)
                _userRoleRepository.Delete(urToDelete);
            _cacheManager.RemoveByPrefix(username);

            //add audit 
            AuditRecord auditRecord = new AuditRecord { Action = "DeleteRoleFromUser", RunStatus = "OK", Parameters = String.Format("username={0};AppCode={1};Role={2}", username, appRole.ApplicationCode, appRole.Name) };
            _auditRecordRepository.Insert(auditRecord);
        }

        public IEnumerable<AppPermission> GetAllAppPermissionsForAppCode(string applicationCode)
        {
            var appPermissions = (from ap in _appPermissionRepository.Table
                                 where ap.ApplicationCode.Equals(applicationCode)
                                 select ap).ToList();

            return appPermissions;
        }

        public IEnumerable<AppRole> GetAllAppRoles()
        {
            var toBeReturned = _appRoleRepository.Table.ToList();
            return toBeReturned;
        }

        public IEnumerable<string> GetAllExistingUsers()
        {
            var toBeReturn = (from ur in _userRoleRepository.Table
                             select ur.Username).ToList();

            return toBeReturn;
        }

        public IEnumerable<AppPermission> GetAllPermissions()
        {
            var toBeReturned = _appPermissionRepository.Table.ToList();
            return toBeReturned;
        }

        public IEnumerable<AppPermission> GetAllUserAppPermissionsForAppCode(string applicationCode, string userName)
        {
            var ar = (from ur in _userRoleRepository.Table
                      where (ur.Username.Equals(userName)
                        && ur.appRole.ApplicationCode.Equals(applicationCode))
                      select ur.appRole.Id).ToList();

            //var toBeReturned = ar.SelectMany(x => x.AppPermissions);

            var rp = (from tempRp in _rolePermissionRepository.Table
                     where ar.Contains(tempRp.AppRole_Id)
                     select tempRp.appPermission).ToList();

            return rp;
        }

        public IEnumerable<string> GetAllUserForAppCodePermissionName(string applicationCode, string permissionName)
        {
            var userNames = (from ur in _userRoleRepository.Table
                             join rp in _rolePermissionRepository.Table on ur.AppRole_Id equals rp.AppRole_Id
                             join ap in _appPermissionRepository.Table on rp.AppPermission_Id equals ap.Id
                             where (ur.appRole.ApplicationCode.Equals(applicationCode)
                                && ap.Name.Equals(permissionName))
                             select ur.Username).ToList();

            return userNames;
        }

        public IEnumerable<string> GetApplicationToExclude()
        {
            var toBeReturned = (from ate in _appToExcludeRepository.Table
                               select ate.ApplicationCode).ToList();
            return toBeReturned;
        }

        public IEnumerable<AppPermission> GetAppPermissionsInAppRole(AppRole appRole)
        {
            var appPermissions = (from ar in _appRoleRepository.Table
                                  join rp in _rolePermissionRepository.Table on ar.Id equals rp.AppRole_Id
                                  join ap in _appPermissionRepository.Table on rp.AppPermission_Id equals ap.Id
                                  where (ar.Id.Equals(appRole.Id))
                                  select ap).ToList();

            return appPermissions;
        }

        public AppPermission GetAppPermission(String name, String applicationCode)
        {
            var appPermission = (from ap in _appPermissionRepository.Table
                                 where ap.Name.Equals(name) && ap.ApplicationCode.Equals(applicationCode)
                                 select ap).FirstOrDefault();
            return appPermission;
        }

        public AppRole GetAppRole(int appRoleId)
        {
            var toBeReturned = (from ar in _appRoleRepository.Table
                                where ar.Id.Equals(appRoleId)
                                select ar).FirstOrDefault();

            return toBeReturned;
        }

        public AppRole GetAppRole(String name, String applicationCode)
        {
            var toBeReturned = (from ar in _appRoleRepository.Table
                                where ar.Name.Equals(name) && ar.ApplicationCode.Equals(applicationCode)
                                select ar).FirstOrDefault();

            return toBeReturned;
        }

        public IEnumerable<AppRole> GetAppRolesForUser(string username)
        {
            var toBeReturned = (from ur in _userRoleRepository.Table
                               join ar in _appRoleRepository.Table on ur.AppRole_Id equals ar.Id
                               where ur.Username.Equals(username)
                               select ar).ToList();

            return toBeReturned;
        }

        public IEnumerable<AppRole> GetAppRolesWithAppPermission(AppPermission appPermission)
        {
            var toBeReturned = (from ar in _appRoleRepository.Table
                               join rp in _rolePermissionRepository.Table on ar.Id equals rp.AppRole_Id
                               join ap in _appPermissionRepository.Table on rp.AppPermission_Id equals ap.Id
                               where ap.Id.Equals(appPermission.Id)
                               select ar).ToList();
            return toBeReturned;
        }

        public IEnumerable<ADUser> GetADUsers()
        {
            return GetADUsers("");
        }

        public IEnumerable<ADUser> GetADUsers(string ldPath)
        {
            List<ADUser> lu = new List<ADUser>();

            try
            {
                //lu.AddRange(GetActiveDirectoryDUsers(ldPath, "OU=User_Accounts,OU=Users"));
                //lu.AddRange(GetActiveDirectoryDUsers(ldPath, "OU=Admin_Accounts"));
                string adUsersCacheKey = "DISADUsers";
                IEnumerable<ADUser> adUsers = _cacheManager.Get(adUsersCacheKey, 60*24, () => GetActiveDirectoryDUsers(ldPath, "")); // cache AD entries for one day
                lu.AddRange(adUsers);

                return lu.OrderBy(x => x.DisplayName);
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Error getting user for AD path:{0}", ldPath), ex);
            }
        }

        private IEnumerable<ADUser> GetActiveDirectoryDUsers(string ldPath, string additionalOU)
        {
            IList<ADUser> lu = new List<ADUser>();

            //DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://" + additionalOU + "," + ldPath);
            // look up this LDAP:// string with "Active Directory Explorer"
            DirectoryEntry directoryEntry = new DirectoryEntry("LDAP://OU=DaiwaCM,OU=11. Users,OU=DaiwaCM Hong Kong,DC=daiwaasia,DC=local"); 
            DirectorySearcher directorySearch = new DirectorySearcher(directoryEntry);
            directorySearch.Asynchronous = true;
            directorySearch.PageSize = 1000;
            directorySearch.CacheResults = true;
            directorySearch.Filter = "(&(objectCategory=person)(objectClass=user))";
            directorySearch.SearchScope = SearchScope.Subtree;
            SearchResultCollection userCollection = directorySearch.FindAll();

            foreach (SearchResult users in userCollection)
            {
                DirectoryEntry userEntry = new DirectoryEntry(users.Path);

                ADUser u = new ADUser();
                u.DisplayName = GetProperty(userEntry, "displayName").ToString();
                u.Email = GetProperty(userEntry, "mail").ToString();

                String principalName = GetProperty(userEntry, "userPrincipalName").ToString();
                string[] usplit = principalName.Split('@');
                u.PrincipalName = usplit[1].Split('.')[0].ToUpper() + @"\" + usplit[0];

                lu.Add(u);
            }

            return lu.OrderBy(x => x.DisplayName);
        }

        private Object GetProperty(DirectoryEntry userDetail, String propertyName)
        {
            if (userDetail.Properties.Contains(propertyName))
            {
                return userDetail.Properties[propertyName][0];
            }
            else
            {
                return string.Empty;
            }
        }

        public IEnumerable<ADUser> GetUsersInAppRole(AppRole appRole)
        {
            var toBeReturned = (from ur in _userRoleRepository.Table
                               where ur.AppRole_Id.Equals(appRole.Id)
                               select (new ADUser() { PrincipalName = ur.Username })).ToList();

            return toBeReturned;
        }

        public bool IsUserAuthorized(IEnumerable<AppPermission> permissions)
        {
            foreach (AppPermission ap in permissions)
                if (!IsUserAuthorized(ap))
                    return false;

            return true;
        }

        public bool IsUserAuthorized(AppPermission permission)
        {
            String username = _userservice.GetUsername();
            var user = from ur in _userRoleRepository.Table
                       join rp in _rolePermissionRepository.Table on ur.AppRole_Id equals rp.AppRole_Id
                       join ap in _appPermissionRepository.Table on rp.AppPermission_Id equals ap.Id
                       where (ap.Name.Equals(permission.Name) && ap.ApplicationCode.Equals(permission.ApplicationCode) && ur.Username.Equals(username))
                       select ur;

            return user.Count() >= 1;
        }

        public bool IsUserMember(string applicationCode)
        {
            var user = from ur in _userRoleRepository.Table
                       where ur.appRole.ApplicationCode.Equals(applicationCode) &&
                            ur.Username.Equals(_userservice.GetUsername())
                       select ur;

            return user.Count() >= 1;
        }

        public void UpdatePermission(AppPermission permission)
        {
            if (permission == null)
                throw new ArgumentNullException("UpdatePermission");

            _appPermissionRepository.Update(permission);
        }

        public void UpdateRole(AppRole appRole)
        {
            if (appRole == null)
                throw new ArgumentNullException("UpdateRole");
            _appRoleRepository.Update(appRole);
        }

        public IEnumerable<string> GetApplicationMembershipToUser()
        {
            var appCode = (from ur in _userRoleRepository.Table
                           where ur.Username.Equals(_userservice.GetUsername())
                           select ur.appRole.ApplicationCode).Distinct();

            return appCode;

        }

        public IPagedList<AuditRecord> GetAuditRecords(string dtFilter, String sortBy, String sortDir, ref int iTotalFilteredRecords, ref int iTotalRecords, int pageIndex = 0, int pageSize = int.MaxValue)
        {
            var query = from ar in _auditRecordRepository.Table
                            //orderby ar.CreateDate descending
                        select ar;

            iTotalRecords = query.Count();

            query = from ar in query
                    where ar.Action.Contains(dtFilter) || ar.Parameters.Contains(dtFilter)
                    select ar;

            iTotalFilteredRecords = query.Count();

            bool desc = sortDir.Equals("desc");
            var orderedQuery = query.OrderBy(sortBy, desc);

            var toBeReturned = new PagedList<AuditRecord>(orderedQuery, pageIndex, pageSize);
            return toBeReturned;
        }

        public void MarkAppRoleDeleted(string appRoleApplicationCode)
        {
            if (String.IsNullOrEmpty(appRoleApplicationCode))
                throw new ArgumentNullException("MarkAppRoleDeleted");

            var appRole = (from ar in _appRoleRepository.Table
                                where ar.ApplicationCode.ToLower().Equals(appRoleApplicationCode.ToLower())
                                select ar).ToList();

            foreach (var ar in appRole)
            {
                ar.IsDeleted = true;
                _appRoleRepository.Update(ar);
            }
        }

    }
}
