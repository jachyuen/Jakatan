﻿using FluentValidation;
using FluentValidation.Attributes;
using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    [Validator(typeof(AppToExcludeValidator))]
    public class AppToExclude : Entity
    {
        public string ApplicationCode { get; set; }
        public Boolean IsDeleted { get; set; }
    }

    public class AppToExcludeValidator : AbstractValidator<AppToExclude>
    {
        public AppToExcludeValidator()
        {
            RuleFor(x => x.ApplicationCode).NotNull().NotEmpty().WithMessage("Application Code cannot be null");
        }
    }
}
