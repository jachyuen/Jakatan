﻿using FluentValidation;
using FluentValidation.Attributes;
using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    [Validator(typeof(AuditRecordValidator))]
    public class AuditRecord : Entity
    {
        public string Action { get; set; }
        public string Parameters { get; set; }
        public string RunStatus { get; set; }
        public string RunDetails { get; set; }
    }

    public class AuditRecordValidator : AbstractValidator<AuditRecord>
    {
        public AuditRecordValidator()
        {
            RuleFor(x => x.Action).NotNull().NotEmpty().WithMessage("Action cannot be null");
        }
    }

}
