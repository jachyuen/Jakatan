﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public class ADUser
    {
        /// <summary>
        /// Principal name formed by:   domain\name
        /// </summary>
        public string PrincipalName { get; set; }
        /// <summary>
        /// display name from AD
        /// </summary>
        public string DisplayName { get; set; }
        public string Email { get; set; }
    }
}
