﻿using DIS.Framework.Plugins.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public interface IAuthorizationService
    {
        //check authorization Part
        /// <summary>
        /// is user authorized for one permission
        /// </summary>
        /// <param name="permission"></param>
        /// <returns></returns>
        bool IsUserAuthorized(PluginPermission permission);
        bool IsUserAuthorized(AppPermission permission);
        void IsActionAuthorized(PluginPermission permission);

        /// <summary>
        /// is user assigned to one role
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        bool IsUserInRole(string userName, PluginRole role);

        /// <summary>
        /// Is User member of an application
        /// </summary>
        /// <param name="applicationCode"></param>
        /// <returns></returns>
        bool IsUserMember(string applicationCode);

        //data
        /// <summary>
        /// register permission
        /// </summary>
        /// <param name="permission"></param>
        void RegisterPermission(PluginPermission permission);
        void RegisterPermission(AppPermission permission);

        /// <summary>
        /// delete permission
        /// </summary>
        /// <param name="permission"></param>
        void DeletePermission(PluginPermission permission);
        void DeletePermission(AppPermission permission);

        /// <summary>
        /// create a Role
        /// </summary>
        /// <param name="r"></param>
        void AddRole(PluginRole r);

        /// <summary>
        /// Add a permission to a Role
        /// </summary>
        /// <param name="p"></param>
        /// <param name="r"></param>
        void AddPermissionToRole(PluginPermission p, PluginRole r);

        /// <summary>
        /// Delete permission from a Role
        /// </summary>
        /// <param name="p"></param>
        /// <param name="r"></param>
        void DeletePermissionFromRole(PluginPermission p, PluginRole r);

        /// <summary>
        /// Get all permissions for a given user and application
        /// </summary>
        /// <param name="applicationCode"></param>
        /// <returns></returns>
        IEnumerable<PluginPermission> GetAllUserPermissionsForAppCode(string appcode, string username);

        /// <summary>
        /// Get all permissions for a given user
        /// </summary>
        /// <param name="appcode"></param>
        /// <returns></returns>
        IEnumerable<PluginPermission> GetAllAppPermissionsForAppCode(string appcode);
        /// <summary>
        /// Update an existing role
        /// </summary>
        /// <param name="r"></param>
        /// <param name="newName"></param>
        /// <param name="newDescription"></param>
        void UpdateRoleDesc(PluginRole r, string newDescription);
        /// <summary>
        /// Update an existing role
        /// </summary>
        /// <param name="r"></param>
        /// <param name="newName"></param>
        /// <param name="newDescription"></param>
        void UpdateRoleNameAndDesc(PluginRole r, string newName, string newDescription);
        /// <summary>
        /// Update an existing permission
        /// </summary>
        /// <param name="r"></param>
        /// <param name="newName"></param>
        /// <param name="newDescription"></param>
        void UpdatePermissionDesc(PluginPermission p, string newDescription);
        /// <summary>
        /// Update an existing permission
        /// </summary>
        /// <param name="r"></param>
        /// <param name="newName"></param>
        /// <param name="newDescription"></param>
        void UpdatePermissionNameAndDesc(PluginPermission p, string newName, string newDescription);
        /// <summary>
        /// delete a existing role with name
        /// </summary>
        /// <param name="r"></param>
        void DeleteRole(PluginRole r);

        /// <summary>
        /// Get user name giving AppCode & Permission Name
        /// </summary>
        /// <param name="ldPath"></param>
        /// <returns></returns>
        IEnumerable<string> GetAllUserForAppCodePermissionName(string applicationCode, string permissionName);

        /// <summary>
        /// Get a list of application membership to user. It is a wrapper to IRoleService
        /// </summary>
        /// <returns>A list of App Codes</returns>
        IEnumerable<string> GetApplicationMembershipToUser();
    }
}
