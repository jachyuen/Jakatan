﻿using DIS.Framework.DataAccess.EntityFrameworkRepository.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization.Mapping
{
    public class AppRoleMap : DISEntityTypeConfiguration<AppRole>
    {
        public AppRoleMap()
        {
            this.ToTable("AUTH.AppRole");
            this.HasKey(ar => ar.Id);
        }
    }
}
