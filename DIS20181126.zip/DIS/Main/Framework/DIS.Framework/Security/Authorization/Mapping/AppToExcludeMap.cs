﻿using DIS.Framework.DataAccess.EntityFrameworkRepository.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization.Mapping
{
    public class AppToExcludeMap : DISEntityTypeConfiguration<AppToExclude>
    {
        public AppToExcludeMap()
        {
            this.ToTable("AUTH.AppToExclude");
            this.HasKey(ar => ar.Id);
        }
    }
}
