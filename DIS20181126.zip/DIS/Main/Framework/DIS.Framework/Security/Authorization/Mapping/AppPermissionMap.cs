﻿using DIS.Framework.DataAccess.EntityFrameworkRepository.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization.Mapping
{
    public class AppPermissionMap : DISEntityTypeConfiguration<AppPermission>
    {
        public AppPermissionMap()
        {
            this.ToTable("AUTH.AppPermission");
            this.HasKey(ap => ap.Id);
        }

    }
}
