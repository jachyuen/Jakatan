﻿using DIS.Framework.DataAccess.EntityFrameworkRepository.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization.Mapping
{
    public class UserRoleMap : DISEntityTypeConfiguration<UserRole>
    {
        public UserRoleMap()
        {
            this.ToTable("AUTH.UserRole");
            this.HasKey(ar => ar.Id);

            this.HasRequired(ur => ur.appRole)
                .WithMany(ap => ap.UserRoles)
                .HasForeignKey(ur => ur.AppRole_Id)
                .WillCascadeOnDelete(false);
        }
    }
}
