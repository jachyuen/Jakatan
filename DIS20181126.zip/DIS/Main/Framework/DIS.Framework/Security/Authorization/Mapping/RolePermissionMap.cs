﻿using DIS.Framework.DataAccess.EntityFrameworkRepository.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization.Mapping
{
    public class RolePermissionMap : DISEntityTypeConfiguration<RolePermission>
    {
        public RolePermissionMap()
        {
            this.ToTable("AUTH.RolePermission");
            this.HasKey(rp => rp.Id);
            //this.HasKey(rp => new { rp.AppRole_Id, rp.AppPermission_Id });

            this.HasRequired(rp => rp.appRole)
                .WithMany(ar => ar.RolePermissions)
                .HasForeignKey(rp => rp.AppRole_Id);

            this.HasRequired(rp => rp.appPermission)
                .WithMany(ap => ap.RolePermissions)
                .HasForeignKey(rp => rp.AppPermission_Id);
        }
    }
}
