﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public class WPFUserService : IUserService
    {
        #region IUserService Members

        public string GetUsername()
        {
            //if (HttpContext.Current != null && HttpContext.Current.User != null)
            //{
            //    return HttpContext.Current.User.Identity.Name;
            //}
            string userName = String.IsNullOrEmpty(System.Security.Principal.WindowsIdentity.GetCurrent().Name) ? "System" : System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            return userName;
        }

        #endregion
    }
}
