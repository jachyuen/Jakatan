﻿using DIS.Framework.Plugins.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public interface IPermissionProvider
    {
        IEnumerable<PluginPermission> GetPermissions();
        IEnumerable<PluginRole> GetRoles();
    }
}
