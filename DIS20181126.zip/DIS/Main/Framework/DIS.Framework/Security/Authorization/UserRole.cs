﻿using FluentValidation;
using FluentValidation.Attributes;
using DIS.Framework.DataAccess.PlainSQLRepository.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    [Validator(typeof(UserRoleValidator))]
    public class UserRole : Entity
    {
        public string Username { get; set; }
        public int AppRole_Id { get; set; }
        public Boolean IsDeleted { get; set; }
        public virtual AppRole appRole { get; set; }
    }

    public class UserRoleValidator : AbstractValidator<UserRole>
    {
        public UserRoleValidator()
        {
            RuleFor(x => x.Username).NotNull().NotEmpty().WithMessage("Username value cannot be null");
        }
    }
}
