﻿using DIS.Framework.Plugins.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security.Authorization
{
    public class AuthorizationService : IAuthorizationService
    {
        private IRoleService _roleService;

        public AuthorizationService(IRoleService roleService)
        {
            _roleService = roleService;
        }


        public void RegisterPermission(PluginPermission permission)
        {
            _roleService.AddPermission(PluginPermissionToPermission(permission));
        }
        public void RegisterPermission(AppPermission permission)
        {
            _roleService.AddPermission(permission);
        }


        public void DeletePermission(PluginPermission permission)
        {
            _roleService.DeletePermission(PluginPermissionToPermission(permission));
        }
        public void DeletePermission(AppPermission permission)
        {
            _roleService.DeletePermission(permission);
        }


        public bool IsUserAuthorized(PluginPermission permission)
        {
            return _roleService.IsUserAuthorized(PluginPermissionToPermission(permission));
        }
        public bool IsUserAuthorized(AppPermission permission)
        {
            return _roleService.IsUserAuthorized(permission);
        }
        public void IsActionAuthorized(PluginPermission permission)
        {
            if (_roleService.IsUserAuthorized(PluginPermissionToPermission(permission)))
                return;
            throw new SecurityException(String.Format("User is not authorized for action '{0}'", permission.Name));
        }

        public bool IsUserInRole(string userName, PluginRole role)
        {
            return _roleService.GetAppRolesForUser(userName).Where(x => x.Name == role.Name.ToLower()).Count() > 0;
        }


        public bool IsUserMember(string applicationCode)
        {
            return _roleService.IsUserMember(applicationCode);
        }

        public void AddRole(PluginRole r)
        {
            _roleService.AddRole(PluginRoleToRole(r));
        }

        public void AddPermissionToRole(PluginPermission p, PluginRole r)
        {
            _roleService.AddAppPermissionToRole(PluginPermissionToPermission(p), PluginRoleToRole(r));
        }

        public void DeletePermissionFromRole(PluginPermission p, PluginRole r)
        {
            _roleService.DeleteAppPermissionFromAppRole(PluginPermissionToPermission(p), PluginRoleToRole(r));
        }

        public IEnumerable<PluginPermission> GetAllUserPermissionsForAppCode(string appcode, string username)
        {
            return _roleService.GetAllUserAppPermissionsForAppCode(appcode, username)
                        .Select(
                            x => new PluginPermission()
                            {
                                Area = x.ApplicationCode,
                                Name = x.Name,
                                Description = x.Description,
                            }
                        );
        }

        public IEnumerable<PluginPermission> GetAllAppPermissionsForAppCode(string appcode)
        {
            return _roleService.GetAllAppPermissionsForAppCode(appcode)
                         .Select(
                             x => new PluginPermission()
                             {
                                 Area = x.ApplicationCode,
                                 Name = x.Name,
                                 Description = x.Description,
                             }
                         );
        }

        public void UpdateRoleDesc(PluginRole r, string newDescription)
        {
            var targetRole = _roleService.GetAllAppRoles()
                                    .Where(x => x.ApplicationCode.ToLower() == r.Area.ToLower() && x.Name.ToLower() == r.Name.ToLower());
            if (targetRole.Count() == 0)
                throw new IndexOutOfRangeException("PluginRole Not Found!");

            targetRole.First().Description = newDescription;
            _roleService.UpdateRole(targetRole.First());
        }

        public void UpdateRoleNameAndDesc(PluginRole r, string newName, string newDescription)
        {
            var targetRole = _roleService.GetAllAppRoles()
                                    .Where(x => x.ApplicationCode.ToLower() == r.Area.ToLower() && x.Name.ToLower() == r.Name.ToLower());
            if (targetRole.Count() == 0)
                throw new IndexOutOfRangeException("PluginRole Not Found!");

            var appRole = targetRole.First();
            appRole.Name = newName;
            appRole.Description = newDescription;
            _roleService.UpdateRole(appRole);
        }

        public void UpdatePermissionDesc(PluginPermission p, string newDescription)
        {
            var targetPermission = _roleService.GetAllPermissions()
                                    .Where(x => x.ApplicationCode.ToLower() == p.Area.ToLower() && x.Name.ToLower() == p.Name.ToLower());
            if (targetPermission.Count() == 0)
                throw new IndexOutOfRangeException("PluginPermission Not Found!");

            targetPermission.First().Description = newDescription;
            _roleService.UpdatePermission(targetPermission.First());
        }

        public void UpdatePermissionNameAndDesc(PluginPermission p, string newName, string newDescription)
        {
            var targetPermission = _roleService.GetAllPermissions()
                                    .Where(x => x.ApplicationCode.ToLower() == p.Area.ToLower() && x.Name.ToLower() == p.Name.ToLower());
            if (targetPermission.Count() == 0)
                throw new IndexOutOfRangeException("PluginPermission Not Found!");

            targetPermission.First().Name = newName;
            targetPermission.First().Description = newDescription;
            _roleService.UpdatePermission(targetPermission.First());
        }


        public void DeleteRole(PluginRole r)
        {
            var targetRole = _roleService.GetAllAppRoles()
                                    .Where(x => x.ApplicationCode.ToLower() == r.Area.ToLower() && x.Name.ToLower() == r.Name.ToLower());
            if (targetRole.Count() == 0)
                throw new IndexOutOfRangeException("PluginPermission Not Found!");
            _roleService.DeleteRole(targetRole.First());
        }
        /// <summary>
        /// transform PluginPermission to Plugin
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private AppPermission PluginPermissionToPermission(PluginPermission p)
        {
            return new AppPermission()
            {
                ApplicationCode = p.Area,
                Name = p.Name,
                Description = p.Description
            };
        }
        /// <summary>
        /// transform PluginRole to Role
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private AppRole PluginRoleToRole(PluginRole r)
        {
            AppRole role = new AppRole()
            {
                Name = r.Name,
                Description = r.Description,
                ApplicationCode = r.Area,
            };
            ICollection<RolePermission> rps = new List<RolePermission>();

            foreach (var permission in r.Permissions)
            {
                rps.Add(new RolePermission { appRole = role, appPermission = PluginPermissionToPermission(permission) });
            }

            role.RolePermissions = rps;

            return role;
        }

        public IEnumerable<string> GetAllUserForAppCodePermissionName(string applicationCode, string permissionName)
        {
            return _roleService.GetAllUserForAppCodePermissionName(applicationCode, permissionName);
        }

        /// <summary>
        /// Get a list of application membership to user. It is a wrapper to IRoleService
        /// </summary>
        /// <returns>A list of App Codes</returns>
        public IEnumerable<string> GetApplicationMembershipToUser()
        {
            return _roleService.GetApplicationMembershipToUser();
        }
    }
}
