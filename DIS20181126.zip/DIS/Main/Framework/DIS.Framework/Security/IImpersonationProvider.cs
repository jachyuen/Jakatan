﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security
{
    public interface IImpersonationProvider
    {
        bool ImpersonateValidUser(String userName, String domain, String password, out WindowsImpersonationContext impersonationContext);
        //void undoImpersonation();
    }
}
