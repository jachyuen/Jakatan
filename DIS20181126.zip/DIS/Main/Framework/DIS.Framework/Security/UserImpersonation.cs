﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Security
{
    public class UserImpersonation
    {
        /// <summary>
        /// Get/Set the impersonation user
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Get/Set the impersonation user domain
        /// </summary>
        public string Domain { get; set; }

        /// <summary>
        /// Get/Set the impersonation user password
        /// </summary>
        public string UserPassword { get; set; }

        /// <summary>
        /// Get/Set the impersonation ID
        /// </summary>
        private string _id;
        public string Id
        {
            get
            {
                if (string.IsNullOrEmpty(_id))
                    _id = "default";

                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public bool IsNull()
        {
            if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Domain) || string.IsNullOrEmpty(UserPassword))
                return true;

            return false;
        }
    }
}
