﻿using DIS.Framework.Caching;
using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using DIS.Framework.Security.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Navigation
{
    public class MenuService : IMenuService
    {
        private IDISHost _host;
        private IAuthorizationService _auth;
        private ICacheManager _cacheManager;
        private IUserService _userService;

        private const string MVC_MENU = "MVCMenu";

        public MenuService(IDISHost host,
            IAuthorizationService auth,
            ICacheManager cacheManager,
            IUserService userService)
        {
            _host = host;
            _auth = auth;
            _cacheManager = cacheManager;
            _userService = userService;
        }

        public IList<MenuHierarchicalEnumerable> GetAllPluginMenu()
        {
            var menuProviders = _host.ResolveAll<IPluginMenuProvider>();

            var toBeReturned = (from mp in menuProviders
                                select mp.GetPluginMenuData()).ToList();

            return toBeReturned;
        }

        public IList<MenuHierarchicalEnumerable> GetAllAuthorizedPluginMenu()
        {
            IList<MenuHierarchicalEnumerable> toBeReturned = new List<MenuHierarchicalEnumerable>();
            String cacheKey = _userService.GetUsername() + MVC_MENU;

            toBeReturned = _cacheManager.Get(cacheKey, () => priGetAllAuthorizedPluginMenu());

            return toBeReturned;
        }

        private IList<MenuHierarchicalEnumerable> priGetAllAuthorizedPluginMenu()
        {
            IList<MenuHierarchicalEnumerable> toBeReturned = new List<MenuHierarchicalEnumerable>();
            IList<MenuHierarchicalEnumerable> allPluginMenu = GetAllPluginMenu();

            MenuHierarchicalEnumerable tempTopMenu;
            foreach (var topMenu in allPluginMenu)
            {
                tempTopMenu = GetAuthorizedMenu(topMenu);

                if (tempTopMenu.Count > 0)
                    toBeReturned.Add(tempTopMenu);
            }

            return toBeReturned;
        }

        private MenuHierarchicalEnumerable GetAuthorizedMenu(MenuHierarchicalEnumerable menuData)
        {
            MenuHierarchicalEnumerable toBeReturned = new MenuHierarchicalEnumerable(menuData.Area);

            foreach (MenuHierarchyData menuItem in menuData)
            {
                MenuHierarchyData authMenuItem = new MenuHierarchyData(new MenuItemInfo(""));
                if (!menuItem.Permissions.Any() || menuItem.Permissions.Any(row => _auth.IsUserAuthorized(row)))
                {
                    authMenuItem = menuItem.CopyForAuthorizedMenu();
                    if (menuItem.Items != null && menuItem.Items.Any())
                        authMenuItem.Items.AddRange(GetAuthorizedMenu(menuItem.Items));

                    toBeReturned.Add(authMenuItem);
                }
            }

            return toBeReturned;
        }

    }
}
