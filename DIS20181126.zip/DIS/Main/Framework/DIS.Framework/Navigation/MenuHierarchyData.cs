﻿using DIS.Framework.Plugins.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.UI;
using System.Windows.Input;

namespace DIS.Framework.Navigation
{
    public class MenuHierarchyData : IHierarchyData, IComparable<MenuHierarchyData>
    {
        private MenuItemInfo itemInfoObject = null;
        private MenuConfig config = new MenuConfig();
        private IEnumerable<PluginPermission> menuPermissions = Enumerable.Empty<PluginPermission>();
        private MenuHierarchicalEnumerable subItems = null;

        public MenuHierarchyData(MenuItemInfo obj)
        {
            itemInfoObject = obj;
            subItems = new MenuHierarchicalEnumerable();
        }
        public MenuHierarchyData(MenuItemInfo obj, MenuConfig menuConfig)
        {
            itemInfoObject = obj;
            subItems = new MenuHierarchicalEnumerable(menuConfig.IsSort);
            config = menuConfig;
        }
        public MenuHierarchyData(MenuItemInfo obj, IEnumerable<PluginPermission> permissions)
            : this(obj)
        {
            menuPermissions = permissions;
        }
        public MenuHierarchyData(MenuItemInfo obj, MenuConfig menuConfig, IEnumerable<PluginPermission> permissions)
            : this(obj, menuConfig)
        {
            menuPermissions = permissions;
        }

        public MenuHierarchyData CopyForAuthorizedMenu()
        {
            return new MenuHierarchyData(this.itemInfoObject, this.config, this.menuPermissions);
        }

        #region Data Binding
        public string Text
        {
            get
            {
                return itemInfoObject.Text;
            }
        }
        public string Name
        {
            get
            {
                return itemInfoObject.Name;
            }
        }
        public string Url
        {
            get
            {
                return itemInfoObject.NavigateUrl;
            }
        }
        public string ToolTip
        {
            get
            {
                return itemInfoObject.ToolTip;
            }
        }
        public ICommand Command
        {
            get { return itemInfoObject.Command; }
        }

        public MenuHierarchicalEnumerable Items
        {
            get
            {
                return this.subItems;
            }
            set
            {
                this.subItems = value;
            }
        }
        public IEnumerable<PluginPermission> Permissions
        {
            get
            {
                return this.menuPermissions;
            }
        }
        public MenuConfig Config
        {
            get
            {
                return config;
            }
        }
        #endregion

        #region Implements IHierarchyData
        IHierarchicalEnumerable IHierarchyData.GetChildren()
        {
            return CreateChildren();
        }

        IHierarchyData IHierarchyData.GetParent()
        {
            return null;
        }

        bool IHierarchyData.HasChildren
        {
            get { return HasChildren(); }
        }

        object IHierarchyData.Item
        {
            get { return this; }
        }

        string IHierarchyData.Path
        {
            get { return itemInfoObject.NavigateUrl; }
        }

        string IHierarchyData.Type
        {
            get { return GetType().ToString(); }
        }
        #endregion

        #region Implements IHierarchyData
        int IComparable<MenuHierarchyData>.CompareTo(MenuHierarchyData other)
        {
            return this.itemInfoObject.Text.CompareTo(other.itemInfoObject.Text);
        }
        #endregion

        #region Protected Members
        protected virtual bool HasChildren()
        {
            return (subItems != null && subItems.Count() > 0);
        }
        protected virtual IHierarchicalEnumerable CreateChildren()
        {
            return this.subItems;
        }
        #endregion

        public MvcHtmlString MenuActive(MenuHierarchyData menuData, String urlAbsolutePath)
        {
            if (urlAbsolutePath.Equals(menuData.Url))
                return MvcHtmlString.Create("class=\"active\"");
            else
            {
                if (menuData.Items != null && menuData.Items.Any())
                    foreach (var menuItem in menuData.Items)
                    {
                        var tempActiveString = MenuActive(menuItem, urlAbsolutePath);
                        if (!string.IsNullOrEmpty(tempActiveString.ToString()))
                        {
                            return tempActiveString;
                        }
                    }
            }

            // if we are here return empty string
            return MvcHtmlString.Create(String.Empty);
        }
    }
}
