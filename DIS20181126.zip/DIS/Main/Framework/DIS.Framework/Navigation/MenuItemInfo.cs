﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace DIS.Framework.Navigation
{
    public class MenuItemInfo
    {
        public string Text { get; private set; }
        public string Name { get; private set; }
        public string NavigateUrl { get; private set; }
        public string ToolTip { get; private set; }
        public ICommand Command { get; set; }

        public MenuItemInfo(string text) : this(text, string.Empty, string.Empty, string.Empty, null) { }
        public MenuItemInfo(string text, string name) : this(text, name, string.Empty, string.Empty, null) { }
        public MenuItemInfo(string text, string name, string navigateUrl) : this(text, name, navigateUrl, string.Empty, null) { }
        public MenuItemInfo(string text, string name, ICommand command) : this(text, name, string.Empty, string.Empty, command) { }
        public MenuItemInfo(string text, string name, string navigateUrl, string toolTip, ICommand command)
        {
            Text = text;
            Name = name;
            NavigateUrl = navigateUrl;
            ToolTip = toolTip;
            Command = command;
        }
    }
}
