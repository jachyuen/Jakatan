﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;

namespace DIS.Framework.Navigation
{
    public class MenuHierarchicalEnumerable : List<MenuHierarchyData>, IHierarchicalEnumerable
    {
        private bool IsSort = true;

        public string Area { get; set; }
        public MenuHierarchicalEnumerable() : base() { }

        public MenuHierarchicalEnumerable(bool isSort) : base()
        {
            this.IsSort = isSort;
        }

        public MenuHierarchicalEnumerable(string area) : base()
        {
            this.Area = area;
        }

        public MenuHierarchicalEnumerable(string area, bool isSort) : base()
        {
            this.Area = area;
            this.IsSort = isSort;
        }

        #region Sort
        public void RecursiveSort()
        {
            RecursiveSort(this, 0, null);
        }
        public void RecursiveSort(int[] skipLevels)
        {
            RecursiveSort(this, 0, skipLevels);
        }
        private void RecursiveSort(MenuHierarchicalEnumerable subMenuEnum, int currentLevel, int[] skipLevels)
        {
            if (subMenuEnum != null && subMenuEnum.Any())
            {
                if (subMenuEnum.IsSort == true)
                    if (skipLevels == null || !skipLevels.Any(row => row == currentLevel))
                        ((List<MenuHierarchyData>)subMenuEnum).Sort();


                foreach (var child in subMenuEnum)
                {
                    RecursiveSort(child.Items, currentLevel + 1, skipLevels);
                }
            }
        }
        #endregion

        #region Implements IEnumerable
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        #region Implements IHierarchicalEnumerable
        IHierarchyData IHierarchicalEnumerable.GetHierarchyData(object enumeratedItem)
        {
            return (IHierarchyData)enumeratedItem;
        }
        #endregion
    }
}
