﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Navigation
{
    public class MenuConfig
    {
        public bool SuppressIfEmpty { get; set; }
        public bool AllowDropDownMenu { get; set; }
        public bool AlwaysShowInPluginMenu { get; set; }
        public bool IsSort { get; set; }

        public MenuConfig()
        {
            SuppressIfEmpty = false;
            AllowDropDownMenu = true;
            AlwaysShowInPluginMenu = false;
            IsSort = true;
        }
    }
}
