﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Navigation
{
    public interface IPluginMenuProvider
    {
        /// <summary>
        /// Get Menu Data for the plugin
        /// </summary>
        /// <returns>MenuHierarchicalEnumerable object of plugin menu</returns>
        MenuHierarchicalEnumerable GetPluginMenuData();
    }
}
