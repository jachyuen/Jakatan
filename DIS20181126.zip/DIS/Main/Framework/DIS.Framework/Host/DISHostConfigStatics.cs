﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIS.Framework.Host
{
    public static class WebHostConfigStatics
    {
        public static readonly string DefaultArea = ConfigurationManager.AppSettings["DefaultArea"];
        public static readonly string AdminGroups = ConfigurationManager.AppSettings["AdminGroups"];
    }

    public static class WcfHostConfigStatics
    {
        public static readonly string ServiceDisplayName = ConfigurationManager.AppSettings["ServiceDisplayName"];
        public static readonly string ServiceName = ConfigurationManager.AppSettings["ServiceName"];
        public static readonly string ServiceDesc = ConfigurationManager.AppSettings["ServiceDesc"];
    }

    public static class DISHostConfigStatics
    {
        public static readonly string Environment = ConfigurationManager.AppSettings["Env"];

        //Plugins Assembly related variables 
        public static readonly string PluginsPath = ConfigurationManager.AppSettings["PluginsPath"];
        public static readonly string PluginsTempPath = ConfigurationManager.AppSettings["PluginTempPath"];
        public static readonly string PluginsList = ConfigurationManager.AppSettings["PluginsList"];
        public static readonly bool PluginsConfigCached = bool.Parse(ConfigurationManager.AppSettings["PluginsConfigCached"]);
        public static readonly string PluginsNameRegex = ConfigurationManager.AppSettings["PluginsNameRegex"];
        public static readonly string PluginsDllNameRegex = ConfigurationManager.AppSettings["PluginsDllNameRegex"];
        public static readonly string PluginsNameStringFormat = ConfigurationManager.AppSettings["PluginsNameStringFormat"];
        public static readonly bool PluginsEncrypted = bool.Parse(ConfigurationManager.AppSettings["PluginsEncrypted"]);

        //Plugins Configuration variables
        public static readonly string PluginsConfigFileExt = ConfigurationManager.AppSettings["PluginsConfigFileExt"];
        public static readonly string PluginsConfigPath = ConfigurationManager.AppSettings["PluginsConfigPath"];
        public static readonly string PluginsExternalConfigPath = ConfigurationManager.AppSettings["PluginsExternalConfigPath"];
        public static readonly string PluginsEncryptedConfigPath = ConfigurationManager.AppSettings["PluginsEncryptedConfigPath"];
        public static readonly string PluginsEncryptedConfigFileExt = ConfigurationManager.AppSettings["PluginsEncryptedConfigFileExt"];

        public static readonly bool PluginsExternalConfigEncrypted = bool.Parse(ConfigurationManager.AppSettings["PluginsExternalConfigEncrypted"]);
        public static readonly string PluginsExternalConfigEncryptPath = ConfigurationManager.AppSettings["PluginsExternalConfigEncryptPath"];
    }
}
