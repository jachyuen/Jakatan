﻿using Autofac;
using DIS.Framework.Infrastructure.DependencyManagement;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DIS.Framework.Host
{
    public interface IDISHost
    {
        ContainerManager ContainerManager { get; }

        //void Initialize(IContainer container);
        void Initialize();

        T Resolve<T>() where T : class;

        object Resolve(Type type);

        T[] ResolveAll<T>();

        //void RegisterSpecificComponents(IContainer container);

        //void RegisterMvcSingletons(IContainer container, ViewEngineCollection engines, RouteCollection routes);
    }

}
