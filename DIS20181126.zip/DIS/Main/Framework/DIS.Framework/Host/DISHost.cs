﻿using Autofac;
using Autofac.Core;
using Autofac.Features.Indexed;
using Autofac.Integration.Mvc;
using DIS.Framework.Caching;
using DIS.Framework.Commands;
using DIS.Framework.DataAccess;
using DIS.Framework.DataAccess.EntityFrameworkRepository.Repository;
using DIS.Framework.DataAccess.PlainSQLRepository.DB;
using DIS.Framework.Infrastructure;
using DIS.Framework.Infrastructure.DependencyManagement;
using DIS.Framework.Modules;
using DIS.Framework.MVCFilters;
using DIS.Framework.Navigation;
using DIS.Framework.Plugins.Configuration;
using DIS.Framework.Plugins.Utility;
using DIS.Framework.Security;
using DIS.Framework.Security.Authorization;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace DIS.Framework.Host
{
    public abstract class DISHost : IDISHost
    {
        public ILog _log { get; set; }

        public DISHost()
        {
            _log = LogManager.GetLogger(typeof(DISHost));
        }

        private ContainerManager _containerManager;
        public ContainerManager ContainerManager
        {
            get { return _containerManager; }
        }

        //public virtual void Initialize(IContainer container)
        public virtual void Initialize()
        {
            var containerBuilder = new ContainerBuilder();

            //register dependencies
            RegisterDependencies(containerBuilder);

            HostSpecificRegistration(containerBuilder);

            RegisterPluginPackages(containerBuilder);

            var container = containerBuilder.Build();
            _containerManager = new ContainerManager(container);

            AfterContainerIsBuilt();

            //startup tasks
            RunStartupTasks();
        }

        protected abstract void HostSpecificRegistration(ContainerBuilder containerBuilder);
        protected abstract void AfterContainerIsBuilt();

        protected virtual void RunStartupTasks()
        {
            var typeFinder = this.Resolve<ITypeFinder>();
            var startUpTaskTypes = typeFinder.FindClassesOfType<IStartupTask>();
            var startUpTasks = new List<IStartupTask>();
            foreach (var startUpTaskType in startUpTaskTypes)
                startUpTasks.Add((IStartupTask)Activator.CreateInstance(startUpTaskType));
            //sort
            startUpTasks = startUpTasks.AsQueryable().OrderBy(st => st.Order).ToList();
            foreach (var startUpTask in startUpTasks)
                startUpTask.Execute();
        }

        protected virtual void RegisterPluginPackages(ContainerBuilder containerBuilder)
        {
            //var typeFinder = this.Resolve<ITypeFinder>();
            var typeFinder = new WebAppTypeFinder(_log);
            var assemblies = typeFinder.GetAssemblies();
            foreach (var assembly in assemblies)
            {
                containerBuilder.RegisterAssemblyTypes(assembly)
                    .AssignableTo<IPluginsPackage>()
                    .Keyed<IPluginsPackage>(t => t.Assembly.GetName().Name)
                    .As<IPluginsPackage>()
                    .SingleInstance();
                //.InstancePerLifetimeScope(); // also refer to http://stackoverflow.com/questions/14603928/automatically-bind-interfaces-using-autofac 
            }

            //var plugins = this.ResolveAll<IPluginsPackage>();
            var plugins = typeFinder.FindClassesOfType<IPluginsPackage>();
            var pluginsInstance = new List<IPluginsPackage>();

            foreach (var plugin in plugins)
                pluginsInstance.Add((IPluginsPackage)Activator.CreateInstance(plugin));

            foreach (var pluginInstance in pluginsInstance)
            {
                var pConfig = new PluginsConfiguration(new CryptoHelper(_log));
                var pConfigManager = new PluginsConfigurationManager(new FileExternalPluginsConfigurationManager(new CryptoHelper(_log)), pConfig);
                pluginInstance._log = _log;
                pluginInstance.Register(containerBuilder, pConfig, pConfigManager);
            }
        }

        protected abstract void RegisterAdditionalDependencies(ContainerBuilder containerBuilder);
        protected virtual void RegisterDependencies(ContainerBuilder containerBuilder)
        {
            // Be careful of order of codes in this function and always append new code to the end of this function unless you know what you are doing.

            //we create new instance of ContainerBuilder
            //because Build() or Update() method can only be called once on a ContainerBuilder.
            //Register logger.
            containerBuilder.RegisterModule<Logging.LoggingModule>();
            //TODO:Register AutoFac log binding/integration if exists.

            //dependencies            
            containerBuilder.RegisterInstance(this).As<IDISHost>().SingleInstance();

            _log.Info("registering typefinder...");
            var typeFinder = new WebAppTypeFinder(_log);
            containerBuilder.RegisterInstance(typeFinder).As<ITypeFinder>().SingleInstance();

            //TODO: normally, new dependency within the framework should add below this line. VVVVVVVVV
            containerBuilder.RegisterType<MemoryCacheManager>().As<ICacheManager>().Named<ICacheManager>("DIS_memory_cache").SingleInstance();
            containerBuilder.RegisterType<CryptoHelper>().As<ICryptoHelper>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsConfiguration>().As<IPluginsConfiguration>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsCatalogService>().As<IPluginsCatalogService>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginFileHelper>().As<IPluginFileHelper>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsConfigurationManager>().As<IPluginsConfigurationManager>().InstancePerLifetimeScope();
            //builder.RegisterType<FileExternalPluginsConfigurationManager>().As<IExternalPluginsConfigurationManager>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<FileExternalPluginsConfigurationManager>().As<IExternalPluginsConfigurationManager>().SingleInstance();
            containerBuilder.RegisterType<ImpersonationProvider>().As<IImpersonationProvider>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<ExecuteHelper>().As<IExecuteHelper>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<DBHelper>().As<IDBHelper>().InstancePerLifetimeScope();

            containerBuilder.RegisterType<MenuService>().As<IMenuService>().InstancePerLifetimeScope();
            //Authorization related repository registrations
            if (ConfigurationManager.ConnectionStrings["DISDb"] != null)
            {
                containerBuilder.Register<IDbContext<int>>(c =>
                {
                    ConnectionInfo connInfo = new ConnectionInfo(ConfigurationManager.ConnectionStrings["DISDb"].ConnectionString, ConfigurationManager.ConnectionStrings["DISDb"].ProviderName);
                    var conn = DbProviderFactories.GetFactory(connInfo.ProviderName).CreateConnection();
                    conn.ConnectionString = connInfo.ConnectionString;

                    return new DISDbContext<int>(conn);
                })
                .Named<IDbContext<int>>("DISDb")
                .InstancePerLifetimeScope();

                //containerBuilder.RegisterGeneric(typeof(EFRepository<,>))
                //    .As(typeof(IEFRepository<,>))
                //    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                //    .InstancePerLifetimeScope();


                containerBuilder.RegisterType<EFRepository<AppRole, int>>()
                    .As<IEFRepository<AppRole, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<EFRepository<AppPermission, int>>()
                    .As<IEFRepository<AppPermission, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<EFRepository<AppToExclude, int>>()
                    .As<IEFRepository<AppToExclude, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<EFRepository<AuditRecord, int>>()
                    .As<IEFRepository<AuditRecord, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<EFRepository<RolePermission, int>>()
                    .As<IEFRepository<RolePermission, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<EFRepository<UserRole, int>>()
                    .As<IEFRepository<UserRole, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
            }
            else
            {
                containerBuilder.Register<IDbContext<int>>(c =>
                {                    
                    var conn = DbProviderFactories.GetFactory("System.Data.SqlClient").CreateConnection();
                    return new DISDbContext<int>(conn);
                })
                .Named<IDbContext<int>>("DISDb")
                .InstancePerLifetimeScope();

                containerBuilder.RegisterType<NullRepository<AppRole, int>>()
                    .As<IEFRepository<AppRole, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<NullRepository<AppPermission, int>>()
                    .As<IEFRepository<AppPermission, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<NullRepository<AppToExclude, int>>()
                    .As<IEFRepository<AppToExclude, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<NullRepository<AuditRecord, int>>()
                    .As<IEFRepository<AuditRecord, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<NullRepository<RolePermission, int>>()
                    .As<IEFRepository<RolePermission, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
                containerBuilder.RegisterType<NullRepository<UserRole, int>>()
                    .As<IEFRepository<UserRole, int>>()
                    .WithParameter(ResolvedParameter.ForNamed<IDbContext<int>>("DISDb"))
                    .InstancePerLifetimeScope();
            }

            containerBuilder.RegisterType<RoleService>().As<IRoleService>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<AuthorizationService>().As<IAuthorizationService>().InstancePerLifetimeScope();

            //TODO: normally, new dependency within the framework should add above this line. ^^^^^^^^^^


            //Register other Host related components.
            RegisterAdditionalDependencies(containerBuilder);
        }


        public T Resolve<T>() where T : class
        {
            return ContainerManager.Resolve<T>();
        }

        public object Resolve(Type type)
        {
            return ContainerManager.Resolve(type);
        }

        public T[] ResolveAll<T>()
        {
            return ContainerManager.ResolveAll<T>();
        }
    }
}
