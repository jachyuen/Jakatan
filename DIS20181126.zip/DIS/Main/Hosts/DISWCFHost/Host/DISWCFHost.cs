﻿using Autofac;
using Autofac.Integration.Mvc;
using Autofac.Integration.Wcf;
using DIS.Framework.Commands;
using DIS.Framework.FileSystems;
using DIS.Framework.FileSystems.Plugins;
using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using DIS.Framework.Infrastructure.DependencyManagement;
using DIS.Framework.Logging;
using DIS.Framework.Modules;
using DIS.Framework.PluginsViewEngine;
using DIS.Framework.Security.Authorization;
using FluentValidation.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace DISWCFHost.Host
{
    public class DISWCFHost : DISHost
    {
        protected override void RegisterAdditionalDependencies(ContainerBuilder containerBuilder)
        {
            _log.Info("registering IDependencyRegistrar, find and register plugins ...");
            //var typeFinder = this.Resolve<ITypeFinder>();
            var typeFinder = new WebAppTypeFinder(_log);
            //register dependencies provided by other assemblies
            var drTypes = typeFinder.FindClassesOfType<IDependencyRegistrar>();
            var drInstances = new List<IDependencyRegistrar>();
            foreach (var drType in drTypes)
                drInstances.Add((IDependencyRegistrar)Activator.CreateInstance(drType));
            //sort
            drInstances = drInstances.AsQueryable().OrderBy(t => t.Order).ToList();
            foreach (var dependencyRegistrar in drInstances)
                dependencyRegistrar.Register(containerBuilder, typeFinder);

            containerBuilder.RegisterFilterProvider();

            _log.Info("registering some other MVC related dependency...");
            //builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
            //    .AssignableTo<ICustomVirtualPathProvider>()
            //    .AsImplementedInterfaces()
            //    .InstancePerLifetimeScope(); // also refer to http://stackoverflow.com/questions/14603928/automatically-bind-interfaces-using-autofac 
            containerBuilder.RegisterType<AssemblyResourceProvider>().As<ICustomVirtualPathProvider>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsControllerFactory>().As<IControllerFactory>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsRazorViewEngine>().As<IViewEngine>().InstancePerLifetimeScope();

            containerBuilder.RegisterType<CommandLineParser>().As<ICommandLineParser>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<CommandParametersParser>().As<ICommandParametersParser>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<CommandHandlerDescriptorBuilder>().As<ICommandHandlerDescriptorBuilder>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<CommandManager>().As<ICommandManager>().InstancePerLifetimeScope();

            containerBuilder.RegisterAssemblyTypes(typeof(IDISHost).Assembly)
                .AssignableTo<ICommandHandler>()
                .Keyed<ICommandHandler>(t => t.Name)
                .As<ICommandHandler>()
                .InstancePerLifetimeScope();

            containerBuilder.RegisterType<ExeLogger>().As<IExeLogger>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<WebUserService>().As<IUserService>().InstancePerLifetimeScope();
        }

        protected override void HostSpecificRegistration(ContainerBuilder containerBuilder)
        {
            _log.Info("registering virtualPathProviders...");
            RegisterControllerFactory();
        }

        private void RegisterVpps()
        {
            // Registering a Virtual Path Provider to resolve resources (i.e views, static content) embedded into plugins dll
            var virtualPathProviders = this.ResolveAll<ICustomVirtualPathProvider>();
            foreach (var vpp in virtualPathProviders)
            {
                HostingEnvironment.RegisterVirtualPathProvider(vpp.Instance);
            }
        }

        private void RegisterControllerFactory()
        {
            //autofac auto reg this? by builder.RegisterType<PluginsControllerFactory>().As<IControllerFactory>().InstancePerLifetimeScope();
            //ControllerBuilder.Current.SetControllerFactory(Singleton<IDISHost>.Instance.ContainerManager.Resolve<IControllerFactory>());
        }

        private void RegisterEngines(ViewEngineCollection engines)
        {
            engines.Clear();
            foreach (var ve in Singleton<IDISHost>.Instance.ContainerManager.ResolveAll<IViewEngine>())
            {
                engines.Add(ve);
            }
        }

        private void RegisterModelValidators()
        {
            FluentValidationModelValidatorProvider.Configure();
        }

        protected override void AfterContainerIsBuilt()
        {
            //set the AutofacHostFactory.Container
            AutofacHostFactory.Container = this.ContainerManager.Container;
            //set dependency resolver
            DependencyResolver.SetResolver(new AutofacDependencyResolver(this.ContainerManager.Container));

            RegisterVpps();
            RegisterEngines(ViewEngines.Engines);
            RegisterModelValidators();
        }
    }
}