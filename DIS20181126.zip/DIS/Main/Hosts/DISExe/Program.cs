﻿using DISExe.Host;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DISExe
{
    class Program
    {
        static int Main(string[] args)
        {
            #region init log4net
            string log4netPath = ConfigurationManager.AppSettings["Log4netConfigPath"];
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, log4netPath);
            XmlConfigurator.Configure(new System.IO.FileInfo(fullPath));
            #endregion

            return (int)new DISExeHost().Run(Console.In, Console.Out, args);

        }
    }
}
