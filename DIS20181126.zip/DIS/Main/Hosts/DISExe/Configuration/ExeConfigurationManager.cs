﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;

namespace DISExe.Configuration
{
    public class ExeConfigurationManager
    {
        public static readonly string configRoot_XPath = "/configuration/env";
        public static readonly string plugSettings_XPath = "settings/setting";

        public IDictionary<string, string> GetPlugSetting()
        {
            IDictionary<string, string> settings = new Dictionary<string, string>();
            XPathNodeIterator nodes = this.FindByEnv().Select(plugSettings_XPath);
            while (nodes.MoveNext())
            {
                settings.Add(nodes.Current.GetAttribute("key", ""), nodes.Current.GetAttribute("value", ""));
            }

            if (settings.Count == 0)
                throw new ConfigurationErrorsException("No plugins settings defined");

            return settings;
        }

        private XPathNavigator FindByEnv()
        {
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, EnvConfigPath);
            XPathDocument document = new XPathDocument(fullPath);
            XPathNavigator navigator = document.CreateNavigator();
            XPathNodeIterator nodes = navigator.Select(String.Format("{0}[@id=\"{1}\"]", configRoot_XPath, Env));
            if (nodes.Count > 0)
            {
                nodes.MoveNext();
                return nodes.Current;
            }
            throw new ConfigurationErrorsException(String.Format("Plugins has no defined configuration for current environment: {0}", Env));
        }

        private string Env
        {
            get
            {
                return ConfigurationManager.AppSettings["Env"];
            }

        }

        private string EnvConfigPath
        {
            get
            {
                return ConfigurationManager.AppSettings["EnvConfigPath"];
            }
        }
    }
}
