﻿using DISExe.Command;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DISExe.Host
{
    public class DISExeHost
    {
        private CommandHost _host;

        public int Run(TextReader input, TextWriter output, string[] args)
        {
            _host = new CommandHost(input, output, args);

            return _host.Run();
        }
    }
}
