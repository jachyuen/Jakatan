﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DISExe.Command
{
    public enum CommandReturnCodes
    {
        Ok = 0,
        Error = 1
    }
}
