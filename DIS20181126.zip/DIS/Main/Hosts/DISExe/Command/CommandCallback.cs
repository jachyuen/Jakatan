﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DISExe.Command
{
    public class CommandCallback : ICommandCallback
    {
        private ILog _log;

        public CommandCallback()
        {
            _log = LogManager.GetLogger(this.GetType());
        }
        public void SendResult(string message)
        {
            Console.Write(message);
            //_log.Info(message);
        }

        public void IsAlive()
        {
        }
    }
}
