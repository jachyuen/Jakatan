﻿using DIS.Framework.Commands;
using DISExe.Configuration;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DISExe.Command
{
    public class CommandHost
    {
        private string[] _inputArgs { get; set; }
        private TextReader _input { get; set; }
        private TextWriter _output { get; set; }
        private CommandParameters _params { get; set; }
        private CommandProxy _cmdProxy = new CommandProxy();
        private CommandLineParser _cliParser = new CommandLineParser();
        private ILog _log;

        public CommandHost(TextReader input, TextWriter output, string[] args)
        {
            _inputArgs = args;
            _input = input;
            _output = output;
            _log = LogManager.GetLogger(this.GetType());
        }

        public int Run()
        {
            return DoRun();
        }

        private int DoRun()
        {
            _params = InitHostContext();
            try
            {
                CheckWCFWeb();
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Exception encountered during DIS commmand session. message: {0}", ex.Message);
                return (int)CommandReturnCodes.Error;
            }

            if (_params.Arguments.Any())
                return RunSingleCommand(_params);
            else
                return RunInteractiveMode();
        }

        private void CheckWCFWeb()
        {
            ExeConfigurationManager cfgMgr = new ExeConfigurationManager();
            string[] WCFWebURLs = cfgMgr.GetPlugSetting()["invokeURL"].Split(new string[] { "||" }, StringSplitOptions.RemoveEmptyEntries);


            try
            {
                foreach (string WCFWebURL in WCFWebURLs)
                    using (var handler = new WebRequestHandler())
                    {
                        handler.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;

                        using (var client = new HttpClient(handler))
                        {
                            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                            using (var formData = new MultipartFormDataContent())
                            {
                                //var response = client.PostAsync(WCFWebURL, formData).Result;
                                var response = client.GetAsync(WCFWebURL).Result;
                                if (response == null)
                                //if (!response.IsSuccessStatusCode)
                                {
                                    throw new Exception(string.Format("Not able to invoke WCF Web [{0}]. Please check WCF Web site readiness.", WCFWebURL));
                                }
                            }
                        }
                    }
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Exception encountered during DIS commmand session. message: {0}", ex.Message);
                throw new Exception("Not able to invoke WCF Web. Please check WCF Web site readiness.");
            }
        }

        private CommandParameters InitHostContext()
        {
            CommandParameters p = CommandParametersParser.Parse(_inputArgs);
            return p;
        }

        private int RunCommand(CommandParameters parameters, bool IsSessionCloseOnCompletion)
        {
            int returnCode = (int)CommandReturnCodes.Ok;
            try
            {
                _log.InfoFormat("Exehost send command: \"{0} {1}\"",
                parameters.Arguments.Count() > 0 ? parameters.Arguments.Aggregate((current, next) => current + " " + next) : "",
                parameters.Switches.Count() > 0 ? parameters.Switches.Select((pair) => "/" + pair.Key + ":" + pair.Value).Aggregate((current, next) => current + " " + next) : "");

                returnCode = _cmdProxy.Execute(parameters);

                if (IsSessionCloseOnCompletion)
                    _cmdProxy.Close();

                _log.InfoFormat("Exehost finished command. Return status:{0}", returnCode);
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Exception: {0}", ex.Message);
                returnCode = (int)CommandReturnCodes.Error;
                _cmdProxy.Close();
            }
            return returnCode;
        }

        private int RunSingleCommand(CommandParameters p)
        {
            return RunCommand(p, true);
        }

        private int RunInteractiveMode()
        {
            _output.WriteLine("Type \"exit\" to exit");
            while (true)
            {
                var command = ReadCommand();
                switch (command.Trim().ToLowerInvariant())
                {
                    case "exit":
                        _cmdProxy.Close();
                        return (int)CommandReturnCodes.Ok;
                    case "DISsh":
                        _output.WriteLine(@"DIS SHell");
                        _output.WriteLine(@"DISSH is proudly developed and maintained by Jakatan Development team!");
                        break;
                    case "":
                        break;
                    default:
                        _params = CommandParametersParser.Parse(_cliParser.Parse(command));
                        RunCommand(_params, false);

                        break;
                }
            }
        }

        private string ReadCommand()
        {
            _output.WriteLine();
            _output.Write("DISSH> ");
            return _input.ReadLine();
        }

    }
}
