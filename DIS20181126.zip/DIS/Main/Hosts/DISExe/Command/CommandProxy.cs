﻿using DIS.Framework.Commands;
using DISExe.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DISExe.Command
{
    public class CommandProxy
    {
        private CommandClient _client;
        private NetTcpBinding _binding;
        private EndpointAddress _endPoint;

        public CommandProxy()
        {
            ExeConfigurationManager cfgMgr = new ExeConfigurationManager();
            int genericTimeout = int.Parse(cfgMgr.GetPlugSetting()["GenericTimeout"]);

            _binding = new NetTcpBinding()
            {
                MaxReceivedMessageSize = int.MaxValue,
                OpenTimeout = new TimeSpan(0, 0, genericTimeout),
                CloseTimeout = new TimeSpan(0, 0, genericTimeout),
                ReceiveTimeout = new TimeSpan(0, 0, genericTimeout),
                SendTimeout = new TimeSpan(0, 0, genericTimeout),
                MaxBufferPoolSize = int.MaxValue,
                ReaderQuotas = new System.Xml.XmlDictionaryReaderQuotas() { MaxStringContentLength = int.MaxValue },
                TransactionFlow = false,
                HostNameComparisonMode = HostNameComparisonMode.StrongWildcard,
            };

            string url = cfgMgr.GetPlugSetting()["WcfURL"];
            _endPoint = new EndpointAddress(url);

            InitClient();
        }

        private void InitClient()
        {
            _client = new CommandClient(new InstanceContext(new CommandCallback()), _binding, _endPoint);
        }

        public int Execute(CommandParameters p)
        {
            if (_client == null)
            {
                InitClient();
            }
            else
            {
                switch (_client.State)
                {
                    case CommunicationState.Opened:
                    case CommunicationState.Created:
                        break;
                    default:
                        _client.Abort();
                        InitClient();
                        break;
                }
            }
            int tobeReturned = _client.Execute(p);
            _client.Abort();
            return tobeReturned;
        }

        public void Close()
        {
            _client.Abort();
        }
    }
}
