﻿using DISWebHost.Host;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace DISWebHost
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private static ILog _log = LogManager.GetLogger(typeof(System.Web.HttpApplication));

        protected void Application_Start()
        {
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new System.IO.FileInfo(AppDomain.CurrentDomain.BaseDirectory + "\\Config\\log4net.config"));
            bool log4netIsConfigured = log4net.LogManager.GetRepository().Configured;

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            WebHostContext.Initialize();
        }
    }
}
