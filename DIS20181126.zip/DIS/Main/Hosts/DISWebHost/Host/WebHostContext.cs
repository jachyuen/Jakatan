﻿using Autofac;
using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;

namespace DISWebHost.Host
{
    public class WebHostContext
    {
        #region Methods

        /// <summary>
        /// Initializes a static instance of the Nop factory.
        /// </summary>
        /// <param name="forceRecreate">Creates a new factory instance even though the factory has been previously initialized.</param>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static IDISHost Initialize()
        {
            if (Singleton<IDISHost>.Instance == null)
            {
                Singleton<IDISHost>.Instance = new DISWebHost();
                Singleton<IDISHost>.Instance.Initialize();
            }
            return Singleton<IDISHost>.Instance;
        }

        /// <summary>
        /// Sets the static engine instance to the supplied engine. Use this method to supply your own engine implementation.
        /// </summary>
        /// <remarks>Only use this method if you know what you're doing.</remarks>
        public static void Replace(IDISHost host)
        {
            Singleton<IDISHost>.Instance = host;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the singleton Nop engine used to access Nop services.
        /// </summary>
        public static IDISHost Current
        {
            get
            {
                if (Singleton<IDISHost>.Instance == null)
                {
                    Initialize();
                }
                return Singleton<IDISHost>.Instance;
            }
        }

        #endregion
    }
}