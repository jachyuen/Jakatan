﻿using Autofac;
using Autofac.Integration.Mvc;
using DIS.Framework.FileSystems;
using DIS.Framework.FileSystems.Plugins;
using DIS.Framework.Host;
using DIS.Framework.Infrastructure;
using DIS.Framework.Infrastructure.DependencyManagement;
using DIS.Framework.Modules;
using DIS.Framework.PluginsViewEngine;
using DIS.Framework.Security.Authorization;
using DIS.Framework.Validation;
using FluentValidation.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace DISWebHost.Host
{
    public class DISWebHost : DISHost
    {
        protected override void RegisterAdditionalDependencies(ContainerBuilder containerBuilder)
        {
            _log.Info("registering IDependencyRegistrar, find and register plugins ...");
            //var typeFinder = this.Resolve<ITypeFinder>();
            var typeFinder = new WebAppTypeFinder(_log);
            //register dependencies provided by other assemblies
            var drTypes = typeFinder.FindClassesOfType<IDependencyRegistrar>();
            var drInstances = new List<IDependencyRegistrar>();
            foreach (var drType in drTypes)
                drInstances.Add((IDependencyRegistrar)Activator.CreateInstance(drType));
            //sort
            drInstances = drInstances.AsQueryable().OrderBy(t => t.Order).ToList();
            foreach (var dependencyRegistrar in drInstances)
                dependencyRegistrar.Register(containerBuilder, typeFinder);

            containerBuilder.RegisterFilterProvider();

            _log.Info("registering some other MVC related dependency...");
            //builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
            //    .AssignableTo<ICustomVirtualPathProvider>()
            //    .AsImplementedInterfaces()
            //    .InstancePerLifetimeScope(); // also refer to http://stackoverflow.com/questions/14603928/automatically-bind-interfaces-using-autofac 
            containerBuilder.RegisterType<AssemblyResourceProvider>().As<ICustomVirtualPathProvider>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsControllerFactory>().As<IControllerFactory>().InstancePerLifetimeScope();
            containerBuilder.RegisterType<PluginsRazorViewEngine>().As<IViewEngine>().InstancePerLifetimeScope();

            containerBuilder.RegisterType<WebUserService>().As<IUserService>().InstancePerLifetimeScope();
        }

        protected override void AfterContainerIsBuilt()
        {
            //set dependency resolver
            DependencyResolver.SetResolver(new AutofacDependencyResolver(this.ContainerManager.Container));
            RegisterVpps();
            RegisterEngines(ViewEngines.Engines);
            RegisterModelValidators();

            var plugins = this.ResolveAll<IPluginsPackage>();

            foreach (var plugin in plugins)
            {
                MVCPluginsPackage tempMVC = plugin as MVCPluginsPackage;
                if (tempMVC != null)
                    tempMVC.RegisterAuthorizations();

                WPFPluginsPackage tempWPF = plugin as WPFPluginsPackage;
                if (tempWPF != null)
                    tempWPF.RegisterAuthorizations();

            }
        }

        protected override void HostSpecificRegistration(ContainerBuilder containerBuilder)
        {
            _log.Info("registering virtualPathProviders...");
            RegisterControllerFactory();
        }

        private void RegisterVpps()
        {
            // Registering a Virtual Path Provider to resolve resources (i.e views, static content) embedded into plugins dll
            var virtualPathProviders = this.ResolveAll<ICustomVirtualPathProvider>();
            foreach (var vpp in virtualPathProviders)
            {
                HostingEnvironment.RegisterVirtualPathProvider(vpp.Instance);
            }
        }

        private void RegisterControllerFactory()
        {
            //autofac auto reg this? by builder.RegisterType<PluginsControllerFactory>().As<IControllerFactory>().InstancePerLifetimeScope();
            //ControllerBuilder.Current.SetControllerFactory(Singleton<IDISHost>.Instance.ContainerManager.Resolve<IControllerFactory>());
        }

        private void RegisterEngines(ViewEngineCollection engines)
        {
            engines.Clear();
            foreach (var ve in this.ResolveAll<IViewEngine>())
            {
                engines.Add(ve);
            }
        }

        private void RegisterModelValidators()
        {
            //fluent validation, suppose to allow non default constructor (without any arguments)
            var fluentValidationModelValidatorProvider = new FluentValidationModelValidatorProvider(new WebValidatorFactory(this.ContainerManager.Container));
            DataAnnotationsModelValidatorProvider.AddImplicitRequiredAttributeForValueTypes = false;
            fluentValidationModelValidatorProvider.AddImplicitRequiredValidator = false;
            ModelValidatorProviders.Providers.Add(fluentValidationModelValidatorProvider);

            //FluentValidationModelValidatorProvider.Configure();
        }

    }
}