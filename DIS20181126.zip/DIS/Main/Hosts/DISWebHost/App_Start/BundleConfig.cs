﻿using System.Web;
using System.Web.Optimization;

namespace DISWebHost
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                        "~/Scripts/jquery.unobtrusive-ajax.min.js",
                        "~/Scripts/jquery.validate.min.js",
                        "~/Scripts/jquery.validate.unobtrusive.min.js",
                        "~/Scripts/jquery.blockUI.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new ScriptBundle("~/bundles/AdminLTE").Include(
                "~/Scripts/AdminLTE/plugins/fastclick/fastclick.js",
                "~/Scripts/AdminLTE/app.js",
                "~/Scripts/AdminLTE/plugins/jQueryUI/jquery-ui-1.10.3.min.js",
                "~/Scripts/AdminLTE/plugins/sparkline/jquery.sparkline.js",
                "~/Scripts/AdminLTE/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js",
                "~/Scripts/AdminLTE/plugins/jvectormap/jquery-jvectormap-world-mill-en.js",
                "~/Scripts/AdminLTE/plugins/datetimepicker/moment-with-locales.js",
                "~/Scripts/AdminLTE/plugins/daterangepicker/daterangepicker.js",
                "~/Scripts/AdminLTE/plugins/datepicker/bootstrap-datepicker.js",
                "~/Scripts/AdminLTE/plugins/datetimepicker/bootstrap-datetimepicker.js",
                "~/Scripts/AdminLTE/plugins/iCheck/icheck.js",
                "~/Scripts/AdminLTE/plugins/slimScroll/jquery.slimscroll.js",
                "~/Scripts/AdminLTE/plugins/datatables/jquery.dataTables.js",
                "~/Scripts/AdminLTE/plugins/datatables/dataTables.bootstrap.js",
                "~/Scripts/AdminLTE/plugins/select2/select2.full.min.js",
                "~/Scripts/AdminLTE/plugins/chartjs/Chart.js"));

            bundles.Add(new ScriptBundle("~/bundles/vis").Include(
                        "~/Scripts/vis/vis-graph3d.min.js",
                        "~/Scripts/vis/vis-network.min.js",
                        "~/Scripts/vis/vis-timeline-graph2d.min.js",
                        "~/Scripts/vis/vis.js"));


            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));

            bundles.Add(new StyleBundle("~/Content/AdminLTE/css").Include(
                "~/Content/AdminLTE/AdminLTE.css",
                "~/Content/css/font-awesome.css",
                "~/Content/AdminLTE/skins/_all-skins.css",
                "~/Scripts/AdminLTE/plugins/morris/morris.css",
                "~/Scripts/AdminLTE/plugins/jvectormap/jquery-jvectormap-1.2.2.css",
                "~/Scripts/AdminLTE/plugins/daterangepicker/daterangepicker-bs3.css",
                "~/Scripts/AdminLTE/plugins/datepicker/datepicker3.css",
                "~/Scripts/AdminLTE/plugins/datetimepicker/bootstrap-datetimepicker.css",
                "~/Scripts/AdminLTE/plugins/datatables/dataTables.bootstrap.css",
                "~/Scripts/AdminLTE/plugins/select2/select2.min.css"));

            bundles.Add(new StyleBundle("~/Content/vis/css").Include(
                    "~/Content/vis/vis-network.min.css",
                    "~/Content/vis/vis-timeline-graph2d.min.css",
                    "~/Content/vis/vis.css"));

            BundleTable.EnableOptimizations = false;

        }
    }
}
