﻿CREATE TABLE [DataMover].[PartnersPDFUploadAuditLog] (
    [Id]			INT            IDENTITY (1, 1) NOT NULL,
    [DocumentId]	VARCHAR (1000) NOT NULL,
    [ReportType]	VARCHAR (1000) NULL,
	[PDFFileName]	VARCHAR (1000) NULL,
    [Status]		VARCHAR (50)   NOT NULL,
    [CreateUser]          VARCHAR (255)  NULL,
    [CreateDate]          DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser]          VARCHAR (255)  NULL,
    [UpdateDate]          DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

