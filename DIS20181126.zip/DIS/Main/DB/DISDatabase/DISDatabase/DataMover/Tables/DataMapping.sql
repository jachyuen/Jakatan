﻿CREATE TABLE [DataMover].[DataMapping] (
    [Id]                  INT            IDENTITY (1, 1) NOT NULL,
    [MappingType]         VARCHAR (100)  NOT NULL,
    [MappingPropertyFrom] VARCHAR (255)  NOT NULL,
    [MappingPropertyTo]   VARCHAR (255)  NOT NULL,
    [MappingValueFrom]    NVARCHAR (255) NOT NULL,
	[MappingValueTransition]    NVARCHAR (1000) NULL,
    [MappingValueTo]      NVARCHAR (255) NOT NULL,
    [CreateUser]          VARCHAR (255)  NULL,
    [CreateDate]          DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser]          VARCHAR (255)  NULL,
    [UpdateDate]          DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

