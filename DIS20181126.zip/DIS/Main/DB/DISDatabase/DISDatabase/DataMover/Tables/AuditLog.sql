﻿CREATE TABLE [DataMover].[AuditLog] (
    [Id]                  INT            IDENTITY (1, 1) NOT NULL,
    [DataMoverModuleName] VARCHAR (1000) NOT NULL,
    [Source]              VARCHAR (1000) NOT NULL,
    [Destination]         VARCHAR (1000) NOT NULL,
    [Status]              VARCHAR (50)   NOT NULL,
    [ErrorMsg]            VARCHAR (MAX)  NULL,
    [TotalCount]          INT            NULL,
    [GoodCount]           INT            NULL,
    [BadCount]            INT            NULL,
    [CreateUser]          VARCHAR (255)  NULL,
    [CreateDate]          DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser]          VARCHAR (255)  NULL,
    [UpdateDate]          DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

