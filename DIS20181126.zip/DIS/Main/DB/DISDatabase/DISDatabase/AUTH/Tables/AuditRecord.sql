﻿CREATE TABLE [AUTH].[AuditRecord] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [Action]     VARCHAR (100)  NOT NULL,
    [Parameters] NVARCHAR (500) NULL,
    [RunStatus]  NVARCHAR (50)  DEFAULT ('KO') NULL,
    [RunDetails] NVARCHAR (500) NULL,
    [CreateUser] NVARCHAR (50)  NULL,
    [CreateDate] DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser] NVARCHAR (50)  NULL,
    [UpdateDate] DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

