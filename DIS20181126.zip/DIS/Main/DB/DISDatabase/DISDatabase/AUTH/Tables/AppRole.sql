﻿CREATE TABLE [AUTH].[AppRole] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [Name]            VARCHAR (255)  NULL,
    [Description]     VARCHAR (1500) NULL,
    [ApplicationCode] VARCHAR (255)  NULL,
    [IsActive]        BIT            DEFAULT ((1)) NULL,
    [IsDeleted]       BIT            DEFAULT ((0)) NULL,
    [CreateUser]      NVARCHAR (50)  NULL,
    [CreateDate]      DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser]      NVARCHAR (50)  NULL,
    [UpdateDate]      DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

