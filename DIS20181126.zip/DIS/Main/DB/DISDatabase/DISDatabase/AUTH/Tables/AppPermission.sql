﻿CREATE TABLE [AUTH].[AppPermission] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [Name]            VARCHAR (255)  NOT NULL,
    [Description]     VARCHAR (1500) NULL,
    [ApplicationCode] VARCHAR (255)  NULL,
    [IsDeleted]       BIT            DEFAULT ((0)) NULL,
    [CreateUser]      VARCHAR (255)  NULL,
    [CreateDate]      DATETIME       DEFAULT (getdate()) NULL,
    [UpdateUser]      VARCHAR (255)  NULL,
    [UpdateDate]      DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

