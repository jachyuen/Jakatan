﻿CREATE TABLE [AUTH].[RolePermission] (
    [Id]               INT           IDENTITY (1, 1) NOT NULL,
    [AppRole_Id]       INT           NOT NULL,
    [AppPermission_Id] INT           NOT NULL,
    [IsDeleted]        BIT           DEFAULT ((0)) NULL,
    [CreateUser]       NVARCHAR (50) NULL,
    [CreateDate]       DATETIME      DEFAULT (getdate()) NULL,
    [UpdateUser]       NVARCHAR (50) NULL,
    [UpdateDate]       DATETIME      DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_RolePermission_ToAppPermission] FOREIGN KEY ([AppPermission_Id]) REFERENCES [AUTH].[AppPermission] ([Id]),
    CONSTRAINT [FK_RolePermission_ToAppRole] FOREIGN KEY ([AppRole_Id]) REFERENCES [AUTH].[AppRole] ([Id])
);

