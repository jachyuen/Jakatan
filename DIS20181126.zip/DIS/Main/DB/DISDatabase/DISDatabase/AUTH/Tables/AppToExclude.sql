﻿CREATE TABLE [AUTH].[AppToExclude] (
    [Id]              INT           IDENTITY (1, 1) NOT NULL,
    [ApplicationCode] VARCHAR (255) NOT NULL,
    [IsDeleted]       BIT           DEFAULT ((0)) NOT NULL,
    [CreateUser]      VARCHAR (255) NULL,
    [CreateDate]      DATETIME      DEFAULT (getdate()) NULL,
    [UpdateUser]      VARCHAR (255) NULL,
    [UpdateDate]      DATETIME      DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

