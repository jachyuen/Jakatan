﻿CREATE TABLE [AUTH].[UserRole] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Username]   VARCHAR (255) NOT NULL,
    [AppRole_Id] INT           NOT NULL,
    [IsDeleted]  BIT           DEFAULT ((0)) NULL,
    [CreateUser] NVARCHAR (50) NULL,
    [CreateDate] DATETIME      DEFAULT (getdate()) NULL,
    [UpdateUser] NVARCHAR (50) NULL,
    [UpdateDate] DATETIME      DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_UserRole_ToAppRole] FOREIGN KEY ([AppRole_Id]) REFERENCES [AUTH].[AppRole] ([Id])
);

